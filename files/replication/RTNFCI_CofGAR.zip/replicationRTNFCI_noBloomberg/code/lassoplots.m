% This script loads in the .mat file from our L1QR-penalized analysis and creates
% figures used in the paper.

clearvars -except maindir
close all

%% Set formatting parameters for plots and load in mat file from decomposition 
outfolder = fullfile(maindir, 'figures');
set(groot, ...
    'DefaultAxesFontName', 'Times New Roman', ...
    'DefaultTextFontName', 'Times New Roman', ...
    'DefaultLegendFontName', 'Times New Roman', ...
    'DefaultAxesTitleFontWeight', 'normal', ...
    'defaultAxesFontSize',10, ...
    'defaultTextFontSize',10, ...
    'defaultTextFontSizeMode','manual', ...
    'defaultLegendFontSize',10, ...
    'defaultLegendFontSizeMode','manual' ...
    )
lw = 1.5;
Fwidth=7; % width of figure (inches)
Fheight=6; % height of figure (inches)
x0=0; % horizontal starting point on screen (inches)
y0=0; % vertical starting point on screen (inches)
colors = {'#000000', '#CCCCCC', '#ABABAB', '#5C5C5C'};

load(fullfile(maindir, 'output', 'beta_L1norm_tickloss.mat'))

%% Find the last lambda value for which coefficients are nonzero
for i = 1:2
    h = horizons(i);
    fh = h_names{i};
    for f = 1:flength
        fn_series = series_names{f};
        rhsNames = RHS_names.(fn_series)(2:end);
    
        for t = 1:length(Tau)
            tau     = Tau(t);
            fn_tau  = sprintf('Q%d', t);      %quantiles 1st to 5th
    
            % round coefficients with absolute value less than 0.0001 to zero
            B_givenLambda.(fh).(fn_series).(fn_tau)(abs(B_givenLambda.(fh).(fn_series).(fn_tau)) < 0.0001 ) = 0;
    
            % get L1-norm
            l1norm = L1norm_givenLambda.(fh).(fn_series).(fn_tau);
    
            for m = 1:length(rhsNames)
    
                % FIRST METHOD: Find first instance where coefficient is
                % different from zero FROM THE RIGHT (find method 'last').
                % (Remember that L1 norm gets bigger going from right to
                % left.)
                % So this method doesn't catch cases where coefficient
                % briefly picks up for one L1-norm but then
                % goes back to being (effectively) zero again for a while
                % until it finally stabilizes, i.e. remains well-separated
                % from zero for the rest of the sequence of L1-norm
    
                beta = B_givenLambda.(fh).(fn_series).(fn_tau)(m +1,:);     % start from 2nd row since the first row is intercepts
    
                temp_idx = find(abs(beta) > 0, 1, 'last');
    
                % account for cases where EVERY OR NO coefficient is
                % well-separated from zero, such that the returned temp_idx
                % matrix is empty
                sum_beta_zero = sum(beta == 0);                             % sum the logical array of beta == 0
    
                if isempty(temp_idx) == 1 && sum_beta_zero == 0             % every coefficient is well-separated from zero
                    [~, idx_min_L1norm]  = min(l1norm);
                    idx.B_givenLambda_zeros.(fh).(fn_series).(fn_tau)(m, 1) = idx_min_L1norm;       %then component enters model at the first plotted (minimum) L1 norm
                elseif isempty(temp_idx) == 1 && sum_beta_zero ~= 0          % NO coefficient is well-separated from zero
                    idx.B_givenLambda_zeros.(fh).(fn_series).(fn_tau)(m, 1) = 0;                    %then coefficient never enters the model
                elseif isempty(temp_idx) == 0
                    idx.B_givenLambda_zeros.(fh).(fn_series).(fn_tau)(m, 1) = temp_idx;
                end
    
    
            end
        end
    end
    
    %========================================================================
    %  GET IDX WHERE COEFFICIENT BECOMES WELL SEPARATED FROM ZERO
    
    for f = 1:flength
        fn_series = series_names{f};
        rhsNames = RHS_names.(fn_series)(2:end);
    
        for t = 1:length(Tau)
            tau     = Tau(t);
            fn_tau  = sprintf('Q%d', t);      %quantiles 1st to 5th
    
            % index L1 norm where each component's coefficient first becomes
            % nonzero
            idx_nonzero_coeff.(fh).(fn_series).(fn_tau) = idx.B_givenLambda_zeros.(fh).(fn_series).(fn_tau);
    
            %sort based on descending order of L1 norm indices where
            %coefficients becomes well-separated from zero (L1 norm gets
            %smaller as indices get bigger)
            [idx_nonzero_coeff.(fh).(fn_series).(fn_tau),idx_sort] = sort(idx_nonzero_coeff.(fh).(fn_series).(fn_tau), 'descend');
            rhsNames_sorted.(fh).(fn_series).(fn_tau) = rhsNames(idx_sort);

         
        end
    end
end


%% Figure 4
fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

subplot(3, 2, 1)
plot(L1norm_givenLambda.h1.GDP.Q1, loss_givenLambda.h1.GDP.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h1.GDP.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h1.GDP.Q1(idx_nonzero_coeff.h1.GDP.Q1(strcmp(rhsNames_sorted.h1.GDP.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.GDP.Q1(idx_nonzero_coeff.h1.GDP.Q1(strcmp(rhsNames_sorted.h1.GDP.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h1.GDP.Q1(idx_nonzero_coeff.h1.GDP.Q1(strcmp(rhsNames_sorted.h1.GDP.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.GDP.Q1(idx_nonzero_coeff.h1.GDP.Q1(strcmp(rhsNames_sorted.h1.GDP.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
ylabel('GDP')
xlim([min(L1norm_givenLambda.h1.GDP.Q1) - 0.01, 0.85])
ylim([0.085, max(loss_givenLambda.h1.GDP.Q1)])
title('1Q-Ahead')

subplot(3, 2, 2)
plot(L1norm_givenLambda.h4.GDP.Q1, loss_givenLambda.h4.GDP.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h4.GDP.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h4.GDP.Q1(idx_nonzero_coeff.h4.GDP.Q1(strcmp(rhsNames_sorted.h4.GDP.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h4.GDP.Q1(idx_nonzero_coeff.h4.GDP.Q1(strcmp(rhsNames_sorted.h4.GDP.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h4.GDP.Q1(idx_nonzero_coeff.h4.GDP.Q1(strcmp(rhsNames_sorted.h4.GDP.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h4.GDP.Q1(idx_nonzero_coeff.h4.GDP.Q1(strcmp(rhsNames_sorted.h4.GDP.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([min(L1norm_givenLambda.h4.GDP.Q1) - 0.01, 1.12])
ylim([0.075, max(loss_givenLambda.h4.GDP.Q1)])
title('4Q-Ahead')

subplot(3, 2, 3)
plot(L1norm_givenLambda.h1.C.Q1, loss_givenLambda.h1.C.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h1.C.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h1.C.Q1(idx_nonzero_coeff.h1.C.Q1(strcmp(rhsNames_sorted.h1.C.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.C.Q1(idx_nonzero_coeff.h1.C.Q1(strcmp(rhsNames_sorted.h1.C.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h1.C.Q1(idx_nonzero_coeff.h1.C.Q1(strcmp(rhsNames_sorted.h1.C.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.C.Q1(idx_nonzero_coeff.h1.C.Q1(strcmp(rhsNames_sorted.h1.C.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([min(L1norm_givenLambda.h1.C.Q1) - 0.01, 1.05])
ylim([0.085, max(loss_givenLambda.h1.C.Q1)])
ylabel('C')

subplot(3, 2, 4)
plot(L1norm_givenLambda.h4.C.Q1, loss_givenLambda.h4.C.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h4.C.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h4.C.Q1(idx_nonzero_coeff.h4.C.Q1(strcmp(rhsNames_sorted.h4.C.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h4.C.Q1(idx_nonzero_coeff.h4.C.Q1(strcmp(rhsNames_sorted.h4.C.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h4.C.Q1(idx_nonzero_coeff.h4.C.Q1(strcmp(rhsNames_sorted.h4.C.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h4.C.Q1(idx_nonzero_coeff.h4.C.Q1(strcmp(rhsNames_sorted.h4.C.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([min(L1norm_givenLambda.h4.C.Q1) - 0.01, 1.12])
ylim([0.089, max(loss_givenLambda.h4.C.Q1)])


subplot(3, 2, 5)
plot(L1norm_givenLambda.h1.I.Q1, loss_givenLambda.h1.I.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h1.I.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h1.I.Q1(idx_nonzero_coeff.h1.I.Q1(strcmp(rhsNames_sorted.h1.I.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.I.Q1(idx_nonzero_coeff.h1.I.Q1(strcmp(rhsNames_sorted.h1.I.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h1.I.Q1(idx_nonzero_coeff.h1.I.Q1(strcmp(rhsNames_sorted.h1.I.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.I.Q1(idx_nonzero_coeff.h1.I.Q1(strcmp(rhsNames_sorted.h1.I.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
ylabel('I')
xlim([min(L1norm_givenLambda.h1.I.Q1) - 0.01, 1])
ylim([0.085, max(loss_givenLambda.h1.I.Q1)])
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')

subplot(3, 2, 6)
plot(L1norm_givenLambda.h4.I.Q1, loss_givenLambda.h4.I.Q1, 'LineWidth', lw, 'Color','k')
%xline(L1norm_givenLambda.h4.I.Q1(201), 'LineStyle', '-', 'Label', 'Optimal $\lambda$', 'Interpreter', 'latex')
xline(L1norm_givenLambda.h4.I.Q1(idx_nonzero_coeff.h4.I.Q1(strcmp(rhsNames_sorted.h4.I.Q1, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h4.I.Q1(idx_nonzero_coeff.h4.I.Q1(strcmp(rhsNames_sorted.h4.I.Q1, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h4.I.Q1(idx_nonzero_coeff.h4.I.Q1(strcmp(rhsNames_sorted.h4.I.Q1, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h4.I.Q1(idx_nonzero_coeff.h4.I.Q1(strcmp(rhsNames_sorted.h4.I.Q1, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([min(L1norm_givenLambda.h4.I.Q1) - 0.01, 1.2])
ylim([0.07, max(loss_givenLambda.h4.I.Q1)])
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')

exportgraphics(fig, fullfile(outfolder, 'Figure4.pdf'), 'BackgroundColor', 'none')

%% Figure A5
styles = {'-', '--', '-.', ':'};
names = {'GDP', 'Leverage', 'Credit', 'Risk'};

fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

subplot(3, 2, 1)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.GDP.Q1, B_givenLambda.h1.GDP.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
legend(names, 'Location', 'southwest', 'FontSize', 6)
ylabel('GDP')
title('1Q-Ahead')
xlim([min(L1norm_givenLambda.h1.GDP.Q1), 0.85])

subplot(3, 2, 2)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.GDP.Q1, B_givenLambda.h4.GDP.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
title('4Q-Ahead')
xlim([min(L1norm_givenLambda.h4.GDP.Q1), 1.1])

subplot(3, 2, 3)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.C.Q1, B_givenLambda.h1.C.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
ylabel('C')
xlim([min(L1norm_givenLambda.h1.C.Q1), 0.9])

subplot(3, 2, 4)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.C.Q1, B_givenLambda.h4.C.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
xlim([min(L1norm_givenLambda.h4.C.Q1), 0.9])

subplot(3, 2, 5)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.I.Q1, B_givenLambda.h1.I.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
ylabel('I')
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')
xlim([min(L1norm_givenLambda.h1.I.Q1), 1])

subplot(3, 2, 6)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.I.Q1, B_givenLambda.h4.I.Q1(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')
xlim([min(L1norm_givenLambda.h4.I.Q1), 1.2])

exportgraphics(fig, fullfile(outfolder, 'FigureA5.pdf'), 'BackgroundColor', 'none')

%% Figure A6

fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

subplot(3, 2, 1)
plot(L1norm_givenLambda.h1.GDP.Q3, loss_givenLambda.h1.GDP.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h1.GDP.Q3(idx_nonzero_coeff.h1.GDP.Q3(strcmp(rhsNames_sorted.h1.GDP.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.GDP.Q3(idx_nonzero_coeff.h1.GDP.Q3(strcmp(rhsNames_sorted.h1.GDP.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.GDP.Q3(idx_nonzero_coeff.h1.GDP.Q3(strcmp(rhsNames_sorted.h1.GDP.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.GDP.Q3(idx_nonzero_coeff.h1.GDP.Q3(strcmp(rhsNames_sorted.h1.GDP.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','middle')
ylabel('GDP')
xlim([0, max(L1norm_givenLambda.h1.GDP.Q3)])
ylim([0.088, max(loss_givenLambda.h1.GDP.Q3)])
title('1Q-Ahead')

subplot(3, 2, 2)
plot(L1norm_givenLambda.h4.GDP.Q3, loss_givenLambda.h4.GDP.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h4.GDP.Q3(idx_nonzero_coeff.h4.GDP.Q3(strcmp(rhsNames_sorted.h4.GDP.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP')
xline(L1norm_givenLambda.h4.GDP.Q3(idx_nonzero_coeff.h4.GDP.Q3(strcmp(rhsNames_sorted.h4.GDP.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h4.GDP.Q3(idx_nonzero_coeff.h4.GDP.Q3(strcmp(rhsNames_sorted.h4.GDP.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h4.GDP.Q3(idx_nonzero_coeff.h4.GDP.Q3(strcmp(rhsNames_sorted.h4.GDP.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([0, max(L1norm_givenLambda.h4.GDP.Q3)])
ylim([0.073, max(loss_givenLambda.h4.GDP.Q3)])
title('4Q-Ahead')

subplot(3, 2, 3)
plot(L1norm_givenLambda.h1.C.Q3, loss_givenLambda.h1.C.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h1.C.Q3(idx_nonzero_coeff.h1.C.Q3(strcmp(rhsNames_sorted.h1.C.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP', 'LabelVerticalAlignment','top')
xline(L1norm_givenLambda.h1.C.Q3(idx_nonzero_coeff.h1.C.Q3(strcmp(rhsNames_sorted.h1.C.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','top')
xline(L1norm_givenLambda.h1.C.Q3(idx_nonzero_coeff.h1.C.Q3(strcmp(rhsNames_sorted.h1.C.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.C.Q3(idx_nonzero_coeff.h1.C.Q3(strcmp(rhsNames_sorted.h1.C.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','bottom')
xlim([0, 0.415])
ylim([0.0913, max(loss_givenLambda.h1.C.Q3)])
ylabel('C')

subplot(3, 2, 4)
plot(L1norm_givenLambda.h4.C.Q3, loss_givenLambda.h4.C.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h4.C.Q3(idx_nonzero_coeff.h4.C.Q3(strcmp(rhsNames_sorted.h4.C.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP')
xline(L1norm_givenLambda.h4.C.Q3(idx_nonzero_coeff.h4.C.Q3(strcmp(rhsNames_sorted.h4.C.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','bottom')
xline(L1norm_givenLambda.h4.C.Q3(idx_nonzero_coeff.h4.C.Q3(strcmp(rhsNames_sorted.h4.C.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk', 'LabelVerticalAlignment', 'middle')
xline(L1norm_givenLambda.h4.C.Q3(idx_nonzero_coeff.h4.C.Q3(strcmp(rhsNames_sorted.h4.C.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([0, 0.72])
ylim([0.0795, max(loss_givenLambda.h4.C.Q3)])

subplot(3, 2, 5)
plot(L1norm_givenLambda.h1.I.Q3, loss_givenLambda.h1.I.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h1.I.Q3(idx_nonzero_coeff.h1.I.Q3(strcmp(rhsNames_sorted.h1.I.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP')
xline(L1norm_givenLambda.h1.I.Q3(idx_nonzero_coeff.h1.I.Q3(strcmp(rhsNames_sorted.h1.I.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h1.I.Q3(idx_nonzero_coeff.h1.I.Q3(strcmp(rhsNames_sorted.h1.I.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h1.I.Q3(idx_nonzero_coeff.h1.I.Q3(strcmp(rhsNames_sorted.h1.I.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
ylabel('I')
xlim([0, 0.6])
ylim([0.093, max(loss_givenLambda.h1.I.Q3)])
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')

subplot(3, 2, 6)
plot(L1norm_givenLambda.h4.I.Q3, loss_givenLambda.h4.I.Q3, 'LineWidth', lw, 'Color','k')
xline(L1norm_givenLambda.h4.I.Q3(idx_nonzero_coeff.h4.I.Q3(strcmp(rhsNames_sorted.h4.I.Q3, 'QQ_gdp_lags'))), 'LineStyle', '-.', 'Label', 'GDP')
xline(L1norm_givenLambda.h4.I.Q3(idx_nonzero_coeff.h4.I.Q3(strcmp(rhsNames_sorted.h4.I.Q3, 'leverage'))), 'LineStyle', '-.', 'Label', 'Leverage', 'LabelVerticalAlignment','middle')
xline(L1norm_givenLambda.h4.I.Q3(idx_nonzero_coeff.h4.I.Q3(strcmp(rhsNames_sorted.h4.I.Q3, 'risk'))), 'LineStyle', '-.', 'Label', 'Risk')
xline(L1norm_givenLambda.h4.I.Q3(idx_nonzero_coeff.h4.I.Q3(strcmp(rhsNames_sorted.h4.I.Q3, 'credit'))), 'LineStyle', '-.', 'Label', 'Credit', 'LabelVerticalAlignment','top')
xlim([0, 1.05])
ylim([0.093, max(loss_givenLambda.h4.I.Q3)])
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')

exportgraphics(fig, fullfile(outfolder, 'FigureA6.pdf'), 'BackgroundColor', 'none')

%% Figure A7

styles = {'-', '--', '-.', ':'};
names = {'GDP', 'Leverage', 'Credit', 'Risk'};

fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

subplot(3, 2, 1)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.GDP.Q3, B_givenLambda.h1.GDP.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
legend(names, 'Location', 'northwest', 'FontSize', 6)
ylabel('GDP')
title('1Q-Ahead')
xlim([min(L1norm_givenLambda.h1.GDP.Q3), 0.65])

subplot(3, 2, 2)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.GDP.Q3, B_givenLambda.h4.GDP.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
title('4Q-Ahead')
xlim([min(L1norm_givenLambda.h4.GDP.Q3), 0.85])

subplot(3, 2, 3)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.C.Q3, B_givenLambda.h1.C.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
ylabel('C')
xlim([min(L1norm_givenLambda.h1.C.Q3), 0.4])


subplot(3, 2, 4)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.C.Q3, B_givenLambda.h4.C.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
xlim([min(L1norm_givenLambda.h4.C.Q3), 0.65])


subplot(3, 2, 5)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h1.I.Q3, B_givenLambda.h1.I.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
ylabel('I')
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')
xlim([min(L1norm_givenLambda.h1.I.Q3), 0.55])


subplot(3, 2, 6)
hold on
for i = 1:4
    plot(L1norm_givenLambda.h4.I.Q3, B_givenLambda.h4.I.Q3(i+1, :), 'LineWidth', lw, 'LineStyle', styles{i}, 'Color', colors{i})
end
yline(0)
xlabel('$\ell_1$-norm', 'Interpreter', 'latex')
xlim([min(L1norm_givenLambda.h4.C.Q3), 0.85])

exportgraphics(fig, fullfile(outfolder, 'FigureA7.pdf'), 'BackgroundColor', 'none')