%Description: Get Vintages and Realizations for various release types of
%the given FRED Series

clearvars -except maindir vintage_max api_key
close all

%User Defined Parameters

% Cutoffs for first exercise (vintages). 
% NOTE: vintage max should be month ahead of last vintage we want, date max
% should be exact last date (e.g., the first of Jan/Apr/July/Oct for Q1/Q2/Q3/Q4)
date_min = datetime(1971, 1, 1)-calquarters(3); % so we can get four quarter growth rate for 1971
date_max = dateshift(vintage_max - calquarters(1), "start", "month");
vintage_min = datetime(1988, 1, 27);

% Set FRED path and load in SERIES
if ~isfile(fullfile(maindir, "data", "raw", "gdpic1.csv"))
    data = fred_vintages_api(api_key, 'GPDIC1'); % this function will take about 10 minutes as it has to pull every vintage from FRED
    writetimetable(data, fullfile(maindir, "data", "raw", "gdpic1.csv"))
end 

raw_gdpic1 = readcell(fullfile(maindir, "data", "raw", "gdpic1.csv"), "DatetimeType", "text");
gdpic1 = cell2mat(raw_gdpic1(2:end, 2:end));
date = datetime(raw_gdpic1(2:end, 1), "InputFormat", "dd-MMM-yy", "PivotYear", 1930);
vintages = datetime(raw_gdpic1(1, 2:end), "InputFormat", "dd-MMM-yy", "PivotYear", 1930);

% Create matrix keeping only series we are interested in (last week of april july oct jan)
idx = [];
vintagedates = [];
current_time = dateshift(vintage_min, 'end', 'month');

for i = 1:length(vintages)-1
    if vintages(i) <= current_time && vintages(i+1) > current_time
        if month(vintages(i)) == month(current_time) && vintages(i) ~= datetime(1996, 1, 19) && vintages(i) ~= datetime(1996, 4, 2)
            vintagedates = [vintagedates; vintages(i)];
            idx = [idx; i];
                if month(current_time) == 4 %Account for april having only 30 days
                    current_time = current_time + calmonths(3) + caldays(1);
                else 
                    current_time = current_time + calmonths(3);
                end 
        else
            vintagedates = [vintagedates; vintages(i+1)];
            idx = [idx; i+1];
                if month(current_time) == 4 %Account for april having only 30 days
                    current_time = current_time + calmonths(3) + caldays(1);
                else 
                    current_time = current_time + calmonths(3);
                end 
            end
        end 
end

%Clean to desired dates
idx_date = date >= date_min & date <= date_max; %Select Date Cutoff
idx_vintage = vintagedates >= vintage_min & vintagedates < vintage_max; %Select Vintage Cutoff

series_lvl0 = gdpic1(idx_date, idx);
series_lvl0 = series_lvl0(:, idx_vintage);

date0 = date(idx_date);
vintagedates0 = vintagedates(idx_vintage);

gdpic1_quarterly = array2timetable(series_lvl0, "RowTimes",date0, "VariableNames",string(vintagedates0));

% correction for 2025 government shutdown, label Dec 2025 vintage as first
% week of October since there were no releases for october ad november (dec
% 2025 can count as the first week of october for our purposes)
gdpic1_quarterly.Properties.VariableNames(strcmp(gdpic1_quarterly.Properties.VariableNames, "23-Dec-2025"))={'30-Oct-2025'};
writetimetable(gdpic1_quarterly, fullfile(maindir, "data", "raw", "gdpic1_quarterly.txt")); % export quarterly data in levels

