% This script loads in the .mat file from our main analysis and creates
% figures used in the paper.

clearvars -except maindir api_key % needed for figure A4
close all

%% Set formatting parameters for plots and load in mat file from decomposition 
outfolder = fullfile(maindir, 'figures');
Fwidth=7; % width of figure (inches)
Fheight=6; % height of figure (inches)
x0=0; % horizontal starting point on screen (inches)
y0=0; % vertical starting point on screen (inches)
lw = 1.5;

set(groot,...
    'DefaultAxesFontName', 'Times New Roman',...
    'DefaultTextFontName', 'Times New Roman',...
    'DefaultLegendFontName', 'Times New Roman',...
    'DefaultAxesTitleFontWeight', 'normal',...
    'defaultAxesFontSize',10,...
    'defaultTextFontSize',10,...
    'defaultTextFontSizeMode','manual',...
    'defaultLegendFontSize',10,...
    'defaultLegendFontSizeMode','manual'...
    ) 

%Define Colors
color_components = ['#000000' %CNDUR 
         '#5C5C5C' %CDUR
         '#ABABAB' %CSER
         '#000000' %INRES
         '#ABABAB' %IRES
         '#000000' %X
         '#ABABAB']; %M

color = ['#000000'; '#CCCCCC'; '#ABABAB'; '#5C5C5C']; 

%Load decomposition data
load(fullfile(maindir, 'output', 'decomp_pchg.mat'))

%% Read in weekly RTNFCI
rtnfci_vintages = readtimetable(fullfile(maindir, 'data', 'raw', 'nfci.csv'), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
% Add 2012/11/1 vintage and 2020/1/1 since these are missing on ALFRED
rtnfci_vintages.("01-Nov-2012") = NaN(height(rtnfci_vintages), 1);
rtnfci_vintages.("01-Jan-2020") = NaN(height(rtnfci_vintages), 1);
orderedCol = string(sortrows(datetime(rtnfci_vintages.Properties.VariableNames'))); 
rtnfci_vintages = rtnfci_vintages(:, orderedCol); % resort columns after adding missing vintages

post1988 = rtnfci_vintages.Properties.RowTimes>datetime(1987, 12, 31); % first vintage is Jan 6 1988, only include dates 1988-present
rtnfci_vintages = rtnfci_vintages(post1988, :);
rtnfci = diag(rtnfci_vintages{:, :}); % Get diagonals

dates_rtnfci = rtnfci_vintages.Properties.RowTimes; % Store dates and vintages
vintages_rtnfci = datetime(rtnfci_vintages.Properties.VariableNames);

%% Get decomposition based on value and predicted shortfall
for i = 1:2
    
    fh = h_names{i};
    
    decomp.(fh) = NaN(length(Esf.(fh)), flength-1);
    
    tots.(fh) = gdp_lvls.(fh);
    
    for f = 1:length(Esf_ynames)
        
        weight_tot = abs(series_lvls.(fh)(:, f))./tots.(fh);
        decomp.(fh)(:, f) = weight_tot.*Esf.(fh)(:, f);
             
    end
    
    decomp.(fh)(:, strcmp('M', Esf_ynames)) = decomp.(fh)(:, strcmp('M', Esf_ynames))*-1;       
    
    idx.(fh) = targets.(fh) <= datetime(2019, 12, 31);
    idx_covid.(fh) = targets.(fh) >= datetime(2019, 1, 1);   
    
    % note we need to interpolate into weekly values so we don't get odd
    % transitions between negative and positive values
    targets_ip.(fh) = targets.(fh)(1):calweeks(2):targets.(fh)(end);
    idx_ip.(fh) = targets_ip.(fh) <= datetime(2019, 12, 31);
    idx_ip_covid.(fh) = targets_ip.(fh) >= datetime(2019, 1, 1);
    decomp_ip.(fh) = interp1(targets.(fh), decomp.(fh), targets_ip.(fh));
    T_ip.(fh) = length(targets_ip.(fh));
    area_neg.(fh) = zeros(T_ip.(fh), (flength-1));
    area_pos.(fh) = zeros(T_ip.(fh), (flength-1));
    
    
    for j = 1:length(Esf_ynames)
        for t = 1:T_ip.(fh)
            
            if decomp_ip.(fh)(t, j) < 0
                area_neg.(fh)(t, j) = decomp_ip.(fh)(t, j);
            else
                area_pos.(fh)(t, j) = decomp_ip.(fh)(t, j);
            end
        end
    end
    
end

%% Figure 1
y_names = {'C', 'I', 'G', 'NX'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches','Position',[x0 y0 Fwidth Fheight],'PaperPositionMode','auto');

% h = 1
ax1 = subplot(2, 1, 1);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx))
colororder(ax1, color )
area(targets_ip.h1, area_pos.h1(:, y_idx))
colororder(ax1, color)
ylabel('Annualized Percent Change')
legend(y_names, 'location', 'southwest', 'orientation', 'horizontal', 'NumColumns', 2)
title('1Q-Ahead')
xlim([targets.h1(1), datetime(2019, 12, 1)])

% h = 4
ax2 = subplot(2, 1, 2);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx))
colororder(ax2, color)
area(targets_ip.h4, area_pos.h4(:, y_idx))
colororder(ax2, color)
ylabel('Annualized Percent Change')
title('4Q-Ahead')
xlim([targets.h4(1), datetime(2019, 12, 1)])

ha=get(gcf,'children');

set(ha(1),'position',[.13 .11 .775 .3412])
set(ha(3),'position',[.13 .525 .775 .3412])

exportgraphics(fig, fullfile(outfolder, 'Figure1.pdf'), 'BackgroundColor', 'none')

%% Figure 2
y_names = {'C', 'I', 'G', 'NX'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches','Position',[x0 y0 Fwidth Fheight], 'PaperPositionMode','auto');

ynames_long = {'Consumption', 'Investment', 'Govt Spending', 'Net Exports'};
for f = 1:length(y_idx)    
    fn = ynames_long{f};
    subplot(4, 2, f*2-1)
    hold on
    plot(targets.h1, Esf.h1(:, y_idx(f)), 'color', 'k', 'linewidth', lw)
    yline(0)
    ylabel(y_names{f})
    if f == 1
        title('1Q-Ahead')
    end
    xlim([targets.h1(1), datetime(2019, 12, 1)])
end

% h = 4
for f = 1:length(y_idx)   
    fn = ynames_long{f};
    subplot(4, 2, f*2)
    hold on
    plot(targets.h4, Esf.h4(:, y_idx(f)), 'color', 'k', 'linewidth', lw)
    yline(0)
    if f == 1
        title('4Q-Ahead')
    end
    xlim([targets.h4(1), datetime(2019, 12, 1)])
end

ha=get(gcf,'children');
set(ha(8),'position',[0.1300 0.7673 0.3347 0.1577])
set(ha(7),'position',[0.1300 0.5482 0.3347 0.1577])
set(ha(6),'position',[0.1300 0.3291 0.3347 0.1577])
set(ha(5),'position',[0.1300 0.1100 0.3347 0.1577])
set(ha(4),'position',[0.54 0.7673 0.3347 0.1577])
set(ha(3),'position',[0.54 0.5482 0.3347 0.1577])
set(ha(2),'position',[0.54 0.3291 0.3347 0.1577])
set(ha(1),'position',[0.54 0.1100 0.3347 0.1577])

exportgraphics(fig, fullfile(outfolder, 'Figure2.pdf'), 'BackgroundColor', 'none')

%% Figure 3
y_names = {'CNDUR', 'CDUR', 'CSER' 'INRES', 'IRES', 'X', 'M'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

ax1 = subplot(3, 2, 1);
hold on
title('1Q Ahead')
area(targets_ip.h1, area_neg.h1(:, y_idx(1:3)))
colororder(ax1, color_components(1:3, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(1:3)))
colororder(ax1, color_components(1:3, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(1:3), 'location', 'southwest', 'orientation', 'vertical', 'NumColumns', 1, 'fontsize', 7)
xlim([targets.h1(1), datetime(2019, 12, 1)])
hold off

ax2 = subplot(3, 2, 3);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx(4:5)))
colororder(ax2, color_components(4:5, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(4:5)))
colororder(ax2, color_components(4:5, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(4:5), 'location', 'southwest', 'orientation', 'vertical', 'fontsize', 7)
xlim([targets.h1(1), datetime(2019, 12, 1)])
hold off

ax3 = subplot(3, 2, 5);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx(6:7)))
colororder(ax3, color_components(6:7, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(6:7)))
colororder(ax3, color_components(6:7, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(6:7), 'location', 'northwest', 'orientation', 'horizontal', 'fontsize', 7)
xlim([targets.h1(1), datetime(2019, 12, 1)])
hold off

ax4 = subplot(3, 2, 2);
hold on
title('4Q-Ahead')
area(targets_ip.h4, area_neg.h4(:, y_idx(1:3)))
colororder(ax4, color_components(1:3, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(1:3)))
colororder(ax4, color_components(1:3, :))
xlim([targets.h4(1), datetime(2019, 12, 1)])

hold off

ax5 = subplot(3, 2, 4);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx(4:5)))
colororder(ax5, color_components(4:5, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(4:5)))
colororder(ax5, color_components(4:5, :))
xlim([targets.h4(1), datetime(2019, 12, 1)])

hold off

ax6 = subplot(3, 2, 6);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx(6:7)))
colororder(ax6, color_components(6:7, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(6:7)))
colororder(ax6, color_components(6:7, :))
xlim([targets.h4(1), datetime(2019, 12, 1)])

hold off

ha=get(gcf,'children');
set(ha(9),'position',[0.1300 0.65 0.3347 0.2157])
set(ha(7),'position',[0.1300 0.38 0.3347 0.2157])
set(ha(5),'position',[0.1300 0.1100 0.3347 0.2157])
set(ha(3),'position',[0.525 0.65 0.3347 0.2157])
set(ha(2),'position',[0.525 0.38 0.3347 0.2157])
set(ha(1),'position',[0.525 0.1100 0.3347 0.2157])

exportgraphics(fig, fullfile(outfolder, 'Figure3.pdf'), 'BackgroundColor', 'none')

%% Figure A3
decomp_sum.h1 = sum(decomp.h1(:, [1 2 3 6]), 2);
decomp_sum.h4 = sum(decomp.h4(:, [1 2 3 6]), 2);
fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

%h = 1
ax1 = subplot(2, 1, 1);
hold on
plot(targets.h1, Esf_GDP.h1, 'LineWidth', lw, 'color', '#5C5C5C')
plot(targets.h1, decomp_sum.h1,  'LineWidth', lw, 'LineStyle', '--', 'color', 'k')
yline(0)
xlim([targets.h1(1), datetime(2019, 12, 1)])

legend('Expected Shortfall', 'Sum of aCES', 'Location', 'Southwest') 
title('1Q-Ahead')

%h = 4
ax2 = subplot(2, 1, 2);
hold on
plot(targets.h4, Esf_GDP.h4, 'LineWidth', lw, 'color', '#5C5C5C')
plot(targets.h4, decomp_sum.h4, 'LineWidth', lw, 'LineStyle', '--', 'color', 'k')
yline(0)
xlim([targets.h4(1), datetime(2019, 12, 1)])
title('4Q-Ahead')

exportgraphics(fig, fullfile(outfolder, 'FigureA3.pdf'), 'BackgroundColor', 'none')

%% Figure A4
% Get data from FRED for nfci and subindices
url = ['https://api.stlouisfed.org/fred/series/observations?series_id=' 'NFCI' '&file_type=json&api_key=' api_key];
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
NFCI = timetable(dates, pulled_series_data);

url = ['https://api.stlouisfed.org/fred/series/observations?series_id=' 'NFCILEVERAGE' '&file_type=json&api_key=' api_key];
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
NFCILEVERAGE = timetable(dates, pulled_series_data);

url = ['https://api.stlouisfed.org/fred/series/observations?series_id=' 'NFCICREDIT' '&file_type=json&api_key=' api_key];
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
NFCICREDIT = timetable(dates, pulled_series_data);

url = ['https://api.stlouisfed.org/fred/series/observations?series_id=' 'NFCIRISK' '&file_type=json&api_key=' api_key];
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
NFCIRISK = timetable(dates, pulled_series_data);

fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');
plot(NFCI.dates, NFCI.pulled_series_data, 'Color', '#000000', 'LineWidth',1.2)
hold on 
plot(NFCILEVERAGE.dates, NFCILEVERAGE.pulled_series_data, 'Color', '#CCCCCC', 'LineStyle','--', 'LineWidth',1.2)
plot(NFCICREDIT.dates, NFCICREDIT.pulled_series_data, 'Color', '#ABABAB', 'LineStyle','-.', 'LineWidth',1.2)
plot(NFCIRISK.dates, NFCIRISK.pulled_series_data, 'Color', '#5C5C5C', 'LineWidth',1.2)
yline(0, 'k')
xlim([min(NFCI.dates), datetime(2020, 1, 1)])
legend('NFCI', 'Leverage', 'Credit', 'Risk', '', 'Location','north')

exportgraphics(fig, fullfile(outfolder, 'FigureA4.pdf'), 'BackgroundColor', 'none')

%% Table A1
first_row = [' '];
second_row = [' '];
for q = 1:length(horizons)
    fh = horizons(q);
    first_row = [first_row, 'tau='+string(fh), NaN(1, 1)];
    second_row = [second_row, {'nu_w'}, {'sigma_w'}];
end

first_column = [];
for s = [1 2 3 6]
    first_column = [first_column; Esf_ynames(s)];
end

main = [];
for q = 1:length(horizons)
    fh = h_names{q};
    temp = [];
    for s = [1 2 3 6]
        fn = Esf_ynames{s};
        temp = [temp; [nus.(fn).(fh), Rhos.(fn).(fh)(1, 2)]];
    end
    main = [main, temp];
end

table = [first_row; second_row; [first_column, num2cell(main)]];

outfile = fullfile(maindir, 'tables', 'TableA1.csv');
writematrix(table, outfile)

%% Figure C1
y_names = {'C', 'I', 'G', 'NX'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches','Position',[x0 y0 Fwidth Fheight],'PaperPositionMode','auto');

% h = 1
ax1 = subplot(2, 1, 1);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx))
colororder(ax1, color)
area(targets_ip.h1, area_pos.h1(:, y_idx))
colororder(ax1, color)
ylabel('Annualized Percent Change')
legend(y_names, 'location', 'southeast', 'orientation', 'horizontal', 'NumColumns', 2)
title('1Q-Ahead')
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits')

% h = 4
ax2 = subplot(2, 1, 2);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx))
colororder(ax2, color)
area(targets_ip.h4, area_pos.h4(:, y_idx))
colororder(ax2, color)
ylabel('Annualized Percent Change')
title('4Q-Ahead')
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits')

ha=get(gcf,'children');

set(ha(1),'position',[.13 .11 .775 .3412])
set(ha(3),'position',[.13 .525 .775 .3412])

exportgraphics(fig, fullfile(outfolder, 'FigureC1.pdf'), 'BackgroundColor', 'none')

%% Figure C2
y_names = {'CNDUR', 'CDUR', 'CSER' 'INRES', 'IRES', 'X', 'M'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

ax1 = subplot(3, 2, 1);
hold on
title('1Q Ahead')
area(targets_ip.h1, area_neg.h1(:, y_idx(1:3)))
colororder(ax1, color_components(1:3, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(1:3)))
colororder(ax1, color_components(1:3, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(1:3), 'location', 'southeast', 'orientation', 'vertical', 'NumColumns', 1, 'fontsize', 7)
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ax2 = subplot(3, 2, 3);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx(4:5)))
colororder(ax2, color_components(4:5, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(4:5)))
colororder(ax2, color_components(4:5, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(4:5), 'location', 'southeast', 'orientation', 'vertical', 'fontsize', 7)
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ax3 = subplot(3, 2, 5);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx(6:7)))
colororder(ax3, color_components(6:7, :))
area(targets_ip.h1, area_pos.h1(:, y_idx(6:7)))
colororder(ax3, color_components(6:7, :))

ylabel('Annualized Percent Change', 'fontsize', 8)
legend(y_names(6:7), 'location', 'northeast', 'orientation', 'horizontal', 'fontsize', 7)
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ax4 = subplot(3, 2, 2);
hold on
title('4Q-Ahead')
area(targets_ip.h4, area_neg.h4(:, y_idx(1:3)))
colororder(ax4, color_components(1:3, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(1:3)))
colororder(ax4, color_components(1:3, :))
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ax5 = subplot(3, 2, 4);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx(4:5)))
colororder(ax5, color_components(4:5, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(4:5)))
colororder(ax5, color_components(4:5, :))
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ax6 = subplot(3, 2, 6);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx(6:7)))
colororder(ax6, color_components(6:7, :))
area(targets_ip.h4, area_pos.h4(:, y_idx(6:7)))
colororder(ax6, color_components(6:7, :))
xlim([datetime(2020,1, 1),datetime(2022, 4, 1)])
datetick('x', 'mmmyy', 'keeplimits', 'keepticks')
hold off

ha=get(gcf,'children');
set(ha(9),'position',[0.1300 0.65 0.3347 0.2157])
set(ha(7),'position',[0.1300 0.38 0.3347 0.2157])
set(ha(5),'position',[0.1300 0.1100 0.3347 0.2157])
set(ha(3),'position',[0.525 0.65 0.3347 0.2157])
set(ha(2),'position',[0.525 0.38 0.3347 0.2157])
set(ha(1),'position',[0.525 0.1100 0.3347 0.2157])

exportgraphics(fig, fullfile(outfolder, 'FigureC2.pdf'), 'BackgroundColor', 'none')