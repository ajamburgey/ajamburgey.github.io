% This script loads in the .mat file from our main analysis and creates
% figure A1 used in the paper.

clearvars -except maindir
close all

%% Set formatting parameters for plots and load in mat file from decomposition 
Fwidth=7; % width of figure (inches)
Fheight=6; % height of figure (inches)
x0=0; % horizontal starting point on screen (inches)
y0=0; % vertical starting point on screen (inches)
lw = 1.5;

set(groot,...
    'DefaultAxesFontName', 'Times New Roman',...
    'DefaultTextFontName', 'Times New Roman',...
    'DefaultLegendFontName', 'Times New Roman',...
    'DefaultAxesTitleFontWeight', 'normal',...
    'defaultAxesFontSize',10,...
    'defaultTextFontSize',10,...
    'defaultTextFontSizeMode','manual',...
    'defaultLegendFontSize',10,...
    'defaultLegendFontSizeMode','manual'...
    ) 

%Define Colors
color = ['#000000'; '#CCCCCC'; '#ABABAB'; '#5C5C5C']; % gray scale

%Load decomposition data
load(fullfile(maindir, 'output', 'decomp_pchg_clayton.mat'))

%% Read in weekly RTNFCI
rtnfci_vintages = readtimetable(fullfile(maindir, 'data', 'raw', 'nfci.csv'), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
% Add 2012/11/1 vintage and 2020/1/1 since these are missing on ALFRED
rtnfci_vintages.("01-Nov-2012") = NaN(height(rtnfci_vintages), 1);
rtnfci_vintages.("01-Jan-2020") = NaN(height(rtnfci_vintages), 1);
orderedCol = string(sortrows(datetime(rtnfci_vintages.Properties.VariableNames'))); 
rtnfci_vintages = rtnfci_vintages(:, orderedCol); % resort columns after adding missing vintages

post1988 = rtnfci_vintages.Properties.RowTimes>datetime(1987, 12, 31); % first vintage is Jan 6 1988, only include dates 1988-present
rtnfci_vintages = rtnfci_vintages(post1988, :);
rtnfci = diag(rtnfci_vintages{:, :}); % Get diagonals

dates_rtnfci = rtnfci_vintages.Properties.RowTimes; % Store dates and vintages
vintages_rtnfci = datetime(rtnfci_vintages.Properties.VariableNames);


%% Get decomposition based on value and predicted shortfall
for i = 1:2
    
    fh = h_names{i};
    
    decomp.(fh) = NaN(length(Esf.(fh)), flength-1);
    
    tots.(fh) = gdp_lvls.(fh);
    
    for f = 1:length(Esf_ynames)
        
        weight_tot = abs(series_lvls.(fh)(:, f))./tots.(fh);
        decomp.(fh)(:, f) = weight_tot.*Esf.(fh)(:, f);
                
    end
    
    decomp.(fh)(:, strcmp('M', Esf_ynames)) = decomp.(fh)(:, strcmp('M', Esf_ynames))*-1;       
    
    idx.(fh) = targets.(fh) <= datetime(2019, 12, 31);
    idx_covid.(fh) = targets.(fh) >= datetime(2019, 1, 1);   
    
    %note we need to interpolate into weekly values so we don't get odd
    %transitions between negative and positive values
    targets_ip.(fh) = targets.(fh)(1):calweeks(2):targets.(fh)(end);
    idx_ip.(fh) = targets_ip.(fh) <= datetime(2019, 12, 31);
    idx_ip_covid.(fh) = targets_ip.(fh) >= datetime(2019, 1, 1);
    decomp_ip.(fh) = interp1(targets.(fh), decomp.(fh), targets_ip.(fh));
    T_ip.(fh) = length(targets_ip.(fh));
    area_neg.(fh) = zeros(T_ip.(fh), (flength-1));
    area_pos.(fh) = zeros(T_ip.(fh), (flength-1));
    
    
    for j = 1:length(Esf_ynames)
        for t = 1:T_ip.(fh)
            
            if decomp_ip.(fh)(t, j) < 0
                area_neg.(fh)(t, j) = decomp_ip.(fh)(t, j);
            else
                area_pos.(fh)(t, j) = decomp_ip.(fh)(t, j);
            end
        end
    end
  
end


%% Figure A2
y_names = {'C', 'I', 'G', 'NX'};
[~, ~, y_idx] = intersect(y_names, Esf_ynames, 'stable');
fig=figure('Units','inches',...
    'Position',[x0 y0 Fwidth Fheight],...
    'PaperPositionMode','auto');

%h = 1
ax1 = subplot(2, 1, 1);
hold on
area(targets_ip.h1, area_neg.h1(:, y_idx))
colororder(ax1, color)
area(targets_ip.h1, area_pos.h1(:, y_idx))
colororder(ax1, color)
ylabel('Annualized Percent Change')
legend(y_names, 'location', 'south', 'orientation', 'horizontal', 'NumColumns', 2)
title('1Q-Ahead')
xlim([targets.h1(1), datetime(2019, 12, 1)])

%h = 4
ax2 = subplot(2, 1, 2);
hold on
area(targets_ip.h4, area_neg.h4(:, y_idx))
colororder(ax2, color)
area(targets_ip.h4, area_pos.h4(:, y_idx))
colororder(ax2, color)
ylabel('Annualized Percent Change')
title('4Q-Ahead')
xlim([targets.h4(1), datetime(2019, 12, 1)])

ha=get(gcf,'children');

set(ha(1),'position',[.13 .11 .775 .3412])
set(ha(3),'position',[.13 .525 .775 .3412])

exportgraphics(fig, fullfile(maindir, 'figures', 'FigureA1.pdf'), 'BackgroundColor', 'none')