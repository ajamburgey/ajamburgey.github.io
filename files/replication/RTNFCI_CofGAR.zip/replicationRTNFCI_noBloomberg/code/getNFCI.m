%Description: Get true NFCI vintages, combine them with our estimated
%vintages, and create 3-month averages of the NFCI.

clearvars -except maindir vintage_max api_key
close all
vintage_choice = datetime(2023, 10, 25); 

%% Retrieve nfci data 
if ~isfile(fullfile(maindir, "data", "raw", "nfci_true.csv"))
    data = fred_vintages_api(api_key, 'NFCI'); % this function will take about ten minutes as it has to pull every vintage of nfci from FRED
    writetimetable(data, fullfile(maindir, "data", "raw", "nfci_true.csv"))
end 

% Combine estimated data from Amburgey and McCracken (2023) and true vintages from FRED
raw_nfci_true = readcell("nfci_true.csv");
nfci_true = cell2mat(raw_nfci_true(2:end, 2:end));

raw_nfci_est = readcell("NFCI_estimatedvintages.xlsx");
nfci_est = readmatrix("NFCI_estimatedvintages.xlsx", "Range","B3");
nfci_est2 = [NaN(length(datetime(1971,1,8):calweeks(1):datetime(1972,12,29)), size(nfci_est, 2)); nfci_est];

values_raw = [[nfci_est2; NaN(length(nfci_true) - length(nfci_est2), size(nfci_est2, 2))], nfci_true]; % nfci_true has more recent dates than nfci_est, fill those missing dates in with NaN rows
dates = vertcat(raw_nfci_true{2:end, 1});
vintages = [vertcat(raw_nfci_est{2, 2:end})', vertcat(raw_nfci_true{1, 2:end})'];

%If correlation with later true vintage is negative, flip sign
correlations = corr(values_raw, 'rows', 'pairwise');
values = values_raw;
for i = 1:length(correlations)
   if correlations(i, 1000) < 0
       values(:, i) = values_raw(:, i)*-1;
   end
end

nfci = array2timetable(values, 'RowTimes',dates, 'VariableNames',string(vintages));
writetimetable(nfci, fullfile(maindir, "data", "raw", "nfci.csv")) % export nfci data composed of both estimated values and true values

%% Create 3-month aggregate vintages for last weeks of April, July, Oct, and Jan
clearvars -except maindir vintage_max api_key vintage_choice
close all

temp = readtimetable(fullfile(maindir, "data", "raw", "nfci.csv"), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
dates = temp.Properties.RowTimes;
vintage_dates = datetime(temp.Properties.VariableNames);
raw = temp{:, :};

% Choose first and last vintage dates and reduce data to subsample
first_date = datetime(1971, 2, 1); %Should be first day of Feb/May/Aug/Nov
first_vintage_date = datetime(1988, 1, 1); %Should be first day of Jan/April/July/Oct
last_vintage_date = vintage_max; % from master file

vintage_idx_keep = vintage_dates >= first_vintage_date & vintage_dates <= last_vintage_date;
dates_idx_keep = dates > first_date & dates <= last_vintage_date;
dates = dates(dates_idx_keep);
vintage_dates = vintage_dates(vintage_idx_keep);
data = raw(dates_idx_keep, vintage_idx_keep);

% Preallocate Parameters
num_vintages = length(first_vintage_date:calmonths(3):last_vintage_date);

dates_3month = (first_date:calmonths(3):last_vintage_date)';
num_dates = length(dates_3month);

vintage_dates_3month = NaT(1, num_vintages);
vintages_3month = NaN(num_dates, num_vintages);

count = 1;
for i = 1:length(vintage_dates)
    if i==length(vintage_dates) || ... % if last vintage 
            (any(month(vintage_dates(i)) == [1 4 7 10]) && month(vintage_dates(i)) ~= month(vintage_dates(i+1))) % OR if vintage is jan, apr, jul, or oct and is the last vintage of mnth
                
        temp_dates_idx = dates <= vintage_dates(i);
        temp_dates = dates(temp_dates_idx);
        temp_vintage = data(temp_dates_idx, i);
        
        temp_dates_3month_idx = dates_3month <= vintage_dates(i);
        temp_dates_3month = dates_3month(temp_dates_3month_idx);
        
        temp_vintage_3month = NaN(length(temp_dates_3month), 1);
                      
        for k = 1:length(temp_dates_3month)
            temp_firstdate = temp_dates_3month(k);
            temp_lastdate = temp_dates_3month(k)+calmonths(3);
            
            temp_keep_vintage_idx = temp_dates >= temp_firstdate & temp_dates < temp_lastdate;           
            temp_vintage_3month(k) = nanmean(temp_vintage(temp_keep_vintage_idx));
                        
        end
        
    vintage_dates_3month(count) = vintage_dates(i);
    vintages_3month(1:length(temp_vintage_3month), count) = temp_vintage_3month;
    count = count+1;
    end
end

nfci_quarterly = array2timetable(vintages_3month, "RowTimes",dates_3month, "VariableNames",string(vintage_dates_3month));
writetimetable(nfci_quarterly, fullfile(maindir, "data", "raw", "nfci_quarterly.csv")) % export quarterly data
writetimetable(nfci_quarterly(:, string(vintage_choice)), fullfile(maindir, "data", "raw", "nfci_quarterly_expost.csv")) % export expost data

%% Get data for subindices (only need expost) AC: choosing vintage equal to 27 Apr 2022 to compare to original paper 
clearvars -except maindir vintage_choice api_key vintage_max

vintage_dates = webread(['https://api.stlouisfed.org/fred/series/vintagedates?series_id=' 'NFCILEVERAGE' '&file_type=json&api_key=' api_key]).vintage_dates;
vintage_dates = vintage_dates(le(vintage_dates,vintage_max));
url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" + "NFCILEVERAGE"  ...
   + "&" + "vintage_dates" + "=" + string(datetime(vintage_choice, 'Format', 'uuuu-MM-dd')) ... % change back to vintage_dates(end) eventually
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
vint = pull.realtime_end;
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
subs.NFCILEVERAGE = array2timetable(pulled_series_data, 'RowTimes', dates, 'VariableNames', string(datetime(vint, 'Format', 'dd-MMM-uuuu')));

vintage_dates = webread(['https://api.stlouisfed.org/fred/series/vintagedates?series_id=' 'NFCICREDIT' '&file_type=json&api_key=' api_key]).vintage_dates;
vintage_dates = vintage_dates(le(vintage_dates,vintage_max));
url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" + "NFCICREDIT"  ...
   + "&" + "vintage_dates" + "=" + string(datetime(vintage_choice, 'Format', 'uuuu-MM-dd')) ... % change back to vintage_dates(end) eventually
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
vint = pull.realtime_end;
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
subs.NFCICREDIT = array2timetable(pulled_series_data, 'RowTimes', dates, 'VariableNames', string(datetime(vint, 'Format', 'dd-MMM-uuuu')));

vintage_dates = webread(['https://api.stlouisfed.org/fred/series/vintagedates?series_id=' 'NFCIRISK' '&file_type=json&api_key=' api_key]).vintage_dates;
vintage_dates = vintage_dates(le(vintage_dates,vintage_max));
url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" + "NFCIRISK"  ...
   + "&" + "vintage_dates" + "=" + string(datetime(vintage_choice, 'Format', 'uuuu-MM-dd')) ... % change back to vintage_dates(end) eventually
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
vint = pull.realtime_end;
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
subs.NFCIRISK = array2timetable(pulled_series_data, 'RowTimes', dates, 'VariableNames', string(datetime(vint, 'Format', 'dd-MMM-uuuu')));

%% Do the same for the subindices 
fs = fieldnames(subs);
for s = 1:numel(fs)
    
    temp = subs.(fs{s});
    dates = temp.Properties.RowTimes;
    vintage_dates = datetime(temp.Properties.VariableNames);
    raw = temp{:, :};
    
    % Choose first and last vintage dates and reduce data to subsample
    first_date = datetime(1971, 2, 1); %Should be first day of Feb/May/Aug/Nov
    first_vintage_date = datetime(1988, 1, 1); %Should be first day of Jan/April/July/Oct
    last_vintage_date = vintage_max; % from master file
    
    vintage_idx_keep = vintage_dates >= first_vintage_date & vintage_dates <= last_vintage_date;
    dates_idx_keep = dates > first_date & dates <= last_vintage_date;
    dates = dates(dates_idx_keep);
    vintage_dates = vintage_dates(vintage_idx_keep);
    data = raw(dates_idx_keep, vintage_idx_keep);
    
    % Preallocate Parameters
    num_vintages = length(first_vintage_date:calmonths(3):last_vintage_date);
    
    dates_3month = (first_date:calmonths(3):last_vintage_date)';
    num_dates = length(dates_3month);
    
    vintage_dates_3month = NaT(1, num_vintages);
    vintages_3month = NaN(num_dates, num_vintages);
    
    count = 1;
    for i = 1:length(vintage_dates)
        if i==length(vintage_dates) || ... % if last vintage 
                (any(month(vintage_dates(i)) == [1 4 7 10]) && month(vintage_dates(i)) ~= month(vintage_dates(i+1))) % OR if vintage is jan, apr, jul, or oct and is the last vintage of mnth
                    
            temp_dates_idx = dates <= vintage_dates(i);
            temp_dates = dates(temp_dates_idx);
            temp_vintage = data(temp_dates_idx, i);
            
            temp_dates_3month_idx = dates_3month <= vintage_dates(i);
            temp_dates_3month = dates_3month(temp_dates_3month_idx);
            
            temp_vintage_3month = NaN(length(temp_dates_3month), 1);
                          
            for k = 1:length(temp_dates_3month)
                temp_firstdate = temp_dates_3month(k);
                temp_lastdate = temp_dates_3month(k)+calmonths(3);
                
                temp_keep_vintage_idx = temp_dates >= temp_firstdate & temp_dates < temp_lastdate;           
                temp_vintage_3month(k) = nanmean(temp_vintage(temp_keep_vintage_idx));
                            
            end
            
        vintage_dates_3month(count) = vintage_dates(i);
        vintages_3month(1:length(temp_vintage_3month), count) = temp_vintage_3month;
        count = count+1;
        end
    end

    keep = ~ismissing(vintage_dates_3month);
       
    sub_quarterly = array2timetable(vintages_3month(:, keep), "RowTimes", dates_3month, "VariableNames",string(vintage_dates_3month(keep)));
    writetimetable(sub_quarterly(:, end), [fullfile(maindir, 'data', 'raw', 'nfci') extractAfter(fs{s}, "NFCI") '_quarterly_expost.csv']) % export expost data

end 