% Run all scripts for growth at risk project replication package
clear 
clc

%user defined variables
maindir = '/Users/aaronamburgey/My Drive/RTNFCI_CofGAR/Replication/replicationRTNFCI_noBloomberg';
api_key = 'f999b68da68a43c60f0fb3312e2e3775'; % user will need to replace this api_key
estimate_nfci = 0; %switch to estimate nfci. 
%NOTE1: without access to the raw bloomberg data the estimated NFCI
%vintages will be considerably different.
%NOTE2: estimating the NFCI requires installing the MFSS toolbox. See
%https://github.com/davidakelley/MFSS for details.

%get paths and vintage dates
cd(maindir)
addpath(genpath(maindir))
vintage_max = datetime(2025, 12, 31);

% step 1: estimate nfci vintages
if estimate_nfci == 1 
    fprintf('-> Constructing NFCI Vintages...\n')
    run 'main_construction.m'
end

% step 2: finish getting all the raw data needed: (nfci and gdpic1)
% still needed from FRED. Philly data is downloaded directly from website and
% saved to "maindir\data\raw\ folder".
fprintf('-> Combining Official and Unofficial NFCI Vintages...\n')
run getNFCI.m 

fprintf('-> Pulling GDPIC1...\n')
run getGDPIC1.m

% step 3: transform and clean data to retrieve percent change calculations 
% and advance estiamtes, outputs to maindir\data\transformed\
% note: this code runs a special transformation for Net Exports percent change
fprintf('-> Transforming and Cleaning Data...\n')
run transformRawData.m 

% step 4: output three mat files, two for decomposition with and without
% nfci, and one for decomposition for subindex analysis
R = 60; % Intial window size
fprintf('-> Estimating Component SF, and aMES...\n')
run sf_decomp.m % outputs mat file, takes a few hours

fprintf('-> Estimating Component SF, and aMES without RTNFCI...\n')
run sf_decomp_noRTNFCI.m % outputs mat file with NFCI excluded, takes a few hours

fprintf('-> Estimating Component SF, and aMES with Clayton Copula...\n')
run sf_decomp_clayton.m % outputs mat file with NFCI excluded, takes a few hours

fprintf('-> Estimating Subindex Quantile LASSO Regressions...\n')
run L1QR_subindices.m % outputs mat file with subindex analysis

% step 5: tables and plots 
fprintf('-> Getting Table 1...\n')
run table1.m 

fprintf('-> Making Plots...\n')
run paper_plots.m % outputs empirics from paper to 'maindir\figures\'

fprintf('-> Making Figure A1...\n')
run figureA1.m % outputs figure based on sf_lr_decomp_clayton.m

fprintf('-> Making Figure A2...\n')
run figureA2.m % outputs figure based on sf_lr_decomp_noRTNFCI.m

fprintf('-> Making LASSO Plots...\n')
run lassoplots.m % outputs empirics based on L1QR_subindices.m
