% This script conducts an the real-time quantile OOS forecasting exercise
% that evaluates whether the unrestricted model (containing the NFCI)
% performs better than the restricted model (omitting the NFCI). We do so
% for GDP and each of its components, and then create Table 1 from the
% paper.

clearvars -except maindir R api_key
close all

%% Set parameters
input = fullfile('data', 'transformed');
series_names = {'GDP', 'C', 'I', 'G', 'NX'}; 
num_series = numel(series_names);
all_out_series = convertCharsToStrings(series_names);
outname = "_PCHG";

preCovid = 1;
R = 60;

first_date = datetime(1988, 1, 1);
raw = struct; % initialize structure that will hold the raw data

%3-Month Averaged RTNFCI Vintages
temp = readcell(fullfile(maindir, 'data', 'raw', 'nfci_quarterly.csv'));
raw_vintage_dates.rtnfci_3mth = datetime(string(temp(1, 2:end)));
raw_dates.rtnfci_3mth = datetime(string(temp(2:end, 1)));
raw.rtnfci_3mth = double(string(temp(2:end, 2:end)));

% Setup predictors    
% Y Predictor Vintages (we want single period growth version of y for RHS)
temp = readcell(fullfile(input, 'GDP', 'pchg_vintages_1Q'));
raw_vintage_dates.ypred = datetime(string(temp(1, 2:end)));
raw_dates.ypred = datetime(string(temp(2:end, 1)));     
raw.ypred = double(string(temp(2:end, 2:end)));

%% Loop over horizons
horizons = [1 4];
h_names = ["h1", "h4"];
h_sheets = ["1Q", "2Q", "3Q", "4Q"]; %Don't Change this, it helps automate the reading in of the excel file tabs

if preCovid ==1
    last_date = datetime(2020, 1, 1); %Determine the last forecast target date (exclude COVID-19 usually a good idea). Should be first day of quarter after last target date.
else
    last_date = datetime(2025, 12, 1); 
end 

first_x_date = datetime(1973, 1, 1); %Do not change, this is the first date that we have NFCI information for earlier vintages
last_x_date = last_date - caldays(1); %Do not change, after lags the functional last x date will be before the last target date

for q = 1:length(horizons)

    h = horizons(q);
    fprintf('   |-- Getting '+string(h)+'Q-Ahead Results...\n')
    h_name = h_names(q);

    for s = 1:num_series

        % disp('Series '+string(s)+' of '+string(num_series)+'...')
        out_series = all_out_series(s);

        first_vintage_date = first_date + calmonths(1) - calquarters(h-1); % Do not change this, it sets the first vintage date
        last_vintage_date = last_date - calmonths(2) - calquarters(h-1); % Do not change this, it sets the last vintage date
       
        %==========================================================================
        % Read in Data
        % Predictand Realizations
        temp = readcell(fullfile(input, series_names{s}, "pchg_realized_advance_" + num2str(h) + "Q.txt"));
        raw_dates.realized = datetime(string(temp(2:end, 1)));
        raw.realized = double(string(temp(2:end, 2:end)));

        %Predictand Vintages (we need h period growth version of y for LHS)
        temp = readcell(fullfile(input, series_names{s}, "pchg_vintages_" + num2str(h) + "Q.txt"));
        raw_vintage_dates.series = datetime(string(temp(1, 2:end)));
        raw_vintage_dates.series(raw_vintage_dates.series == datetime(2019, 2, 28)) = datetime(2019, 1, 31); %Cheat here because we didn't have a january release :(
        raw_dates.series = datetime(string(temp(2:end, 1))); 
        raw.series = double(string(temp(2:end, 2:end)));
       
        %==========================================================================
        % Clean Data
        % Predictand Realizations
        idx.realized = raw_dates.realized >= first_date & raw_dates.realized <= last_date;
        dates.realized = raw_dates.realized(idx.realized);
        data.realized = raw.realized(idx.realized);

        % Predictand Vintages
        idx.series = raw_dates.series >= first_x_date & raw_dates.series <= last_x_date;
        dates.series = raw_dates.series(idx.series);
        idx_vintage.series = raw_vintage_dates.series >= first_vintage_date - calmonths(1) & raw_vintage_dates.series <= last_vintage_date;
        vintage_dates.series = raw_vintage_dates.series(idx_vintage.series);
        data.series = raw.series(idx.series, idx_vintage.series);

        % Y Predictor Vintages
        idx.ypred = raw_dates.ypred >= first_x_date & raw_dates.ypred <= last_x_date;
        dates.ypred = raw_dates.ypred(idx.ypred);
        idx_vintage.ypred = raw_vintage_dates.ypred >= first_vintage_date - calmonths(1) & raw_vintage_dates.ypred <= last_vintage_date;
        vintage_dates.ypred = raw_vintage_dates.ypred(idx_vintage.ypred);
        data.ypred = raw.ypred(idx.ypred, idx_vintage.ypred);

        % 3-Month Averaged RTNFCI Vintages
        idx.rtnfci_3mth = raw_dates.rtnfci_3mth >= first_x_date & raw_dates.rtnfci_3mth <= last_x_date;
        dates.rtnfci_3mth = raw_dates.rtnfci_3mth(idx.rtnfci_3mth);
        idx_vintage.rtnfci_3mth = raw_vintage_dates.rtnfci_3mth >= first_vintage_date - calmonths(1) & raw_vintage_dates.rtnfci_3mth <= last_vintage_date;
        vintage_dates.rtnfci_3mth = raw_vintage_dates.rtnfci_3mth(idx_vintage.rtnfci_3mth);
        data.rtnfci_3mth = raw.rtnfci_3mth(idx.rtnfci_3mth, idx_vintage.rtnfci_3mth);

        % Assertions
        assert(length(dates.rtnfci_3mth) == length(dates.series));
        assert(length(vintage_dates.rtnfci_3mth) == length(vintage_dates.series));
        
        %==========================================================================
        % Determine Origins, Targets, and Preallocate
        % Origins
        origins = first_vintage_date:calmonths(3):last_vintage_date;
        origins = origins(origins >= vintage_dates.rtnfci_3mth(1) & origins <= (vintage_dates.rtnfci_3mth(end) + calmonths(1)));

        num_obs_byvintage = sum(~isnan(data.rtnfci_3mth));
        origins = origins(num_obs_byvintage >= R + h);

        % Targets
        targets = (origins - calmonths(1) + calquarters(h-1))'; %Note that for realized dates we call Q1 Jan and so on, but our origins are first month into the quarter.

        % Shave any extra predictor vintages/dates based on origins/targets
        idx_vintage.series2 = vintage_dates.series >= origins(1) - calmonths(1) & vintage_dates.series <= origins(end);
        vintage_dates.series = vintage_dates.series(idx_vintage.series2);
        data.series = data.series(:, idx_vintage.series2);

        idx_vintage.ypred2 = vintage_dates.ypred >= origins(1) - calmonths(1) & vintage_dates.ypred <= origins(end);
        vintage_dates.ypred = vintage_dates.ypred(idx_vintage.ypred2);
        data.ypred = data.ypred(:, idx_vintage.ypred2);


        idx_vintage.rtnfci_3mth2 = vintage_dates.rtnfci_3mth >= origins(1) - calmonths(1) & vintage_dates.rtnfci_3mth <= origins(end);
        vintage_dates.rtnfci_3mth = vintage_dates.rtnfci_3mth(idx_vintage.rtnfci_3mth2);
        data.rtnfci_3mth = data.rtnfci_3mth(:, idx_vintage.rtnfci_3mth2);

        % Shave any remaining realization dates based on target dates
        idx.realized2 = dates.realized >= targets(1) & dates.realized <= targets(end);
        dates.realized = dates.realized(idx.realized2);
        data.realized = data.realized(idx.realized2);

        % Assertions
        assert(length(dates.rtnfci_3mth) == length(dates.series));
        assert(length(vintage_dates.rtnfci_3mth) == length(vintage_dates.series));
        assert(length(dates.realized) == length(targets))
        assert(length(vintage_dates.rtnfci_3mth) == length(origins))

        % Preallocate Forecasts and real-time endpoints (note that we have 3 columns with Q5, Q50, and, Q95)
        alphas = [0.05, 0.1, 0.5, 0.9, 0.95];
        alpha_names = {'Q5', 'Q10', 'Q50', 'Q90', 'Q95'};
        num_alphas = length(alphas);

        fcast.qar1 = NaN(length(targets), num_alphas);
        fcast.rtnfci = NaN(length(targets), num_alphas);

        x_rt= NaN(length(targets), 2);

        %==========================================================================
        % Get Forecasts
        for i = 1:length(origins)

            target = targets(i);
            origin = origins(i);

            % Get Variables as of Origin
            series = data.series(:, i);
            series_dates = dates.series(~isnan(series));
            series = series(~isnan(series));

            ypred = data.ypred(:, i);
            ypred_dates = dates.ypred(~isnan(ypred));
            ypred = ypred(~isnan(ypred));

            rtnfci_3mth = data.rtnfci_3mth(:, i);
            rtnfci_3mth_dates = dates.rtnfci_3mth(~isnan(rtnfci_3mth));
            rtnfci_3mth = rtnfci_3mth(~isnan(rtnfci_3mth));

            % Get Regression matrices
            y = series((1+h):end);
            series_cur = ypred(end);
            series_lags = ypred(1:end-h);
            rtnfci_3mth_lags = rtnfci_3mth(1:end-h);
            rtnfci_3mth_cur = rtnfci_3mth(end);

            % Get Forecasts
            x_qar1 = series_lags;
            x_rtnfci = [series_lags, rtnfci_3mth_lags];

            for a = 1:num_alphas
                alpha = alphas(a);

                beta_qar1= qr_standard_ajamod(x_qar1, y, alpha, 'test', 'wald', 'method', 'interior');
                fcast.qar1(i, a) = [1 series_cur]*beta_qar1;

                beta_rtnfci= qr_standard_ajamod(x_rtnfci, y, alpha, 'test', 'wald', 'method', 'interior');

                %fix NaN beta in a single case by perturbing alpha slightly
                if isnan(beta_rtnfci(1))
                    beta_rtnfci= qr_standard_ajamod(x_rtnfci, y, alpha+0.00001, 'test', 'wald', 'method', 'interior');
                end                
                fcast.rtnfci(i, a) = [1 series_cur rtnfci_3mth_cur]*beta_rtnfci;

            end

            % Record Real-time endpoints
            x_rt(i, :) = [series_cur rtnfci_3mth_cur];

        end


        %==========================================================================
        % Get Losses, Mean Losses, Loss Differentials
        loss.qar1 = NaN(size(fcast.qar1));
        loss.rtnfci = NaN(size(fcast.qar1));

        errors.qar1 = NaN(size(fcast.qar1));
        errors.rtnfci = NaN(size(fcast.qar1));

        for a = 1:num_alphas
            alpha = alphas(a);

            errors.qar1(:, a) = data.realized - fcast.qar1(:, a);
            loss.qar1(:, a) = (alpha - 1.*(errors.qar1(:, a) < 0)).*errors.qar1(:, a);

            errors.rtnfci(:, a) = data.realized - fcast.rtnfci(:, a);
            loss.rtnfci(:, a) = (alpha - 1.*(errors.rtnfci(:, a) < 0)).*errors.rtnfci(:, a);
        end

        meanloss.qar1 = mean(loss.qar1);
        meanloss.rtnfci = mean(loss.rtnfci);

        lossdiffs = loss.qar1 - loss.rtnfci;
        mean_lossdiffs = mean(lossdiffs);
        cumsum_lossdiff = cumsum(lossdiffs);

        % OOS-t test and pchange in mean loss
        pval = strings(1, num_alphas);
        pchange = NaN(1, num_alphas);

        for a = 1:num_alphas
            alpha = alphas(a);

            omega = get_nonparametric_variance(y, x_rtnfci, x_rt, errors.qar1(:, a), errors.rtnfci(:, a), h, alpha, ...
                R, 'recursive', 1/5, 0);
            stat = mean_lossdiffs(a)/sqrt(omega);
            pval1 = round(1 - normcdf(abs(stat)), 2);
            pval(a) = '('+string(pval1)+')';
            pchange(a) = (meanloss.rtnfci(a) - meanloss.qar1(a))/meanloss.qar1(a);

        end
        
        dates_realized.(out_series).(h_name) = dates.realized;
        realizations.(out_series).(h_name) = data.realized;
        fcasts.(out_series).(h_name) = fcast;
        pchanges.(out_series).(h_name) = pchange;
        pvals.(out_series).(h_name) = pval;

    end
end

%% Create and export table
disp('Creating Table...')

first_row = [' '];
second_row = [' '];
for q = 1:length(horizons)
    h = horizons(q);
    first_row = [first_row, 'h='+string(h), NaN(1, num_alphas -1 )];
    second_row = [second_row, alpha_names];
end

first_column = [];
for s = 1:num_series
    first_column = [first_column; all_out_series(s); NaN];
end

main = [];
for q = 1:length(horizons)
    h_name = h_names(q);
    temp = [];
    for s = 1:num_series
        out_series = all_out_series(s);
        temp = [temp; pchanges.(out_series).(h_name); pvals.(out_series).(h_name)];
    end
    main = [main, temp];
end

table = [first_row; second_row; [first_column, main]];
idx_fix = strcmp(table, '(0)');
table(idx_fix) = {'(0.0001)'};

temp = string(round(double(main), 3));
temp(ismissing(temp)) = main(ismissing(temp));
table(3:end, 2:end) =temp; 
writematrix(table, fullfile(maindir, 'tables', 'Table1.csv'))
