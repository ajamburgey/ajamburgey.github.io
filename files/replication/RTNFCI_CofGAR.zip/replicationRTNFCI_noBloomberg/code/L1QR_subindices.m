% Purpose: This code performs a L1-penalized quantile regression (L1QR) of GDP and
% GDP components on (1) lag of Q/Q GDP growth and (2) lag of all NFCI subindices. It
% computes L-1 norm as well as average tick loss, using
% (1) an optimized lambda following Belloni and Chernozhukov 2011, henceforth B&C 2011
% (2) a set of lambdas of varying sizes related to optimal lambda

% MATLAB user-written function for L1-penalized quantile regression comes
% from the paper ""L1-Penalized Quantile Regression in High-Dimensional
% Sparse Models" (B&C 2011):
% https://people.duke.edu/~abn5/L1QR.m. It depends on the MATLAB toolbox
% SDPT3: https://github.com/sqlp/sdpt3#readme. Both have been approved as
% of February 2023.

clearvars -except maindir vintage_max api_key
close all
rng(585937)             %set seed for reproducibility

%==========================================================================
%Specifications
horizons = [1 4];  % Choose horizon
h_names = {'h1', 'h4'};

series_names = {'GDP', 'C', 'I', 'G', 'NX'};

subindices = {'leverage', 'credit', 'risk'};

flength = length(series_names);
slength = length(subindices);
Esf_ynames = series_names(2:end);

vintage_choice = dateshift(datetime(2023, 10, 25), 'end', 'month'); % AC: should change back to most recent vintage but want to compare to original paper!!!

%% ========================================================================
% SETTING UP PARAMETERS

% hyperparameters for L1QR
Tau = [0.05 0.5 0.95];           %quantiles
S = 200;                                 %max integer constant to divide/multiply  optimal lambda by

% plot parameters
lw = 1;
lw2 = 2;
lw3 = 1.5;

fs_title    = 9;
fs_subtitle = 8;
fs_legend = 7;
fs_legend_s = 5;
marker_size = 3;

input = fullfile(maindir, 'data', 'transformed');
%% ==========================================================================
%Preallocate, then start loop over the two horizons

for i = 1:2

    h = horizons(i);
    fh = h_names{i};

    fprintf('   |-- Getting '+string(h)+'Q-Ahead Results...\n')
   
    %Determine the first possible forecast target date based on vintage availability (could be later depending on data availability and window size)
    first_x_date = datetime(1971, 1, 1); %Do not change, this is the first date that we have NFCI information for earlier vintages
    last_x_date = datetime(2019, 12, 31);

    %==========================================================================
    %Read in data

    %Loop over GDP and series
    for f = 1:flength
        fn_series = series_names{f};

        %Predictand Series
        temp = readtimetable(fullfile(input, fn_series, "pchg_vintages_" + num2str(h) + "Q.txt"), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
        colDelete = datetime(temp.Properties.VariableNames)>vintage_max;
        temp(:, colDelete) = [];
        raw_dates.(fn_series) = temp.Properties.RowTimes;
        raw_chghq.(fn_series) = temp{:, string(vintage_choice)}; % only want expost, most current CURRENTLY IS EQUAL TO VINTAGE CHOICE

        %Predictor Series (dates should be the same as h1)
        temp = readtimetable(fullfile(input, fn_series, 'pchg_vintages_1Q.txt'), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
        colDelete = datetime(temp.Properties.VariableNames)>vintage_max;
        temp(:, colDelete) = [];
        raw_chg1q.(fn_series) = temp{:, string(vintage_choice)}; % only want expost, most current CURRENTLY IS EQUAL TO VINTAGE CHOICE

        %Level (dates should be the same as h1)
        temp = readtimetable(fullfile(input, fn_series, 'level_vintages.txt'), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
        colDelete = datetime(temp.Properties.VariableNames)>vintage_max;
        temp(:, colDelete) = [];
        raw_level.(fn_series) = temp{:, string(vintage_choice)}; % only want expost, most current CURRENTLY IS EQUAL TO VINTAGE CHOICE
    end

    %3-Month Averaged NFCI subindices expost
    for s = 1:slength
        fn_series = subindices{s};
        temp = readtimetable(fullfile('data', 'raw', "nfci" + upper(fn_series) + "_quarterly_expost.csv"), 'ReadVariableNames',true, 'VariableNamingRule','preserve');
        raw_level.(fn_series) = temp{:, :};
        raw_dates.(fn_series) = temp.Properties.RowTimes;
    end

    %==========================================================================
    %Clean Data

    %Loop over GDP and series
    for f = 1:flength
        fn = series_names{f};
        idx.(fn) = raw_dates.(fn) >= first_x_date & raw_dates.(fn) <= last_x_date;
        dates.(fn) = raw_dates.(fn)(idx.(fn));
        chghq.(fn) = raw_chghq.(fn)(idx.(fn), :);
        chg1q.(fn) = raw_chg1q.(fn)(idx.(fn), :);
        level.(fn) = raw_level.(fn)(idx.(fn), :);
    end

    %3-Month Averaged NFCI expost subindices
    for s = 1:slength
        fn_series = subindices{s};
        idx.(fn_series) = raw_dates.(fn_series) >= first_x_date & raw_dates.(fn_series) <= last_x_date;
        dates.(fn_series) = raw_dates.(fn_series)(idx.(fn_series));
        level.(fn_series) = raw_level.(fn_series)(idx.(fn_series), :);
    end

    %Assertions
    for f = 1:flength
        fn_series = series_names{f};
        for s = 1:slength
            fn_subindex = subindices{s};
            assert( length( dates.(fn_subindex) ) == length( dates.(fn_series) ) );
        end
    end


    %% ========================================================================
    % L1 PENALIZED QUANTILE REGRESSION
    %--------------------------------------------------------------------------%
    %Setup
    gdp = chghq.GDP;
    gdp_dates = dates.GDP(~isnan(gdp));
    gdp = gdp(~isnan(gdp));

    gdppred = chg1q.GDP;
    gdppred_dates = dates.GDP(~isnan(gdppred));
    gdppred = gdppred(~isnan(gdppred));

    gdp_y = gdp((1+h):end);

    % Ngan fixed 2/15/2024: Before the RHS was lag of average GDP growth over h-quarters. Now RHS is lag of Q/Q GDP growth
    gdp_lags = gdppred(1:end-h);   

    for s = 1:slength
        fn_series = subindices{s};
        nfciSubindex_3m.(fn_series) = level.(fn_series);
        nfciSubindex_3mth_dates.(fn_series) = dates.(fn_series)( ~isnan( nfciSubindex_3m.(fn_series) ) );
        nfciSubindex_3m.(fn_series) = nfciSubindex_3m.(fn_series)( ~isnan( nfciSubindex_3m.(fn_series) ) );
        nfciSubindex_3m_lag.(fn_series) = nfciSubindex_3m.(fn_series)(1:end-h);
    end

    %==========================================================================
    % L1QR ON GDP GROWTH
    % disp('  GDP...')
    % RHS: Intercept, h lags of Q/Q GDP growth (previously h lags of average GDP growth over h quarters), 
    % h lags of all three subindices
    nfciSubindex_3m_lag.all = [nfciSubindex_3m_lag.leverage nfciSubindex_3m_lag.credit nfciSubindex_3m_lag.risk];
    x_l1qr_nfciSubindex = normalize([gdp_lags, nfciSubindex_3m_lag.all]);
    x_l1qr_nfciSubindex = [ones(length(gdp_lags), 1), x_l1qr_nfciSubindex];
    RHS_names.GDP = [{'intercept', 'QQ_gdp_lags'}, subindices];

    % LHS: h-quarter-ahead GDP growth over h quarters
    y_l1qr_nfciSubindex = normalize(gdp_y);

    %SAVE LHS AND RHS for later
    rhs.(fh).GDP = x_l1qr_nfciSubindex;
    lhs.(fh).GDP = y_l1qr_nfciSubindex;

    %Save LHS date
    lhs.(fh).dates = gdp_dates(h+1:end);
    rhs.(fh).dates = gdp_dates(1:end-h);

    % loop through quantiles
    for t =1:length(Tau)
        tau     = Tau(t);
        % disp('      tau = '+string(tau))
        fn_tau  = sprintf('Q%d', t);      %quantiles 1st to 5th

        % Optimize lambda following B&C 2011 and save
        [ ~ , lambda_opt]  = L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, tau);
        Lambda_opt.(fh).GDP.(fn_tau) = lambda_opt;

        %---------------------------------------------------------------
        % L-1 penalized quantile regression with a selection of lambdas
        % related to optimal lambda. Compute L1 norm and mean tick loss

        temp_Lambda_given_small = zeros(1, S -1);
        temp_Lambda_given_large = zeros(1, S -1);
        
        for s =1:S -1
            temp_Lambda_given_small(:, s)    = lambda_opt/(s +1);      %small lambdas. Divide by s+1 to avoid dividing by 1
            temp_Lambda_given_large(:, s)    = lambda_opt*(s +1);       %large lambdas. Multiply by s+1 to avoid multiplying by 1
        end


        Lambdas = sort([0 lambda_opt temp_Lambda_given_small temp_Lambda_given_large]);
        Lambda_given.(fh).GDP.(fn_tau) = Lambdas;
        idx.Lambda_opt.(fh).GDP.(fn_tau) = find(Lambdas == lambda_opt);

        % preallocate space

        beta = NaN(slength +2, length(Lambdas));      %add one row for intercept and one for lag of GDP
        loss = NaN(1, length(Lambdas));
        l1norm = NaN(1, length(Lambdas));

        parfor l =1:length(Lambdas)

            lambda = Lambdas(l);

            beta(:, l)  = L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, tau, lambda);
            temp_beta   = beta(:, l);

            loss(:, l)  = compute_avg_tickloss_L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, temp_beta, tau);   %get mean tick loss
            l1norm(:, l) =  sum(abs(temp_beta(2:end)));                                % get L-1 norm

        end
        B_givenLambda.(fh).GDP.(fn_tau) = beta;
        loss_givenLambda.(fh).GDP.(fn_tau) = loss;
        L1norm_givenLambda.(fh).GDP.(fn_tau) = l1norm;

    end

    %==========================================================================
    % L1QR ON EACH COMPONENT (C, I, G, NX)
    for f = 1:(flength-1)
        
        fn = Esf_ynames{f};
        % disp('  Series '+string(f)+' of '+string(flength-1)+': '+string(fn)+'...')

        series = chghq.(fn);
        series_dates = dates.(fn)(~isnan(series));
        series = series(~isnan(series));

        seriespred = chg1q.GDP;
        seriespred_dates = dates.GDP(~isnan(seriespred));
        seriespred = seriespred(~isnan(seriespred));

        %==========================================================================
        %Get Regression matrices

        series_y = series((1+h):end);
        series_lags = seriespred(1:end-h);

        %==========================================================================
        % L1QR
        % RHS: intercept, h lags of Q/Q GDP growth, h lags of all three NFCI subindices
        x_l1qr_nfciSubindex = normalize([series_lags, nfciSubindex_3m_lag.all]);
        x_l1qr_nfciSubindex = [ones(length(series_lags), 1), x_l1qr_nfciSubindex]; %#ok<*AGROW>
        RHS_names.(fn) = [{'intercept', 'QQ_gdp_lags'}, subindices];

        % LHS: h-quarter-ahead component growth over h quarters
        y_l1qr_nfciSubindex = normalize(series_y);

        %SAVE LHS AND RHS for later
        rhs.(fh).(fn) = x_l1qr_nfciSubindex;
        lhs.(fh).(fn) = y_l1qr_nfciSubindex;

        % loop through quantiles
        for t =1:length(Tau)

            tau     = Tau(t);
            % disp('      tau = '+string(tau))
            fn_tau  = sprintf('Q%d', t);      %quantiles 1st to 5th

            % Optimize lambda following B&C 2011 and save
            [ ~ , lambda_opt]  = L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, tau);
            Lambda_opt.(fh).(fn).(fn_tau) = lambda_opt;

            %---------------------------------------------------------------
            % L-1 penalized quantile regression with a selection of lambdas
            % related to optimal lambda. Compute L1 norm and mean tick loss

            temp_Lambda_given_small = zeros(1, S -1);
            temp_Lambda_given_large = zeros(1, S -1);

            for s =1:S -1
                temp_Lambda_given_small(:, s)    = lambda_opt/(s +1);      %small lambdas. Divide by s+1 to avoid dividing by 1
                temp_Lambda_given_large(:, s)    = lambda_opt*(s +1);       %large lambdas. Multiply by s+1 to avoid multiplying by 1
            end

            Lambdas = sort([0 lambda_opt temp_Lambda_given_small temp_Lambda_given_large]);
            Lambda_given.(fh).(fn).(fn_tau) = Lambdas;
            idx.Lambda_opt.(fh).(fn).(fn_tau) = find(Lambdas == lambda_opt);

            % preallocate space

            beta = NaN(slength +2, length(Lambdas));      %add one row for intercept and one for lag of Q/Q GDP growth
            loss = NaN(1, length(Lambdas));
            l1norm = NaN(1, length(Lambdas));

            parfor l =1:length(Lambdas)

                lambda = Lambdas(l);

                beta(:, l)  = L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, tau, lambda);
                temp_beta   = beta(:, l);

                loss(:, l)  = compute_avg_tickloss_L1QR(y_l1qr_nfciSubindex, x_l1qr_nfciSubindex, temp_beta, tau);   %get mean tick loss
                l1norm(:, l) =  sum(abs(temp_beta(2:end)));                                % get L-1 norm

            end
            B_givenLambda.(fh).(fn).(fn_tau) = beta;
            loss_givenLambda.(fh).(fn).(fn_tau) = loss;
            L1norm_givenLambda.(fh).(fn).(fn_tau) = l1norm;

        end
    end
end

%% ================================================================================
% SAVE RESULTS TO MAT FILE 
save(fullfile(maindir, 'output', 'beta_L1norm_tickloss.mat'), 'rhs', 'lhs', 'flength', 'horizons', 'h_names', 'series_names', 'RHS_names', 'first_x_date', 'last_x_date',...
     'Tau', 'horizons', 'B_givenLambda', 'Lambda_opt', 'Lambda_given','L1norm_givenLambda', 'loss_givenLambda',...
     'series_names', 'subindices','Esf_ynames','-mat');