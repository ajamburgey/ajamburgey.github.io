function Emed = get_med_MPZ(raw, Y_f, tau, alpha1, alpha2)

%raw = raw quantile regression forecasts
%Y_f = MPZ stacked vector of quantile forecasts
%tau = grid of tau values
%alpha = alpha to evaluate expected shortfall

idx_alpha1 = find(tau == alpha1);
idx_alpha2 = find(tau == alpha2);
[T,k] = size(raw);

Emed = NaN(1, T);
for t = 1:T
    cond_quant_alpha1 = raw(t, idx_alpha1);
    cond_quant_alpha2 = raw(t, idx_alpha2);
    sums_idx = Y_f(t, :) >= cond_quant_alpha1 & Y_f(t, :) <= cond_quant_alpha2;
    sums = sum(Y_f(t, sums_idx));
    delta1 = (alpha2 - alpha1)/sum(sums_idx);
    Emed(t) = 1/(alpha2 - alpha1) * sums * delta1;
end