function spliced_data = splice_aja(old_series, new_series)



%Find first date new series begins
idx_both = find(~isnan(old_series) & ~isnan(new_series));
start = idx_both(1);



back_growth_old = (old_series(1:end-1) - old_series(2:end))./old_series(2:end);



old_splice = NaN(start, 1);

for i = start:-1:1
    if i == start
        old_splice(i) = new_series(start);
    else
        old_splice(i) = old_splice(i+1) + back_growth_old(i)*old_splice(i+1);
    end
end


spliced_data = [old_splice(1:start); new_series(start+1:end)];


end



