function Esf = get_shortfall_MPZ(raw, Y_f, tau, alpha)

%raw = raw quantile regression forecasts
%Y_f = MPZ stacked vector of quantile forecasts
%tau = grid of tau values
%alpha = alpha to evaluate expected shortfall

idx_alpha = find(tau == alpha);
[T,k] = size(raw);

Esf = NaN(1, T);
for t = 1:T
    cond_quant_alpha = raw(t, idx_alpha);
    sums_idx = Y_f(t, :) <= cond_quant_alpha;
    sums = sum(Y_f(t, sums_idx));
    delta1 = alpha/sum(sums_idx);
    Esf(t) = 1/alpha * sums * delta1;
end