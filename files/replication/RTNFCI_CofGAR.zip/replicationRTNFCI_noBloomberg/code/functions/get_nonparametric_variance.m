function V = get_nonparametric_variance(y, x, x_rt, OOSerror_res, OOSerror_unres, h, alpha, R, scheme, eps, direct_b1f1)

% This function estimates the nonparametric variance of the average tick-loss
% differential between nested quantile models from the paper "On the
% Real-Time Predictive Content of Financial Conditions Indices" by 
% Aaron Amburgey and Michael McCracken. In this function assumes both
% models contain an intercept.

% INPUTS
% y (Tx1) = full sample of LHS variable
%
% x (TxN) = full sample of RHS variables for the unrestricted model (assumes the
%       last variable is the additional regressor)
%
% x_rt (Px1) = time series of real-time x endpoints. Do not include intercept 
%
% OOSerror_res (Px1) = OOS forecast errors of the restricted model
%
% OOSerror_unres (Px1) = OOS forecast errors of the unrestricted
% model
%
% h = horizon of forecasts
% 
% alpha = quantile
% 
% R = window size of forecasting scheme
% 
% scheme = the options are "rolling" or "recursive" scheme. This should be
%          selected based on what your forecasting scheme was
%
% eps = set epsilon parameter for C_T. As of now we use 1/40 in "On the
%       Real-Time Predictive Content of Financial Conditions Indices"
%       simulation section. However in the empirical section we use 1/5.
%
% direct_b1f1 = set to 0 or 1. If set to 0 we obtain B_1 and F_1 from B_2
%               and F_2. If set to 1 we estimate these directly. In the
%               paper


% OUTPUT
% V = Nonparametric variance estimate

%--------------------------------------------------------------------------
%addpath('/Users/aaronamburgey/Library/CloudStorage/OneDrive-NorthwesternUniversity/Mike_Aaron_Research/FRED-QD/Programs/Functions/kevinsheppard-mfe_toolbox-45462370b5f0/utility')

%Assertions
assert(length(y) == length(x))
assert(length(OOSerror_res) == length(OOSerror_unres))

%Rearrange x, y, and x_rt if neccessary
if size(y, 1) > size(y, 2)
    y = y';
end
if size(x, 1) > size(x, 2)
    x = x';
end
if size(x_rt, 1) > size(x_rt, 2)
    x_rt = x_rt';
end

%Get Dimensions
dimx = size(x, 1); %Number of X vars
T = length(y); %Length of full sample Y
P = length(OOSerror_res); %Number of OOS forecast periods
pi = P/R;

%Restricted and Unrestricted x (assumes unrestricted model has a single
%extra predictor placed last in the matrix)
x_res = [ones(1, T); x(1:end-1, :)];
x_unres = [ones(1, T); x];

%Regressions on Full Sample
beta_fullsamp_res = qr_standard_ajamod(x_res(2:end, :)', y', ...
    alpha ,'test','wald','method','interior');
beta_fullsamp_unres = qr_standard_ajamod(x_unres(2:end, :)', y', ...
    alpha ,'test','wald','method','interior');

%Full Sample Regression Errors
error_fullsamp_res = y' - x_res'*beta_fullsamp_res;
error_fullsamp_unres = y' - x_unres'*beta_fullsamp_unres;

%J (selection matrix)
J = [eye(dimx), zeros(dimx, 1)]';

%C_T
C_T_1 = 1.06*std(error_fullsamp_res)*T^(-1*eps);
C_T_2 = 1.06*std(error_fullsamp_unres)*T^(-1*eps);

%FROM MIKE'S NOTES FOR ESTIMATING ASYMPTOTIC VARIANCE PDF:

%STEP 1: Get Lamda_hh (based on P/R)
if scheme == "recursive"
    lamda_hh = 2.*(1 -  (1./pi.*log(1 + pi)));
elseif scheme == "rolling" && pi <= 1
    lamda_hh = pi - (pi^2)/3;
elseif scheme == "rolling" && pi > 1
    lamda_hh = 1 - (3*pi)^-1;
end


%STEP 2: Get B_2 (and B_1)
B_2_inv = 0;
for t = 1:T
    B_2_inv = B_2_inv + (abs(error_fullsamp_unres(t)) < C_T_2).*(x_unres(:, t)*x_unres(:, t)');
end
B_2_inv = ((2*C_T_2*T)^-1)*B_2_inv;
B_2 = inv(B_2_inv);

if direct_b1f1 == 1 
    B_1_inv = 0;
    for t = 1:T
        B_1_inv = B_1_inv + (abs(error_fullsamp_res(t)) < C_T_1).*(x_res(:, t)*x_res(:, t)');
    end
    B_1_inv = ((2*C_T_1*T)^-1)*B_1_inv;
    B_1 = inv(B_1_inv);
else
    B_1 = inv(J'*B_2_inv*J);
end

%STEP 3: S_2hh, the long run variance of
%phi(error_fullsamp_unres)*x_unres
phi = (alpha - (error_fullsamp_unres < 0));
maxLag = floor(4*(T/100)^(2/9));
S_2hh = covnw(phi.*x_unres', maxLag+h);

%STEP 4: Get F_2 (and F_1)
%Next we need loop over each origin to get each component of F_2
x_rt_unres = [ones(1, P); x_rt];
x_rt_res = [ones(1, P); x_rt(1:end-1, :)];


F_2 = zeros(dimx+1, 1);
for s = 1:P
    F_2 = F_2 + (x_rt_unres(:, s))*((OOSerror_unres(s) < 0) - alpha);
end
F_2 = (P^-1)*F_2;

if direct_b1f1 == 1
    F_1 = zeros(dimx, 1);
    for s = 1:P
        F_1 = F_1 + (x_rt_res(:, s))*((OOSerror_res(s) < 0) - alpha);
    end
    F_1 = (P^-1)*F_1;
else
    F_1 = (F_2'*J)';
end


%Step 5: Get Variance
V = (lamda_hh*([F_1',-F_2'])*[B_1, zeros(2, 3); zeros(3, 2), B_2]*[J'*S_2hh*J, J'*S_2hh; S_2hh*J, S_2hh]* ...
    [B_1, zeros(2, 3); zeros(3, 2), B_2]*[F_1; -F_2])/P;



end