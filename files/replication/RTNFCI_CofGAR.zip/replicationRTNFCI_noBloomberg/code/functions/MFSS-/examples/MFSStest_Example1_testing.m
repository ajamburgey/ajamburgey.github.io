% Mixed-frequency dynamic factor model 
%
% The data in y is a panel of 5 time series: 
%   - The quarterly log-difference of Real Gross Domestic Product
%   - The monthly log-difference of All Employees: Total Nonfarm Payrolls
%   - The monthly log-difference of Real personal income excluding current transfer receipts
%   - The monthly log-difference of Industrial Production Index
%   - The monthly log-difference of Real Manufacturing and Trade Industries Sales
% The monthly series are normalized have a mean of zero and a standard deviation of one. 
% Data retreived from FRED as of August 2, 2018. 
%
% See Also:
%   pgmtmfss_replication.m - Replication code runner script

data = load('data_panel.mat');
y = data.y;
dates = data.dates;

%% Code Example 1: Estimating a Mixed Frequency Dynamic Factor model
% y is a panel of 5 time series at a monthly base frequency.
% The 1st series in y is quarterly with observations in the 3rd month of the quarter.
Z = [1; nan(4,1)];
d = [nan; zeros(4,1)];
H = diag(nan(5,1));
T = nan;
Q = nan;

ssE = StateSpaceEstimation(Z, H, T, Q, 'd', d);

LB = ssE.ThetaMapping.LowerBound;
UB = ssE.ThetaMapping.UpperBound;
LB.Z(2:5,1) = 0;
LB.T(1,1) = -1;
UB.T(1,1) = 1;
ssE.ThetaMapping = ssE.ThetaMapping.addRestrictions(LB, UB);

accum = Accumulator.GenerateRegular(y, {'avg','','','',''}, [3 1 1 1 1]);
ssEA = accum.augmentStateSpaceEstimation(ssE);



ssML = ssEA.estimate(y);


%Alternatively try to use initial state space too
Z0 = ssML.Z;
H0 = ssML.H;
T0 = ssML.T;
Q0 = ssML.Q;
R0 = ssML.R;
a0 = [0; 0; 1];
P0 = ones(3).*.25;
c0 = ssML.c;
ss0 = StateSpace(Z0, H0, T0, Q0, 'R', R0, 'a0', a0, 'P0', P0, 'c', c0);

ssEA.a0 = a0;
ssEA.P0 = P0;

%Add beta/gamma to ssEA
ssML2 = ssEA.estimate(y, ss0);
