%   This function rebases the splices two series together
%   In general, we have two problems:

%   1. The data do not have the same base year
%   2. The data have some overlap and must be spliced together correctly

%   In this program, we rebase the data and splice two or more series
%data = xlsread(filename,sheetname);

function [new_data] = splice_2(data)
[T,N] = size(data);
%   Determine the overlap period
overlap = ones(T,N - 1);
begin_overlap = zeros(1,N-1);
end_overlap = zeros(1,N-1);
for n = 2 : N
    overlap(:,n - 1) = (ones(T,1) - isnan(data(:,n) - data(:,n-1)));
    begin_overlap(:,n - 1) = find(overlap(:,n - 1) == 1,1,'first');
    end_overlap(:,n - 1) = find(overlap(:,n - 1) == 1,1,'last');
end,
new_data = zeros(T,N-1);
%   The Overlap Method
for n = 2 : N
    recalc_factor = 0;
    if n == 2
        for t = begin_overlap(:,n-1) : end_overlap(:,n-1)
            recalc_factor = recalc_factor + data(t,n) / data(t,n-1);
        end,
        recalc_factor = recalc_factor / (end_overlap(:,n-1) - begin_overlap(:,n-1) + 1);
        new_data(1:begin_overlap(:,n-1) - 1,n-1) = recalc_factor * data(1 : begin_overlap(:,n-1) - 1,n-1);
        new_data(begin_overlap(:,n-1):end_overlap(:,n-1),n-1) = recalc_factor * data(begin_overlap(:,n-1):end_overlap(:,n-1),n - 1);
        new_data(end_overlap(:,n-1) + 1 : end,n-1) = data(end_overlap(:,n-1) + 1 : end,n);
    else
        for t = begin_overlap(:,n-1) : end_overlap(:,n-1)
            recalc_factor = recalc_factor + data(t,n) / new_data(t,n-2);
        end,
        recalc_factor = recalc_factor / (end_overlap(:,n-1) - begin_overlap(:,n-1) + 1);
        new_data(1:begin_overlap(:,n-1) - 1,n-1) = recalc_factor * new_data(1 : begin_overlap(:,n-1) - 1,n-2);
        new_data(begin_overlap(:,n-1):end_overlap(:,n-1),n-1) = recalc_factor * data(begin_overlap(:,n-1):end_overlap(:,n-1),n - 1);
        new_data(end_overlap(:,n-1) + 1 : end,n-1) = data(end_overlap(:,n-1) + 1 : end,n);
    end,
end,

















