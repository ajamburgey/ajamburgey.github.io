function [Fnew, Flags] = get_Flags(F, num_lags)

    Fnew = F(num_lags+1:end);
    Flags = NaN(length(Fnew), num_lags);
    
    
    for i = 1:num_lags
       Flags(:, i) = F(((num_lags-i)+1:end-i)); 
    end
    
       
    
    
end