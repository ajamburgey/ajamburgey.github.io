function keep_idx = find_released_06112021(frequency, current_date, release_times, dates, mondays, tuesdays, thursdays, fridays, busdays)


keep_idx = repmat(NaN(size(dates)), 1, length(release_times));

for i = 1:length(release_times)
    
    
    %Weekly
    if strcmp(frequency, 'Weekly')
        
        if strcmp(release_times(i), {'Available'}) == 1
            keep_idx(:, i) = dates <= current_date;
        elseif strcmp(release_times(i), {'Thursday, 1 Week'}) == 1
            keep_idx(:, i) = dates <= current_date - calweeks(1);
        end
        
        
        
    %Monthly
        
    elseif strcmp(frequency, 'Monthly')
        
        
        if strcmp(release_times(i), {'2nd Thursday'}) == 1
            temp_days = thursdays(month(thursdays) == month(current_date) & year(thursdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'2nd Friday'}) == 1
            temp_days = fridays(month(fridays) == month(current_date) & year(fridays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'2nd Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'1st Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(1) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(1) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'2nd bus day'}) == 1
            temp_days = busdays(month(busdays) == month(current_date) & year(busdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'Last Thursday'}) == 1
            temp_days = thursdays(month(thursdays) == month(current_date) & year(thursdays) == year(current_date));
            if temp_days(end) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(end) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'Last Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(end) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(end) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'Last Friday'}) == 1
            temp_days = fridays(month(fridays) == month(current_date) & year(fridays) == year(current_date));
            if temp_days(end) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(end) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            end
        elseif strcmp(release_times(i), {'1 month, 5th bus day'}) == 1
            temp_days = busdays(month(busdays) == month(current_date) & year(busdays) == year(current_date));
            if temp_days(5) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(5) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        elseif strcmp(release_times(i), {'1 month, 1st Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(1) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(1) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
            
        elseif strcmp(release_times(i), {'1 month, 2nd Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        elseif strcmp(release_times(i), {'1 month, 4th Friday'}) == 1
            temp_days = fridays(month(fridays) == month(current_date) & year(fridays) == year(current_date));
            if temp_days(4) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(4) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        elseif strcmp(release_times(i), {'Current, last bus day'}) == 1
            temp_days = busdays(month(busdays) == month(current_date) & year(busdays) == year(current_date));
            if temp_days(end) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
            elseif temp_days(end) <= current_date
                keep_idx(:, i) = dates <= current_date;
            end
            
        end
        
        
   %Quarterly
        
    elseif strcmp(frequency, 'Quarterly')
        
        
        if strcmp(release_times(i), {'5th bus day'}) == 1
            temp_days = busdays(month(busdays) == month(current_date) & year(busdays) == year(current_date));
            if temp_days(5) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            elseif temp_days(5) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(1);
                
            end
        elseif strcmp(release_times(i), {'1 month, 7th bus day'}) == 1
            temp_days = busdays(month(busdays) == month(current_date) & year(busdays) == year(current_date));
            if temp_days(7) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(7) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);                
            end
        elseif strcmp(release_times(i), {'1 month, 1st Monday'}) == 1
            temp_days = mondays(month(mondays) == month(current_date) & year(mondays) == year(current_date));
            if temp_days(1) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(1) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        elseif strcmp(release_times(i), {'1 month, 1st Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(1) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(1) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        elseif strcmp(release_times(i), {'2 month, 2nd Thursday'}) == 1
            temp_days = thursdays(month(thursdays) == month(current_date) & year(thursdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(4);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            end
        elseif strcmp(release_times(i), {'2 month, 2nd Tuesday'}) == 1
            temp_days = tuesdays(month(tuesdays) == month(current_date) & year(tuesdays) == year(current_date));
            if temp_days(2) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(4);
            elseif temp_days(2) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            end
        elseif strcmp(release_times(i), {'1 month, 3rd Friday'}) == 1
            temp_days = fridays(month(fridays) == month(current_date) & year(fridays) == year(current_date));
            if temp_days(3) > current_date
                keep_idx(:, i) = dates <= current_date - calmonths(3);
            elseif temp_days(3) <= current_date
                keep_idx(:, i) = dates <= current_date - calmonths(2);
            end
        end
        
    end
end