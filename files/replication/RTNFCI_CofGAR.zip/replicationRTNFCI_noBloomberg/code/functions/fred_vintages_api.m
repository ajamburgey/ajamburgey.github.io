% Purpose: pull fred data vintages
% Author: Anna Cole
% Input: fred api key and ticker, both as characters
% Output: time table of observations with a column for each vintage

function data = fred_vintages_api(api_key, mnemonic)
    vintage_dates = webread(['https://api.stlouisfed.org/fred/series/vintagedates?series_id=' mnemonic '&file_type=json&api_key=' api_key]).vintage_dates;
    
    % initialize with most current data
    url = ['https://api.stlouisfed.org/fred/series/observations?series_id=' mnemonic '&file_type=json&api_key=' api_key];
    pull = webread(url);
    dates = datetime({pull.observations.date}'); % Convert from char to datetime
    pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
    all_vintages = timetable(dates, pulled_series_data);
    
    pause(60) % just pulled a vintage to initialize, so wait before running the loop

    wait = 120:119:numel(vintage_dates); % vector representing the points in the loop in which we must wait before pulling more requests from fred
       
    for i = 1:numel(vintage_dates)
            if ismember(i, wait)
                pause(60) % workaround for the fred limit on number of requests pulled at once, cap is 120
            end 
            
            url = "https://api.stlouisfed.org/fred/series/observations?"...
               + "series_id" + "=" + convertCharsToStrings(mnemonic) ...
               + "&" + "vintage_dates" + "=" + convertCharsToStrings(vintage_dates(i)) ...
               + "&" + "file_type" + "=" + "json" ...
               + "&" + "api_key" + "=" + api_key;
            pull = webread(url);
            dates = datetime({pull.observations.date}'); % convert from char to datetime
            pulled_series_data = str2double({pull.observations.value}'); % convert from char to numeric
            temp = timetable(dates, pulled_series_data);
            all_vintages = outerjoin(all_vintages, temp);
    end 

    all_vintages(:, 1) = [];
    all_vintages.Properties.VariableNames = string(datetime(vintage_dates));
    data = all_vintages;
end 


