% SEAS is a simple program that demonstrates the use of the programs in the
% seas directory of the X-13 toolbox. These programs are:
%
% trendfilter.m         Computes a trend (i.e. smoothed) version of the
%                       data. You can choose from many different methods to
%                       do that.
% seasfilter.m          Splits data using splitperiods, smoothes them with
%                       trendfilter, and joins them together again with
%                       joinperiods.
% normalize_seas.m      Computes the difference or the ratio, respectively,
%                       of two series, depending on whether the
%                       decomposition is additive or multiplicative,
%                       respectively. 
% splitperiods.m        Splits the data into their periods. For instance,
%                       with monthly data, split periods makes twelve times
%                       series out of your data, one for each month of the
%                       year. 
% joinperiods.m         Reverse of splitperiods.
% fillholes.m           Linear interpolation of missing values.
% wmean.m               Computes the weighted mean. Similar to Matlab's
%                       conv  command, but with smarter treatment of the
%                       edge of the data.
% kernelweights.m       Computes the weights for a wide range of kernels.
%                       Used by trendfilter.m and seasfilter.m in
%                       conjunction with wmean.m
% fixedseas.m           A rather elaborate program that produces a rather
%                       simple version of seasonal adjustment in which the
%                       seasonal factors are kept fixed over the years.
% x11.m                 An implementation of a much simplified version of
%                       the original X-11 method of the U.S. Census Bureau.
% camplet.m             A form of seasonal adjustment that was recently
%                       developed and that does not produce revisions when
%                       data are added to the time series. It does that
%                       because the smoothing is completely backward
%                       looking (so no centered filters at all). camplet is
%                       separately implemented and does not use the other
%                       tools provided here.
% seas.m                This file. You can experiment with the
%                       implementation in this file, and develop your own
%                       seasonal adjustment routine starting from seas.m.
%
% Usage of seas.m
%   s = seas(data,p)
%   s = seas([dates,data],p)
%   s = seas(...,[type],[name])
%   [s,x] = seas(...)
%
% data is either a column vector or an array with two columns. In that
% case, the left column is a date vactor and the right column is the data
% vector. 
%
% p is the period of the data that is to be filtered out. So, typically,
% with monthly data, for instance, p should be set to 12.
%
% type is either 'additive' or 'multiplicative'. 'additive' implies that
% the seasonal factor will be zero on average and are subtracted from the
% unadjusted data to get to the seasonally adjusted data. If type is
% 'multiplicative' the seasonal factor is one on average, and the data is
% divided by the seasonal factor to get the seasonally adjusted data.
%
% name is a string containing the name of the series.
%
% s contains the output in a struct, x contains that information but packed
% into an x13series object.
%
% NOTE: This file is part of the X-13 toolbox, but it is completely
% independent of the Census X-13 program. It is part of the 'seas' addition
% to the toolbox which allows to implement seasonal filters without using
% the Census Bureau programs.
% The toolbox consists of the following programs, guix, x13, makespec, x13spec,
% x13series, x13composite, x13series.plot,x13composite.plot, x13series.seasbreaks,
% x13composite.seasbreaks, fixedseas, camplet, spr, InstallMissingCensusProgram
% makedates, yqmd, TakeDayOff, EasterDate.
%
% Author  : Yvan Lengwiler
% Version : 1.40
%
% If you use this software for your publications, please reference it as:
%
% Yvan Lengwiler, 'X-13 Toolbox for Matlab, Version 1.40', Mathworks File
% Exchange, 2014-2020.
% url: https://ch.mathworks.com/matlabcentral/fileexchange/49120-x-13-toolbox-for-seasonal-filtering

% History:
% 2020-07-01    Version 1.40    Changed normalize to normalize_seas to
%                               avoid conflict with one of the Mathworks
%                               toolboxes.
% 2018-09-19    Version 1.33    First version of the 'seas' part of the X-13
%                               toolbox.

function [s,x] = seas(data,p,type,name)

    % PARSE ARGS
    
    % -- dates present?
    [nrow,ncol] = size(data);
    if nrow == 1 && ncol > 2
        data = data';
    end
    [nobs,ncol] = size(data); nyears = ceil(nobs/p);
    if ncol > 1
        dates = data(:,1);
        data  = data(:,2:end);
    else
        dates = (1:nobs)';
    end
    
    % -- name present?
    if nargin<4 || isempty(name)
        name = '(no name)';
    end
    
    % -- additive or multiplicative?
    if nargin<3 || isempty(type) || all(isnan(type))
        type = 'multiplicative';
    end
    
    type = validatestring(type,{'additive','multiplicative'});
    ismult = strcmp(type,'multiplicative');
    
    % DO THE WORK
    % There are essentially two places where you need to make a choice, and
    % these choices will determine the shape of the seasonal decomposition.
    % The first is: How do you want to smooth the data to compute the trend.
    % Allowing for a lot  of roughness in the trend produces smaller
    % seasonal factors over all. Enforcing a very smooth trend, on the
    % other hand, will produce a more important role for the seasonal
    % factor. The second decision is how you want to smooth the seasonal
    % deviations over consecutive years. If you allow for a lot of
    % roughness here, the seasonal factors will change quickly from year to
    % year, so that the seasonality might appear rather unstable. On the
    % other hand, you can also keep the seasonal factors completely fixed
    % from one year to the next, but that will come at the cost of
    % increasing the 'unexplained' irregular component and making it more
    % serially correlated.
    
    % -- TR (trend) -->  choice #1
    tr = trendfilter(data,'cma',p,p/2,'mirror',p);    % moving average
    % tr = trendfilter(data,'cma',p,p/2,'forward','mirror',p);    % forward-looking moving average
    % tr = trendfilter(data,'cma',p,p/2,'back','mirror',p);    % backward-looking moving average
    % tr = trendfilter(data,'spencer','mirror',p);    % Spencer's filter
    % tr = trendfilter(data,'henderson',2*p-1,'mirror',p);   % Henderson's filter
    % tr = trendfilter(data,'bongard',2*p-1,'mirror',p);     % Bongard's filter
    % % Rehomme & Ladiray: generalization of Henderson and Bongard
    % tr = trendfilter(data,'rehomme-ladiray',[2*p-1,3,0.5],'mirror',p);
    % lambda = exp(-7.10636 + 5.91863781313348 * log(p));    % Hodrick-Prescott
    % tr = trendfilter(data,'hp',lambda,'mirror',p);
    % % Some common Kernels (more are available) ...
    % tr = trendfilter(data,'triangle',2*p-1,'mirror',p);
    % tr = trendfilter(data,'epanech',2*p-1,'mirror',p);
    % h = ((dates(end)-dates(1)) / (numel(dates)-1)) ./ p;   % cubic spline
    % roughness = 1 ./ (1 + h.^3 / 0.6);
    % tr = trendfilter(data,'spline',roughness,'mirror',p);
    
    % -- SI (deviation of data from trend)
    si = normalize_seas(data,tr,ismult);
    
    % -- SF (seasonal factors)  -->  choice #2
    sf = seasfilter(si,p,'spline',0.1,'mirror',nyears);
    % sf = seasfilter(si,p,'cma',5,4,4,'mirror',nyears);
    % sf = seasfilter(si,p,'hp',1400,'mirror',nyears);
    % sf = seasfilter(si,p,'poly',4,'mirror',nyears);
    % sf = seasfilter(si,p,'henderson',13,'mirror',nyears);
    % sf = seasfilter(si,p,'epanech',5,'mirror',nyears);
    %
    % To get seasonal factors that are fixed over the years, you need to
    % smooth this using a simple average over the whole sample. How you
    % take this average depends on whether you decompose additively or
    % multiplicatively.
    % if ismult
    %     sf = seasfilter(si,p,'reldeviation');   % relative deviation from mean
    % else
    %     sf = seasfilter(si,p,'deviation');      % simple deviation from mean
    % end
    
    % -- SA and IR (seasonally adjusted data and irregular component)
    sa = normalize_seas(data,sf,ismult);
    ir = normalize_seas(sa,tr,ismult);
    
    % In the end, tr should contain the low frequency components of the
    % data, sf should contain the medium frequencies, and ir the high
    % frequencies. sa, the seasonally adjusted data, is the data minus the
    % medium frequencies, or equivalently, the sum of tr and ir. (With
    % multiplicative decomposition, replace the word 'sum' with 'product',
    % and 'difference' with 'ratio').
    
    % COLLECT EVERYTHING
    
    s = struct(...
        'name',     name,   ...
        'p',        p,		...
        'type',     type,	...
        'dates',    dates,	...
        'dat',      data,	...
        'tr',       tr,		...
        'sa',       sa,		...
        'sf',       sf,		...
        'ir',       ir,		...
        'si',       si);
    
    % pack everything into an x13series object if the user has requested it
    % add some spectra to this object
    
    if nargout > 1
    
        x = x13series;
        x.prog  = 'seas.m';
        if ismult
            x.specgiven = x13spec('transform','function','log');
        else
            x.specgiven = x13spec('transform','function','none');
        end
        if ~strcmp(name,'(no name)')
            x.specgiven = x13spec(x.specgiven,'series','title',name);
        end
        x.spec = x13spec(x.specgiven,'series','period',p);
        x.addvariable('dat',dates,data,'dat',1);
        x.addvariable('stn',dates,tr  ,'stn',1);
        x.addvariable('ssa',dates,sa  ,'ssa',1);
        x.addvariable('ssf',dates,sf  ,'ssf',1);
        x.addvariable('ssi',dates,si  ,'ssi',1);
        x.addvariable('sir',dates,ir  ,'sir',1);
        
        warning_state = warning('off','X13TBX:miss_toolbox');
        if ~ismember('ssd',x.listofitems)
            x.addspectrum('dat',1,'ssd', ...
                'Spectrum of first-differenced original data (with Matlab)');
        end
        x.addspectrum('ssa' ,1,'sss', ...
            'Spectrum of first-differenced adjusted (seas)');
        x.addspectrum('sir' ,0,'ssr', ...
            'Spectrum of irregular (seas)');
        warning(warning_state);
    
    end

end
