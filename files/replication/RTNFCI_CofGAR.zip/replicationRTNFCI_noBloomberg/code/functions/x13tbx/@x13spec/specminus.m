% SPECMINUS removes all entries in the second x13spec object from the entries in
% the first x13spec object (provided the section-key-values of the second spec
% are present in the first spec). Consequently, if the first spec is a subset of
% the second spec, an empty x13spec object is returned.
%
% Usage:
%   spec1 = specminus(spec1,spec2)
%   spec1 = specminus(spec1,spec2,type)
%
% type is either 1 or 2 or 3. If type is given, spec1 and spec2 are first
% changed so that they conform the the restrictions of x-11 (type = 1), x-12
% (type = 2), or x-13 (type = 3). If type is anything else or omitted, spec1
% and spec2 are not treated before performing the comparison.
%
% NOTE: This file is part of the X-13 toolbox.
%
% see also guix, x13, makespec, x13spec, x13series, x13composite, 
% x13series.plot,x13composite.plot, x13series.seasbreaks,
% x13composite.seasbreaks, fixedseas, spr, InstallMissingCensusProgram
%
% Author  : Yvan Lengwiler
% Version : 1.34
%
% If you use this software for your publications, please reference it as
%   Yvan Lengwiler, 'X-13 Toolbox for Matlab, Version 1.34', Mathworks File
%   Exchange, 2018.

% History:
% 2018-11-02    Version 1.34    Added type argument.
% 2016-09-94    Version 1.18    First version.

function spec1 = specminus(spec1,spec2,type)

    if nargin < 3
        type = 0;   % do not enforce a type if none is requested
    end
    
    % enforce a specific type
    switch type
        case 1
            spec1 = spec1.enforceX11spec;
            spec2 = spec2.enforceX11spec;
        case 2
            spec1 = spec1.enforceX12spec;
            spec2 = spec2.enforceX12spec;
        case 3
            spec1 = spec1.enforceX13spec;
            spec2 = spec2.enforceX13spec;
        case 4
            spec1 = spec1.enforceSEASspec;
            spec2 = spec2.enforceSEASspec;
    end

    series1 = fieldnames(spec1);
    series2 = fieldnames(spec2);
    accumulKeys = {'save', 'savelog', 'print', 'variables', ...
        'aictest', 'types', 'user', 'usertype'};
    
    ser = intersect(series1,series2);
    for s = 1:numel(ser)
        keys1 = {}; try keys1 = fieldnames(spec1.(ser{s})); catch; end
        keys2 = {}; try keys2 = fieldnames(spec2.(ser{s})); catch; end
        keys = intersect(keys1,keys2);
        for k = 1:numel(keys)
            if ismember(keys{k},accumulKeys)
                val1 = spec1.ExtractRequests(spec1,ser{s},keys{k});
                val2 = spec2.ExtractRequests(spec2,ser{s},keys{k});
                val  = intersect(val1,val2);
                spec1 = spec1.RemoveRequests(ser{s},keys{k},val);
            else
                val1 = spec1.(ser{s}).(keys{k});
                val2 = spec2.(ser{s}).(keys{k});
                if isnumeric(val1); val1 = mat2str(val1); end
                if isnumeric(val2); val2 = mat2str(val2); end
                if isequal(val1,val2)
                    spec1 = x13spec(spec1,(ser{s}),(keys{k}),[]);
                end
            end
        end
        if ~isstruct(spec1.(ser{s}))
            spec1 = x13spec(spec1,ser{s},[],[]);
        end
    end
