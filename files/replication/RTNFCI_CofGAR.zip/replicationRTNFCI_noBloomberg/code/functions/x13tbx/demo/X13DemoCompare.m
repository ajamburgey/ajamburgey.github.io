%% DEMO for X13 Toolbox: comparison of X-13, X-12, X-11, SEAS, FIXEDSEAS, and CAMPLET

%% load the data and perform various seasonal adjustments

disp('Load data');

% U.S. Bureau of Labor Statistics, Civilian Unemployment Rate [UNRATENSA]
% retrieved from unemp, Federal Reserve Bank of St. Louis
try
    % not seasonally adjusted data
    ticker = 'UNRATENSA';
    url = sprintf(['https://research.stlouisfed.org/fred2/series/%s', ...
          '/downloaddata/%s.csv'], ticker, ticker);
    str = webread(url);
    pos    = strfind(str,[char(13),newline]);  % ignore first line
    format = ['%s','%f'];
    cells  = textscan(str(pos(1)+2:end), format, ...
        'delimiter',',', 'treatAsEmpty',{'.'}, 'CollectOutput',1);
    unemp.ticker = ticker;
    unemp.dates  = datenum(cells{1},'yyyy-mm-dd');
    unemp.data   = cells{2};
    remove = (unemp.dates<datenum(1970,1,1));
    unemp.dates(remove) = [];
    unemp.data(remove)  = [];
    % seasonally adjusted data by Census Bureau
    ticker = 'UNRATE';
    url = sprintf(['https://research.stlouisfed.org/fred2/series/%s', ...
          '/downloaddata/%s.csv'], ticker, ticker);
    str = webread(url);
    pos    = strfind(str,[char(13),newline]);  % ignore first line
    format = ['%s','%f'];
    cells  = textscan(str(pos(1)+2:end), format, ...
        'delimiter',',', 'treatAsEmpty',{'.'}, 'CollectOutput',1);
    unempsa.ticker = ticker;
    unempsa.dates  = datenum(cells{1},'yyyy-mm-dd');
    unempsa.data   = cells{2};
    remove = (unempsa.dates<datenum(1970,1,1));
    unempsa.dates(remove) = [];
    unempsa.data(remove)  = [];
catch
    load unemp
end

%% Compute seasonal adjustments

disp('Compute seasonal adjustments');

specadd = {'STOCK','ADD','NO OUTLIERS'};     % specs common to all runs

[~,xs] = seas([unemp.dates,unemp.data],12,'add');
x1 = x13([unemp.dates,unemp.data],makespec('X11','FIXED','CAMPLET', ...
    'series','title','simplified X-11',specadd{:}), 'x-11','-n');
x2 = x13([unemp.dates,unemp.data], ...
    makespec('DEFAULT','series','title','X-12',specadd{:}), 'x-12');
x3 = x13([unemp.dates,unemp.data], ...
    makespec('X','pickmdl','file','pure4.pml', ...
    'series','title','X-13 PICK-X13',specadd{:}));
x3s = x13([unemp.dates,unemp.data], ...
    makespec('S','series','title','TRAMO-SEATS',specadd{:}));
% add official seasonal adjustment to the resul as variable (sao)
x1.addvariable('osa',unempsa.dates,unempsa.data,{'osa'},1, ...
    'Census Bureau seasonal adjustment');
x1.addvariable('osf',unempsa.dates,x1.dat.dat-x1.osa.osa,{'osf'},1, ...
    'Census Bureau seasonal factor');

%% Correlation of adjusted series and seasonal factors

fprintf(' Correlations between different seasonal adjustments\n\n');
all_sa = [x1.osa.osa,x3.d11.d11,x3s.s11.s11,x2.d11.d11,x1.d11.d11, ...
    xs.ssa.ssa,x1.sa.sa,x1.csa.csa];
corr_sa = corr(all_sa);
all_names = {'CENSUS','X13','X13SEATS','X12','X11', ...
    'SEAS','FIXED','CAMPLET'};
corr_sa_tbl = table(corr_sa(:,1),corr_sa(:,2),corr_sa(:,3),corr_sa(:,4), ...
    corr_sa(:,5),corr_sa(:,6),corr_sa(:,7),corr_sa(:,8), ...
    'VariableNames',all_names, 'RowNames',all_names);
disp(corr_sa_tbl);

fprintf(' Correlations between different seasonal factors\n\n');
all_sf = [x1.osf.osf,x3.d10.d10,x3s.s10.s10,x2.d10.d10,x1.d10.d10, ...
    xs.ssf.ssf,x1.sf.sf,x1.csf.csf];
corr_sf = corr(all_sf);
corr_sf_tbl = table(corr_sf(:,1),corr_sf(:,2),corr_sf(:,3),corr_sf(:,4), ...
    corr_sf(:,5),corr_sf(:,6),corr_sf(:,7),corr_sf(:,8), ...
    'VariableNames',all_names, 'RowNames',all_names);
disp(corr_sf_tbl);

%% Add ACF/PACF and spectra of seasonally adjusted series
% This part requires the signal processing and the econometrics toolboxes)

disp('Add ACF, PACF, and spectra');

x1.addacf('sa' ,1,'faa','ACF of FIXED seasonally adjusted');
x1.addpcf('sa' ,1,'fpa','PACF of FIXED seasonally adjusted');
x1.addacf('csa',1,'caa','ACF of CAMPLET seasonally adjusted');
x1.addpcf('csa',1,'cpa','PACF of CAMPLET seasonally adjusted');
x1.addacf('d11',1,'xaa','ACF of X-13 seasonally adjusted');
x1.addpcf('d11',1,'xpa','PACF of X-13 seasonally adjusted');

x1.addspectrum('sa' ,1,'sf1','Spectrum of FIXED adjusted');
x1.addspectrum('ir' ,1,'sf2','Spectrum of FIXED irregular');

x1.addspectrum('csa',1,'sc1','Spectrum of CAMPLET adjusted');

x1.addspectrum('d11',1,'sp1','Spectrum of X-11 adjusted');
x1.addspectrum('d13',1,'sp2','Spectrum of X-11 irregular');

x2.addspectrum('d11',1,'sp1','Spectrum of X-12 adjusted');
x2.addspectrum('d13',1,'sp2','Spectrum of X-12 irregular');

x1.addacf('osa',1,'oaf','ACF of X-13 seasonally adjusted');
x1.addpcf('osa',1,'opf','PACF of X-13 seasonally adjusted');
x1.addspectrum('osa',1,'s2c','Spectrum of X-12 irregular');

%% look at the unfiltered data

disp('View data, trends, and seasonal adjustments');

plot(x3);
title('Unemployment Quota');

figure('Position',[290 76 891 643]);
ah = subplot(4,2,1); plot(ah,x3, 'd12','d11','combined');  title('X-13');
ah = subplot(4,2,2); plot(ah,x3s,'s12','s11','combined'); title('X-13 SEATS');
ah = subplot(4,2,3); plot(ah,x2, 'd12','d11','combined');  title('X-12');
ah = subplot(4,2,4); plot(ah,x1, 'd12','d11','combined');  title('X-11 (simplified)');
ah = subplot(4,2,5); plot(ah,xs, 'stn','ssa','combined');  title('SEAS');
ah = subplot(4,2,6); plot(ah,x1, 'tr','sa','combined');    title('FIXED');
ah = subplot(4,2,7); plot(ah,x1, 'crp','csa', ...
    'combined','selection',[0 0 0 1 0 0 0 0 0 0 0 0 0]);
ylim([0,12]); title('CAMPLET');
ah = subplot(4,2,8); plot(ah,x1,'osa');                   title('CENSUS OFFICIAL ADJUSTMENT');

disp(WrapLines(['The official seasponal factors are rugged because ', ...
    'they are available only one digit after the comma. The noise ', ...
    'is due to the resulting rounding errors.']))

%% graph of the seasonal factors

disp('View seasonal factors');

figure('Position',[451 72 560 648]);

ah = subplot(4,1,1);
plot(ah,x1,'osf','byperiodnomean','quiet');
title('seasonal factors');
legend('CENSUS (official adjustment)'); legend('boxoff');

ah = subplot(4,1,2);
plot(ah,x3,x3s,'d10','s10','combined','byperiodnomean','quiet');
title('');
legend('X-13','X-13 SEATS'); legend('boxoff');

ah = subplot(4,1,3);
plot(ah,xs,x1,'d10','sf','ssf','combined','byperiodnomean','quiet');
title('');
legend('SEAS','X-11 (simplified)','FIXED'); legend('boxoff');

ah = subplot(4,1,4);
plot(ah,x1,'csf','byperiodnomean');
title('');
legend('CAMPLET'); legend('boxoff');

%% graph of some ACF/PACF and spectra

disp('View ACF/PACF and spectra');

fh = figure('Position',[457 62 553 659]);
plot(fh,x1,'s2c','sp1','sf1','sc1','rowwise');
fh = figure('Position',[196 84 1112 643]);
plot(fh,x1,'oaf','opf','xaa','xpa','faa','fpa','caa','cpa', ...
    'layout',[NaN,2]);

%% conclusion

disp(WrapLines([newline,'There is no difference (in this ', ...
    'example) between X-12 and X-13. X-13-SEATS produces somewhat ', ...
    'less volatile seasonal factors. The X-11 algorithm used here is ', ...
    'not the original one, but a simplified version. Still, the ', ...
    'results are not too far off of X-13/X-12 (except for the ', ...
    'edge of the sample, because the simplified X-11 does not use ', ...
    'ARIMA to extend the data). The same is true for SEAS. In fact, ' ...
    'the simple SEAS algorithm turns out to have the highest ', ...
    'correlation with the official adjustment in this example.', ...
    newline]));

disp(WrapLines(['FIXED produces a somewhat different result. ', ...
    'Of course, seasonal factors do not vary at all over time (this ', ...
    'is the defining featur of this algorithm). As a result, the ', ...
    'correlation of the seasonal factors with X-13/X-12 or with the ', ...
    'official adjustment by the CENSUS is a bit lower.',newline]));

disp(WrapLines(['CAMPLET also produces quite a different result. ', ...
    'First of all, the trend is backward looking and has therefore a ', ...
    'phase shift. Moreover, the seasonal factors are quite volatile with ', ...
    'this algorithm.']));
