
function Y_f=QR_aja(tau,X,y,idx_est)
[T,p]=size(X);
k=length(tau);% quantiles
assert(length(idx_est) == T);
%% Do the quantile regressions
beta=zeros(p,k);
for r=1:k
   beta(:,r)=rq_fnm(X(idx_est, :), y(idx_est), tau(r));
end  
%% In-Sample density fit
Q_fit=X*beta;
Q_fit=sort(Q_fit,2);
N=20000;% total sample size 
n=N/(k+1);
Y_f=zeros(T,N);
for j=2:k
    ind=(j-1)*n+1:j*n;
    Y_f(:,ind)=Q_fit(:,j-1)+sparse(1:T,1:T,Q_fit(:,j)-Q_fit(:,j-1))*rand(T,n);
end
sig_l=(Q_fit(:,2)-Q_fit(:,1))./(norminv(tau(2))-norminv(tau(1)));
mu_l=Q_fit(:,1)-sig_l*norminv(tau(1));
Y_f(:,1:n)=mu_l+sparse(1:T,1:T,sig_l)*norminv(tau(1)*rand(T,n));
sig_u=(Q_fit(:,k)-Q_fit(:,k-1))./(norminv(tau(k))-norminv(tau(k-1)));
mu_u=Q_fit(:,k)-sig_u*norminv(tau(k));
Y_f(:,k*n+1:end)=mu_u+sparse(1:T,1:T,sig_u)*norminv(tau(k)+(1-tau(k))*rand(T,n));