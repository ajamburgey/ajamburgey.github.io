function yt   = prepare_missing_nfci(rawdata,tcode,macode)
% =========================================================================
% DESCRIPTION: 
% This function transforms raw data based on each series' transformation
% code.
%
% -------------------------------------------------------------------------
% INPUT:
%           rawdata     = raw data 
%           tcode       = transformation codes for each series
%           macode      = moving average codes for series that apply
%
% OUTPUT: 
%           yt          = transformed data
%
% -------------------------------------------------------------------------
% SUBFUNCTION:
%           transxf:    transforms a single series as specified by a 
%                       given transfromation code
%
% =========================================================================
% APPLY TRANSFORMATION:
% Initialize output variable
yt        = [];                                     

% Number of series kept
N = size(rawdata,2);                         

% Perform transformation using subfunction transxf (see below for details)
for i = 1:N
    dum = transxf(rawdata(:,i),tcode(i), macode(i));
    yt    = [yt, dum];
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SUBFUNCTION

function y=transxf(x,tcode, macode)
% =========================================================================
% DESCRIPTION:
% This function transforms a single series (in a column vector)as specified
% by a given transfromation code.
%
% -------------------------------------------------------------------------
% INPUT:
%           x       = series (in a column vector) to be transformed
%           tcode   = transformation code (1-7)
%           macode  = series ma length (used for MA transformation)
%
% OUTPUT:   
%           y       = transformed series (as a column vector)
%
% =========================================================================
% SETUP:
% Number of observations (including missing values)
n=size(x,1);
 
% Value close to zero 
small=1e-6;

% Allocate output variable
y=NaN*ones(n,1);

% =========================================================================

tcode = tcode{1};

% TRANSFORMATION: 
% Determine case 1-7 by transformation code
switch(tcode)
    
  case 'LV' % Level (i.e. no transformation): x(t)
    y=x;

  case 'DLV' % First difference: x(t)-x(t-1)
    y(2:n)=x(2:n,1)-x(1:n-1,1);
  
  
  case 'DLN' % First difference of natural log: ln(x)-ln(x-1)
    if min(x) > small
        x=log(x);
        y(2:n)=x(2:n)-x(1:n-1);
    end
   
  case 'DLNQ' % 13-Week Log First Difference: ln(x)-ln(x-13)
    if min(x) > small
        x=log(x);
        y(14:n)=x(14:n)-x(1:n-13);
    end
    
  case 'LVMA' % Level Relative to MA
      ma_length = macode;
      y_ma = movmean(x, [ma_length-1 0]);
      y(ma_length:end) = x(ma_length:end) - y_ma(ma_length:end);
    
    
    
end
end
