function avg_tickloss = compute_avg_tickloss_L1QR(Y, X, beta, tau)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% Purpose of this function %%%%%%%%%%%%%%%%%%%%%%%%
%This function computes average tick loss from the given matrix of predictor data,
% vector of predictand data, parameter estimate beta's obtained
% from fitting a L-1 penalized quantile regression for the quantile index tau
% using these data 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Input description %%%%%%%%%%%%%%%%%%%%%%
%Y is the Tx1 vector of predictand data
%X is the Txp matrix of predictor data (where p is the number of
%predictors)
%beta is L1QR parameter estimate (which minimizes tick loss)
%tau is the quantile index

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Parameters for computing tickloss %%%%%%%%%%%%%%%%%%
T = size(Y, 1);                  %sample size
assert(T == size(X, 1))          %Y and X must have the same number of rows

d = zeros(1, T);    %preallocate space

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Loop for computing tickloss %%%%%%%%%%%%%%%%%%%%
for t =1:T
    y_t = Y(t, 1);

    if X(t,1) ~= 1
        x_t = [1 X(t, :)];      %add intercept if not already present

    else 
        x_t = X(t, :);
    end

    assert(size(x_t, 2) == size(beta, 1),...
        'Coefficient and predictor vectors have mismatched dimensions, check that regression included intercept')

    u = y_t - x_t*beta;     %error term

    if u < 0                % indicator: I(u < 0)
        I = 1;
    else
        I = 0;
    end

    d(1, t) = (tau - I)*u;

end

avg_tickloss = mean(d);

end