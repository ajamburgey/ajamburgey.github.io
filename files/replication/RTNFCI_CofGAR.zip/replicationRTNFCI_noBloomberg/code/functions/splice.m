%   This function rebases the splices two series together
%   In general, we have two problems:

%   1. The data do not have the same base year
%   2. The data have some overlap and must be spliced together correctly

%   In this program, we rebase the data and splice two or more series
%data = xlsread(filename,sheetname);

function [new_data] = splice(data,freq)
[T,N] = size(data);
%   Determine the overlap period
overlap = ones(T,N - 1);
begin_overlap = zeros(1,N-1);
end_overlap = zeros(1,N-1);
NEW_BASE = zeros(1,N-1);
for n = 2 : N
    overlap(:,n - 1) = (ones(T,1) - isnan(data(:,n) - data(:,n-1)));
    begin_overlap(:,n - 1) = find(overlap(:,n - 1) == 1,1,'first');
    end_overlap(:,n - 1) = find(overlap(:,n - 1) == 1,1,'last');
    NEW_BASE(:,n-1) = ceil((end_overlap - begin_overlap)/2) + begin_overlap;
end,


%freq = 'M';
if freq == 'M'
    freq_n = 12;
elseif freq == 'Q'
    freq_n = 4;
elseif freq == 'W'
    freq_n = 52;
else
    error('wrong frequency')
end,

%   The first problem is to rebase the data
%   To do this, we need to define a base year that is in the overlap period
%   Once we have a base year for the spliced samaple, we can rebase

ann_data = zeros(floor(T/freq_n),N);
fact = zeros(size(ann_data));
rebased_data = zeros(size(data));
for n = 1 : N
    %   We want to convert the data to annual first
    %ann_data(:,n) = data(:,n);
    [ann_data(:,n)] = annualize(data(:,n),freq_n);
    %   Compute the basing factor
    fact(:,n) = 100 * ann_data(:,n) / ann_data(NEW_BASE/freq_n,n);
    count = 1;
    tt = 1;
    for t = 1 : T
        rebased_data(t,n) = data(t,n) * fact(tt,n);
        count = count + 1;
        if count == freq_n
            tt = tt + 1;
        end,
    end,
end,

%   Once the data is rebased, we can compare the series


new_data = zeros(T,1);
%   The Overlap Method
for n = 2 : N
    recalc_factor = 0;
    for t = begin_overlap(:,n-1) : end_overlap(:,n-1) 
        recalc_factor = recalc_factor + data(t,n) / data(t,n-1);
    end,
    recalc_factor = recalc_factor / (end_overlap(:,n-1) - begin_overlap(:,n-1) + 1);
    new_data(1:end_overlap,1) = recalc_factor * rebased_data(1:end_overlap(:,n-1),n - 1);
    new_data(end_overlap + 1 : end,1) = rebased_data(end_overlap(:,n-1) + 1 : end,n);
end,


















