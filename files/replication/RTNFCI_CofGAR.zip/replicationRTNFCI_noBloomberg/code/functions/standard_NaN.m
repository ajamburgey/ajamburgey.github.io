function x=standard_NaN(yy,mask);
[T,N]=size(yy);
mu=repmat(nanmean(yy),T,1);
sd=repmat(nanstd(yy),T,1);
x=(yy-mu)./sd;
