% This script calculates the OOS joint shortfall of one-quarter ahead GDP
% growth and each component of GDP using the unrestricted model (e.g.,
% intercept, lagged gdp, lagged NFCI) to form conditional forecasts of
% each, and a t-copula to map the joint PDF structure.

clearvars -except maindir vintage_max R api_key
close all
rng(5)

%% Specifications
input = fullfile(maindir, 'data', 'transformed');
horizons = [1 4];  % Choose horizon
h_sheets = ["1Q", "2Q", "3Q", "4Q"]; %Don't Change this, it helps automate the reading in of the excel file tabs
h_names = {'h1', 'h4'};

series_names = {'GDP', 'C', 'I', 'G', 'X', 'M', 'NX', 'CNDUR', 'CDUR', 'CSER' 'INRES', 'IRES'}; 

flength = length(series_names);
Esf_ynames = series_names(2:end);

last_origin_date = dateshift(vintage_max, "start", "quarter")+calmonths(1);
last_x_date = last_origin_date-calquarters(1);
first_x_date = datetime(1973, 1, 1); %Do not change, this is the first date that we have NFCI information for earlier vintages

%==========================================================================
%Preallocate, then start loop over the two horizons

for i = 1:2
    
    h = horizons(i);
    fh = h_names{i};
    
    fprintf('   |-- Getting '+string(h)+'Q-Ahead Results...\n')
    
    % Determine the first possible forecast target date based on vintage availability (could be later depending on data availability and window size)
    first_target_date = datetime(1988, 1, 1) + calquarters(h-1);
    first_vintage_date = first_target_date + calmonths(1) - calquarters(h-1); %Do not change this, it sets the first vintage date
       
    %==========================================================================
    % Read in data 
    for f = 1:flength % Loop over GDP and series
        fn_series = series_names{f};

        % Predictand Series
        temp = readcell(fullfile(input, fn_series, "pchg_vintages_" + num2str(h) + "Q.txt"));
        raw_chghq.(fn_series) = double(string(temp(2:end, 2:end)));
        raw_vintage_dates.(fn_series) = datetime(string(temp(1, 2:end)));
        raw_dates.(fn_series) = datetime(string(temp(2:end, 1)));
        raw_vintage_dates.(fn_series)(raw_vintage_dates.(fn_series) == datetime(2019, 2, 28)) = datetime(2019, 1, 31); %Cheat here because we didn't have a january release :(
        
        % Predictor Series (dates should be the same as h1)
        temp = readcell(fullfile(input, fn_series, 'pchg_vintages_1Q.txt'));
        raw_chg1q.(fn_series) = double(string(temp(2:end, 2:end)));
        
        % Level (dates should be the same as h1)
        temp = readcell(fullfile(input, fn_series, 'level_vintages.txt'));
        raw_level.(fn_series) = double(string(temp(2:end, 2:end)));
    end
    
    % 3-Month Averaged RTNFCI Vintages
    temp = readcell(fullfile(maindir, 'data', 'raw', 'nfci_quarterly.csv'));
    raw_level.rtnfci_3mth = double(string(temp(2:end, 2:end)));
    raw_vintage_dates.rtnfci_3mth = datetime(string(temp(1, 2:end)));
    raw_dates.rtnfci_3mth = datetime(string(temp(2:end, 1)));
   
    %==========================================================================
    % Clean Data
    for f = 1:flength % Loop over GDP and series
        fn = series_names{f};
        idx.(fn) = raw_dates.(fn) >= first_x_date & raw_dates.(fn) <= last_x_date;
        dates.(fn) = raw_dates.(fn)(idx.(fn));
        idx_vintage.(fn) = raw_vintage_dates.(fn) >= first_vintage_date - calmonths(1) & raw_vintage_dates.(fn) < last_origin_date;
        vintage_dates.(fn) = raw_vintage_dates.(fn)(idx_vintage.(fn));
        chghq.(fn) = raw_chghq.(fn)(idx.(fn), idx_vintage.(fn));
        chg1q.(fn) = raw_chg1q.(fn)(idx.(fn), idx_vintage.(fn));
        level.(fn) = raw_level.(fn)(idx.(fn), idx_vintage.(fn));
    end
    
    %3-Month Averaged RTNFCI Vintages
    idx.rtnfci_3mth = raw_dates.rtnfci_3mth >= first_x_date & raw_dates.rtnfci_3mth <= last_x_date;
    dates.rtnfci_3mth = raw_dates.rtnfci_3mth(idx.rtnfci_3mth);
    idx_vintage.rtnfci_3mth = raw_vintage_dates.rtnfci_3mth >= first_vintage_date - calmonths(1) & raw_vintage_dates.rtnfci_3mth < last_origin_date;
    vintage_dates.rtnfci_3mth = raw_vintage_dates.rtnfci_3mth(idx_vintage.rtnfci_3mth);
    level.rtnfci_3mth = raw_level.rtnfci_3mth(idx.rtnfci_3mth, idx_vintage.rtnfci_3mth);
    
    % Assertions
    for f = 1:flength
        fn = series_names{f};
        assert(length(dates.rtnfci_3mth) == length(dates.(fn)));
        assert(length(vintage_dates.rtnfci_3mth) == length(vintage_dates.(fn)));
    end
    
    %==========================================================================
    %Determine Origins, Targets, and Preallocate
    
    %Origins
    origins.(fh) = first_vintage_date:calmonths(3):last_origin_date;
    origins.(fh) = origins.(fh)(origins.(fh) >= vintage_dates.rtnfci_3mth(1) & origins.(fh) <= (vintage_dates.rtnfci_3mth(end) + calmonths(1)));
    
    num_obs_byvintage = sum(~isnan(level.rtnfci_3mth));
    origins.(fh) = origins.(fh)(num_obs_byvintage >= R + h);
    
    %Targets
    targets.(fh) = (origins.(fh) - calmonths(1) + calquarters(h-1))'; %Note that for realized dates we call Q1 Jan and so on, but our origins.(fh) are first month into the quarter.
    
    for f = 1:flength
        fn = series_names{f};
        idx_vintage2.(fn) = vintage_dates.(fn) >= origins.(fh)(1) - calmonths(1) & vintage_dates.(fn) <= origins.(fh)(end);
        vintage_dates.(fn) = vintage_dates.(fn)(idx_vintage2.(fn));
        chghq.(fn) = chghq.(fn)(:, idx_vintage2.(fn));
        chg1q.(fn) = chg1q.(fn)(:, idx_vintage2.(fn));
        level.(fn) = level.(fn)(:, idx_vintage2.(fn));        
    end
    
    idx_vintage2.rtnfci_3mth = vintage_dates.rtnfci_3mth >= origins.(fh)(1) - calmonths(1) & vintage_dates.rtnfci_3mth <= origins.(fh)(end);
    vintage_dates.rtnfci_3mth = vintage_dates.rtnfci_3mth(idx_vintage2.rtnfci_3mth);
    level.rtnfci_3mth = level.rtnfci_3mth(:, idx_vintage2.rtnfci_3mth);
        
    %Assertions
    for f = 1:flength
        fn = series_names{f};
        assert(length(dates.rtnfci_3mth) == length(dates.(fn)));
        assert(length(vintage_dates.rtnfci_3mth) == length(vintage_dates.(fn)));
    end
    assert(length(vintage_dates.rtnfci_3mth) == length(origins.(fh)))

    %==========================================================================
    %Get Copula hyperparameters

    gdp = chghq.GDP(:, end);
    gdp_dates = dates.GDP(~isnan(gdp));
    gdp = gdp(~isnan(gdp));
    
    idx_cop = gdp_dates < datetime(2020, 1, 1);

    u = ksdensity(gdp(idx_cop),gdp(idx_cop),'function','cdf');

    for f = 1:(flength-1)
        fn = Esf_ynames{f};
        series = chghq.(fn)(:, end);
        series_dates = dates.(fn)(~isnan(series));
        series = series(~isnan(series));        
        v = ksdensity(series(idx_cop),series(idx_cop),'function','cdf');
        [Rho,nu] = copulafit('t',[u v],'Method','ML');
        Rhos.(fn).(fh) = Rho;
        nus.(fn).(fh) = nu;
    end
    
    %% ========================================================================
    %==========================================================================
    %OOS FORECASTING
    %==========================================================================
    %==========================================================================
    
    %Preallocate
    O = length(origins.(fh));
    tau=0.05:.05:0.95;
    
    Esf_temp = NaN(O, flength-1);
    
    series_lvls_temp = NaN(O, flength-1);
    gdp_lvls.(fh) = NaN(O, 1);
    
    %Start loop over origins
    for o = 1:O

        fprintf('   |   |-- Origin '+string(o)+' of '+string(length(origins.(fh)))+'...\n')
        
        target = targets.(fh)(o);
        origin = origins.(fh)(o);
        
        gdplevel = level.GDP(:, o);
        gdplevel = gdplevel(~isnan(gdplevel));
        gdp_lvls.(fh)(o) = gdplevel(end);
        
        gdp = chghq.GDP(:, o);
        gdp_dates = dates.GDP(~isnan(gdp));
        gdp = gdp(~isnan(gdp));
        
        gdppred = chg1q.GDP(:, o);
        gdppred_dates = dates.GDP(~isnan(gdppred));
        gdppred = gdppred(~isnan(gdppred));
        
        rtnfci_3mth = level.rtnfci_3mth(:, o);
        rtnfci_3mth_dates = dates.rtnfci_3mth(~isnan(rtnfci_3mth));
        rtnfci_3mth = rtnfci_3mth(~isnan(rtnfci_3mth));
        
        gdp_y = gdp((1+h):end);
        gdp_cur = gdppred(end);
        gdp_lags = gdp(1:end-h);
        rtnfci_3mth_lags = rtnfci_3mth(1:end-h);
        rtnfci_3mth_cur = rtnfci_3mth(end);
        
        %==========================================================================
        %Get Estimation indices in case we include the covid-19 period
        
        idx_est = gdp_dates((h+1):end) < datetime(2020, 1, 1);
        idx_cop = gdp_dates < datetime(2020, 1, 1);
        
        %==========================================================================
        %Get GDP forecasts
        
        % With NFCI
        % Do quantile regressions and get OOS forecasts
        k=length(tau);
        qar1_rtnfci = zeros(1, k);
        x_qar1_rtnfci = [ones(length(gdp_lags), 1), gdp_lags, rtnfci_3mth_lags];
        for r=1:k
            beta_rtnfci=rq_fnm(x_qar1_rtnfci(idx_est, :), gdp_y(idx_est), tau(r));
            qar1_rtnfci(1, r) = [1 gdp_cur rtnfci_3mth_cur]*beta_rtnfci;
        end
        
        % MPZ
        Y_f_rtnfci=MPZ_density(tau,qar1_rtnfci);
        Esf_GDP.(fh)(o) = get_shortfall_MPZ(qar1_rtnfci, Y_f_rtnfci, tau, 0.05);
        
        %==========================================================================
        %Start loop over series
        parfor f = 1:(flength-1)
            
            % disp('Series '+string(f)+' of '+string(flength-1)+'...')
            
            fn = Esf_ynames{f};
            
            serieslevel = level.(fn)(:, o);
            serieslevel = serieslevel(~isnan(serieslevel));
            series_lvls_temp(o, f) = serieslevel(end);
            
            series = chghq.(fn)(:, o);
            series_dates = dates.(fn)(~isnan(series));
            series = series(~isnan(series));
            
            seriespred = chg1q.GDP(:, o);
            seriespred_dates = dates.GDP(~isnan(seriespred));
            seriespred = seriespred(~isnan(seriespred));
            
            
            %==========================================================================
            %Fit Unconditional Copula between GDP and Series
            u = ksdensity(gdp(idx_cop),gdp(idx_cop),'function','cdf');
            v = ksdensity(series(idx_cop),series(idx_cop),'function','cdf');
                        
            %Get grid of values in PDF
            grid = 0.005:0.005:0.995;
            [u1,u2] = meshgrid(grid,grid);
            z = copulapdf('t',[u1(:),u2(:)],Rhos.(fn).(fh), nus.(fn).(fh));
            z_rs = reshape(z, 199, 199);
            
            %get slice where grid <= 0.05 (i.e., lower tail)
            idx_slice_sf = grid <= 0.05;
            u_slice_sf = grid(idx_slice_sf);
            z_slice_sf = z_rs(idx_slice_sf, :);
                              
            %==========================================================================
            %Get Regression matrices
            
            series_y = series((1+h):end);
            series_cur = seriespred(end);
            series_lags = seriespred(1:end-h);
            
            %==========================================================================
            %Forecasts that include NFCI
            
            %QAR1 + RTNFCI 3-Month Avg
            % Do quantile regressions and get OOS forecasts
            k=length(tau);
            qar1_rtnfci = zeros(1, k);
            x_qar1_rtnfci = [ones(length(series_lags), 1), series_lags, rtnfci_3mth_lags];
            for r=1:k
                beta=rq_fnm(x_qar1_rtnfci(idx_est, :), series_y(idx_est), tau(r));
                qar1_rtnfci(1, r) = [1 series_cur rtnfci_3mth_cur]*beta;
            end
            Y_f_series=MPZ_density(tau,qar1_rtnfci); % MPZ
            
            %Get Joint Expected Shortfall
            y_slice = NaN(size(z_slice_sf));
            yi = NaN(size(z_slice_sf));
            for d = 1:length(u_slice_sf)
                [y_slice(d, :), yi(d, :)] = ksdensity(Y_f_series, u2(:, d), 'function', 'icdf');
            end
            
            %fix strange case for imports where inverse CDF doesn't
            %convergeif needed (just set both y and z slices to zero so we
            %don't count in ESF computation).
            if h == 4 && strcmp(Esf_ynames{f}, 'M') && origin == datetime(1992, 11, 1)
                for d = 1:width(y_slice)
                    if y_slice(1, d) <= -100
                        y_slice(:, d) = 0;
                        z_slice_sf(:, d) = 0;
                        fprintf('   |   |   |-- Removed failed inverse CDF case.\n')
                    end
                end
            end

            Esf_temp(o, f) = sum(sum(y_slice.*z_slice_sf))./sum(sum(z_slice_sf));
           
        end
    end
    
    series_lvls.(fh) = series_lvls_temp;
    Esf.(fh) = Esf_temp;
    
    delete(gcp('nocreate'))
    
end

%Save results to a .mat file for later
outmat = fullfile(maindir, 'output', 'decomp_pchg.mat');
save(outmat)

