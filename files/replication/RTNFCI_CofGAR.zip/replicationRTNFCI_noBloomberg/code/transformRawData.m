% Purpose: Get Vintages and Realizations 

clearvars -except maindir vintage_max api_key
close all

%% Set parameters
files =     [{'RCONDQvQd.txt'       }    {'RCONNDQvQd.txt'      }    {'RCONQvQd.txt'        }    {'RCONSQvQd.txt'       }    {'REXQvQd.txt'         }    {'RGQvQd.txt'          }...
    {'RIMPQvQd.txt'        }    {'ROUTPUTQvQd.txt'     }    {'rinvbfQvQd.txt'      }    {'rinvresidQvQd.txt'   }];

% Date Cutoff
date_min = datetime(1971, 1, 1); % do not change this
date_max = dateshift(vintage_max, "start", "quarter")-calquarters(1); % set date max to the first day of the quarter behind the maximum vintage date
vintage_min = datetime(1988, 1, 1); % do not change this

% Correspondence between philly fed naming convention and ours
shortnames= [ ["CNDUR" "CDUR" "CSER" "INRES" "IRES" "X" "M" "GDP" "C" "G"]',...
  append(["RCONND" "RCOND" "RCONS" "rinvbf" "rinvresid" "REX" "RIMP" "ROUTPUT" "RCON" "RG" ]', "QvQd.txt")];
shortnames = [shortnames; ["I", "gdpic1_quarterly.txt"]]; % add the only non-philly fed file that needs transforming

% Define patterns for cleaning up column names in philly fed files
pat_year = digitsPattern(2);

% Define horizons for percent change calculations
horizons = [1,4];

%% Grab growth, advanced, and realized
for s = 1:length(files)

    input_name = files{s};
    out_series = convertStringsToChars(shortnames(shortnames(:, 2)==input_name, 1));
    outfolder = [fullfile(maindir, 'data', 'transformed', out_series)];

    % Load in Series and keep neccessary vintages
    raw = readcell(input_name);
    if ~strcmp(out_series, 'I') % data cleaning process for philly fed files (all but INV which is originally from FRED)
        vintage_txt = convertCharsToStrings(raw(1, 2:end));
        date_txt = convertCharsToStrings(raw(2:end, 1));
        raw = double(string(raw(2:end, 2:end))); % convert raw data from cell to double
        
        % Extract vintage year and quarter, combine to vintage dates 
        vintage_year = extract(vintage_txt, pat_year);
        vintage_q = string(extractAfter(vintage_txt, digitsPattern(2)+"Q")); %get quarter
        vintage_yq = append("Q", vintage_q, "-", vintage_year); % year-quarter string
        vintages = datetime(vintage_yq, 'InputFormat', "QQQ-yy", 'pivotYear', 1950); % year-quarter string to datetime
        vintages = dateshift(vintages, 'end', 'month');
        
        % Extract observation year and quarter, combine to observation dates 
        date_year = extractBefore(date_txt, ":Q");
        date_q = string(extractAfter(date_txt, ":Q")); % get quarter
        date_yq = append("Q", date_q, "-", date_year); % year-quarter string
        date = datetime(date_yq, 'InputFormat', "QQQ-yyyy"); % year-quarter string to datetime
    else 
        vintages = datetime(string(raw(1, 2:end))); % get vintages and convert from cell
        vintages = dateshift(vintages, 'end', 'month');
        date = datetime(string(raw(2:end, 1)));
        raw = double(string(raw(2:end, 2:end))); % convert raw data from cell to double
    end 
    
    % Define vintages to keep 
    keep_vintage = vintages >= vintage_min;
    vintages = vintages(keep_vintage); 
    raw = raw(:, keep_vintage);

    % Fill in Missing values with values from next vintage where relevant
    for i = 2:length(vintages)-1
        idx_temp = date <= (vintages(i) - calmonths(2));
        idx_fill = isnan(raw(:, i)) & idx_temp;
        raw(idx_fill, i) = raw(idx_fill, i+1);

        idx_fill2 = isnan(raw(:, i)) & idx_temp;
        raw(idx_fill2, i) = raw(idx_fill2, i-1);
    end
    
    % Cleaned Dates
    idx_date = find(date >= date_min & date <= date_max);
    date_clean = date(idx_date);

    % Growth
    series_growth = [NaN(1, size(raw, 2)); (raw(2:end, :) - raw(1:end-1, :))./raw(1:end-1, :)*4*100];

    % Levels
    if or(strcmp(out_series, 'X'), strcmp(out_series, 'M'))
        netCalc.(out_series) = array2timetable(raw, 'VariableNames',string(vintages), 'RowTimes',date); % save for special NX calc
    end 

    series_lvl = array2timetable(raw(idx_date, :), 'VariableNames',string(vintages), 'RowTimes',date_clean); % use cleaned dates and convert to timetable
    writetimetable(series_lvl, fullfile(outfolder, 'level_vintages.txt')); % export

    % Growth Rate Vintages
    for t = 1:numel(horizons)
        h = horizons(t);
        
        series_growth_hq = (4*100/h)*(raw(1+h:end, :) - raw(1:end-h, :))./raw(1:end-h, :); % calculate growth rates
        series_growth_hq = [NaN(h, width(raw)); series_growth_hq]; % fill in h rows with NaN values 
        series_growth_hq = series_growth_hq(idx_date, :); % use clean dates
        series_growth_hq = array2timetable(series_growth_hq, "VariableNames",string(vintages), "RowTimes",date_clean); % convert to timetable
        
        filename = fullfile(outfolder, "pchg_vintages_" + string(h)+'Q.txt');
        writetimetable(series_growth_hq, filename) % export
    end

    % Single time series of advance estimates
    % Levels
    idx_advance = find(~isnan(series_growth(:, 1)));
    idx_advance = idx_advance(end);

    date_advance = date(idx_advance:end);
    series_level_advance = diag(raw(idx_advance:end, :));
    series_level_advance = array2timetable(series_level_advance, "RowTimes",date_advance);
    writetimetable(series_level_advance, fullfile(outfolder, 'level_realized_advance.txt')) % export

    % Calculate and export results for h = 1 and 4
    for t = 1:numel(horizons)
        h = horizons(t);
        series_growth_hq = (4*100/h)*(raw(1+h:end, :) - raw(1:end-h, :))./raw(1:end-h, :);
        series_growth_hq = [NaN(h, width(raw)); series_growth_hq];
        series_growth_hq = series_growth_hq(idx_advance:end, :);
        series_growth_hq = diag(series_growth_hq);
        series_growth_hq = array2timetable(series_growth_hq, "RowTimes",date_advance); % convert to timetable
        
        filename = fullfile(outfolder, "pchg_realized_advance_" + string(h)+'Q.txt');
        writetimetable(series_growth_hq, filename) % export
    end
end


%% Special transformation for net exports to avoid a simple calculation of exports-imports that can be positive and negative (creating noisy pct changes)
clearvars -except maindir vintage_max date_min date_max horizons netCalc vintMethod vintage_choice api_key
outfolder = fullfile(maindir, 'data', 'transformed', 'NX');

% Get export and import data
raw1 = netCalc.X;
vintages1 = datetime(string(raw1.Properties.VariableNames)); % get vintages and convert from cell
vintages1 = dateshift(vintages1, 'end', 'month');
date1 = raw1.Properties.RowTimes;
raw1 = raw1{:, :}; 

raw2 = netCalc.M;
vintages2 = datetime(string(raw2.Properties.VariableNames)); % get vintages and convert from cell
vintages2 = dateshift(vintages2, 'end', 'month');
date2 = raw2.Properties.RowTimes;
raw2 = raw2{:, :}; 

% Cleaned Dates
assert(length(raw2) == length(raw2) && size(raw2, 2) == size(raw2, 2))
assert(isequal(vintages1, vintages2))
assert(isequal(date1, date2))
vintages = vintages1; % arbitrary choice since the assertions above passed
date = date1; 
idx_date = find(date >= date_min & date <= date_max);
date_clean = date(idx_date);

% Levels
series_lvl = raw1(idx_date, :) - raw2(idx_date, :);
series_lvl = array2timetable(series_lvl, "VariableNames",string(vintages), "RowTimes",date_clean);
writetimetable(series_lvl, fullfile(outfolder, 'level_vintages.txt')); % export

% Continuously Compounded Annual Rate of Change
series_1_growth = 400*(raw1(2:end, :) - raw1(1:end-1, :))./abs(raw1(1:end-1, :));
series_1_weight = raw1(1:end-1, :);
series_2_growth = 400*(raw2(2:end, :) - raw2(1:end-1, :))./abs(raw2(1:end-1, :));
series_2_weight = raw2(1:end-1, :);

series_growth = ...
    [NaN(1, size(raw1, 2)); (series_1_growth.*series_1_weight - series_2_growth.*series_2_weight)./(series_1_weight + series_2_weight)]; % special transform by weights

for t = 1:numel(horizons)
    h = horizons(t);    
    
    series_growth_hq = [NaN(h, size(raw1, 2)); (4*100/h)*((raw1(1+h:end, :) - raw1(1:end-h, :)) - (raw2(1+h:end, :) - raw2(1:end-h, :)))./(raw1(1:end-h, :) + raw2(1:end-h, :))];
    series_growth_hq = series_growth_hq(idx_date, :);
    series_growth_hq = array2timetable(series_growth_hq, "VariableNames",string(vintages), "RowTimes",date_clean); % convert to timetable

    filename = fullfile(outfolder, "pchg_vintages_" + string(h)+'Q.txt');
    writetimetable(series_growth_hq, filename) % export
end

% Single time series of advance estimates
% Levels
idx_advance = find(~isnan(series_growth(:, 1)));
idx_advance = idx_advance(end);

date_advance = date(idx_advance:end);
series_level_advance = diag(raw1(idx_advance:end, :)) - diag(raw2(idx_advance:end, :));
series_level_advance = array2timetable(series_level_advance, "RowTimes",date_advance);
writetimetable(series_level_advance, fullfile(outfolder, 'level_realized_advance.txt')); % export

for t = 1:numel(horizons)
    h = horizons(t);  
    series_growth_hq = [NaN(h, size(raw1, 2)); (4*100/h)*((raw1(1+h:end, :) - raw1(1:end-h, :)) - (raw2(1+h:end, :) - raw2(1:end-h, :)))./(raw1(1:end-h, :) + raw2(1:end-h, :))];
    series_growth_hq = series_growth_hq(idx_advance:end, :);
    series_growth_hq = diag(series_growth_hq);
    series_growth_hq = array2timetable(series_growth_hq, "RowTimes",date_advance); % convert to timetable
    
    filename = fullfile(outfolder, "pchg_realized_advance_" + string(h)+'Q.txt');
    writetimetable(series_growth_hq, filename) % export
end

