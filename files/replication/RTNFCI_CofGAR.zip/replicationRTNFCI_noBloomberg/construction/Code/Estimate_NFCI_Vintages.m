clearvars -except maindir
close all
warning("off")
rmpath(fullfile(maindir, 'code', 'functions',  'kevinsheppard-mfe_toolbox-45462370b5f0', 'crosssection')) %pca function causes problems

%Choose number of lags the state variable will be based on (e.g, 2 for AR(2))
num_lags = 15;
vintages = 1:1220;
    
%% ========================================================================
%SETUP THE DATA
%==========================================================================

%Load in true vintage
[nfci_data, nfci_txt] = xlsread('NFCI_2011Vintage.csv'); % changed 3/23/2026
nfci_data_dates = datetime(nfci_txt(2:end, 1)); % changed 3/23/2026

%Load data (base data)
[all.rawdata.weekly, all.rawtxt.weekly] = xlsread('financials_not_vintages.xlsx','Weekly');
[all.rawdata.monthly, all.rawtxt.monthly] = xlsread('financials_not_vintages.xlsx', 'Monthly');
[all.rawdata.quarterly, all.rawtxt.quarterly] = xlsread('financials_not_vintages.xlsx', 'Quarterly');


all.dates_txt.weekly = all.rawtxt.weekly(4:end, 1);
all.dates_txt.monthly = all.rawtxt.monthly(4:end, 1);
all.dates_txt.quarterly = all.rawtxt.quarterly(4:end, 1);

all.dates.weekly = [datetime(1959, 1, 2):caldays(7):datetime(2020,05,29)]';
all.dates.monthly = [datetime(1959, 1, 1):calmonths(1):datetime(2020,05,1)]';
all.dates.quarterly = [datetime(1959, 3, 1):calmonths(3):datetime(2020,3,1)]';

%Add NaNs to front of weekly series (to make it same size as dates)
all.rawdata.weekly = [NaN(length(all.dates_txt.weekly) - length(all.rawdata.weekly), size(all.rawdata.weekly, 2)); all.rawdata.weekly];


%Load in data (w/ vintages)
[all.vintagedata.nfc, all.vintagetxt.nfc] = xlsread('financials_with_vintages.xlsx', 'NFC');
[all.vintagedata.mcap, all.vintagetxt.mcap] = xlsread('financials_with_vintages.xlsx', 'MCAP');
[all.vintagedata.gse, all.vintagetxt.gse] = xlsread('financials_with_vintages.xlsx', 'GSE');
[all.vintagedata.tabs, all.vintagetxt.tabs] = xlsread('financials_with_vintages.xlsx', 'TABS');
[all.vintagedata.sbd, all.vintagetxt.sbd] = xlsread('financials_with_vintages.xlsx', 'SBD');
[all.vintagedata.fc, all.vintagetxt.fc] = xlsread('financials_with_vintages.xlsx', 'FC');
[all.vintagedata.fcorp, all.vintagetxt.fcorp] = xlsread('financials_with_vintages.xlsx', 'FCORP');
[all.vintagedata.ins, all.vintagetxt.ins] = xlsread('financials_with_vintages.xlsx', 'INS');
[all.vintagedata.pens, all.vintagetxt.pens] = xlsread('financials_with_vintages.xlsx', 'PENS');
[all.vintagedata.reit, all.vintagetxt.reit] = xlsread('financials_with_vintages.xlsx', 'REIT');
[all.vintagedata.stloc, all.vintagetxt.stloc] = xlsread('financials_with_vintages.xlsx', 'STLOC');



all.vintage_txt = all.vintagetxt.nfc(2, 2:end);
all.vintage_datetime = datetime(all.vintage_txt);

all.vintage_date_txt = all.vintagetxt.nfc(3:end, 1);
all.vintage_date_datetime = datetime(all.vintage_date_txt);

%Make sure vintage dates line up with other quarterly series dates
assert(length(all.vintage_date_datetime) == length(all.dates.quarterly));


%--------------------------------------------------------------------------
%Force VintageData to contain same dates/vintages as text


%Generalized version
fn = fieldnames(all.vintagedata);
for k = 1:numel(fn)
    temp_data = all.vintagedata.(fn{k});
    temp_txt = all.vintagetxt.(fn{k});
    idx_test = strcmp(temp_txt(3:end, 2:end), {'NaN'});
    idx2_test = sum(idx_test, 1);
    idx3_test = sum(idx_test, 2);
    
    %Figure out how many rows/columns to add to front vs. end
    count_front_row = 0;
    count_front_col = 0;
    for i = 1:length(idx2_test)
        if idx2_test(i) == length(idx3_test)
            count_front_col = count_front_col+1;
        else
            break
        end
    end
    for i = 1:length(idx2_test)
        if idx3_test(i) == length(idx2_test)
            count_front_row = count_front_row+1;
        else
            break
        end
    end
    
    %Add neccessary NaNs
    temp_data = [NaN(count_front_row,size(temp_data,2));temp_data];
    temp_data = [NaN(size(temp_data,1),count_front_col),temp_data];
    temp_data = [temp_data; NaN(length(idx3_test) - size(temp_data, 1), size(temp_data, 2))];
    temp_data = [temp_data, NaN(size(temp_data, 1), length(idx2_test) - size(temp_data, 2))];
    all.vintagedata.(fn{k}) = temp_data;
end

%--------------------------------------------------------------------------
%SETUP VINTAGE TIMING FOR FINANCIALS

all.series.weekly = all.rawtxt.weekly(1, 2:end);
all.series.monthly = all.rawtxt.monthly(1, 2:end);
all.series.quarterly = all.rawtxt.quarterly(1, 2:end);

all.release.weekly = repelem({'Available'}, length(all.series.weekly));
for i = 1:length(all.release.weekly)
    if sum(strcmp({'FAILS', 'FAILSA', 'FAILSMBS', 'FAILSC'},all.series.weekly(i))) == 1
        all.release.weekly(i) = {'Thursday, 1 Week'};
    end
end



all.release.monthly = cell(size(all.series.monthly));
%Current means July value reported in July, if not noted July value
%reported in August, if 1 month, July value reported in September.
for i = 1:length(all.release.monthly)
    if sum(strcmp({'MG'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'2nd Thursday'};
    elseif sum(strcmp({'CITA', 'CONTA', 'RTA', 'STA', 'ITA', 'DURSPREAD', 'HOUSSPREAD', 'CARSPREAD'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'2nd Friday'};
    elseif sum(strcmp({'CCG'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'1 month, 5th bus day'};
    elseif sum(strcmp({'FG'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'1 month, 4th Friday'};
    elseif sum(strcmp({'CTABS', 'CTF', 'CTMBS'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'2nd bus day'};
    elseif sum(strcmp({'NACMM'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'Current, last bus day'};
    elseif sum(strcmp({'MBONDGF', 'BONDGR', 'STKGR', 'CCDQ', 'CCINC', 'CRG'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'Last Friday'};
    elseif sum(strcmp({'MMF'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'Last Thursday'};
    elseif sum(strcmp({'SMALL'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'2nd Tuesday'};
    elseif sum(strcmp({''},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'1 month, 2nd Tuesday'};
    elseif sum(strcmp({'BDG'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'Last Tuesday'};
    elseif sum(strcmp({'LPH'},all.series.monthly(i))) == 1
        all.release.monthly(i) = {'1 month, 1st Tuesday'};
    end
end

all.release.quarterly = cell(size(all.series.quarterly));
for i = 1:length(all.release.quarterly)
    if sum(strcmp({'CBCAR'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'5th bus day'};
    elseif sum(strcmp({'CPH', 'HH'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'2 month, 2nd Thursday'};
    elseif sum(strcmp({'SPCILARGE', 'SPCISMALL', 'CRE', 'CILARGE', 'RRE', 'CISMALL', 'CWILL'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'1 month, 1st Monday'};
    elseif sum(strcmp({'CBPER'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'1 month, 1st Tuesday'};
    elseif sum(strcmp({'DHE', 'DBC', 'DCLOSE'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'1 month, 3rd Friday'};
    elseif sum(strcmp({'MDQ'},all.series.quarterly(i))) == 1
        all.release.quarterly(i) = {'1 month, 7th bus day'};
    end
end

%--------------------------------------------------------------------------
%SETUP ESTIMATION DATES AND ALLOCATE SPACE FOR STORAGE
estimate_dates = datetime(1988,1,6):caldays(7):datetime(2019,12,29);
mondays = datetime(1988,1,4):caldays(7):datetime(2020,1,1);
tuesdays = datetime(1988,1,5):caldays(7):datetime(2020,1,1);
thursdays = datetime(1988,1,7):caldays(7):datetime(2020,1,1);
fridays = datetime(1988,1,8):caldays(7):datetime(2020,1,1);
busdays = datetime(1988,1,4):caldays(1):datetime(2020,1,1);
busdays = busdays(ismember(weekday(busdays), [2 3 4 5 6]));

%Note that second dimension of Z will be at least 6 due to the 2 lags added
%through the accumulation
m = max(num_lags + 3, 6);
V = length(estimate_dates);
max_length = length(datetime(1971,1,8):caldays(7):estimate_dates(end));

all.Z = nan(92, m, V);
all.H = nan(92, 92, V);
all.Q = nan(1, 1, V);
all.T = nan(m, m, 6, V); 
all.R = nan(m, 1, 5, V); 
all.factors = nan(max_length, V);
all.alphaHat = nan(max_length, m, V);
all.Z_scaled = nan(92, V);
all.ssML = cell(V, 1);



dates_loop = NaT(max_length, V);
num_series_loop = nan(1, V);
series_loop = cell(92, V);
time_to_run = nan(V, 1);

start = 1;




%% ========================================================================
%BEGIN MAIN LOOP OVER EACH VINTAGE
%==========================================================================


for v = vintages(start:end)
    try %In case the vintage doesn't work we can move on
        
        disp('Vintage '+string(v)+' of '+string(V))
        
        estimate_date = estimate_dates(v);
        
        %--------------------------------------------------------------------------
        %SELECT DATA BASED ON ESTIMATION DATE
                
        %Dates
        dates.weekly = all.dates.weekly(all.dates.weekly <= estimate_date);
        dates.monthly = all.dates.monthly(all.dates.monthly <= estimate_date);
        dates.quarterly = all.dates.quarterly(all.dates.quarterly <= estimate_date);
                
        %Series Specific keep index
        keepdateidx.weekly = find_released('Weekly', estimate_date, all.release.weekly, dates.weekly, mondays, tuesdays, thursdays, fridays, busdays);
        keepdateidx.monthly = find_released('Monthly', estimate_date, all.release.monthly, dates.monthly, mondays, tuesdays, thursdays, fridays, busdays);
        keepdateidx.quarterly = find_released('Quarterly', estimate_date, all.release.quarterly, dates.quarterly, mondays, tuesdays, thursdays, fridays, busdays);
        
        %Vintage dates to keep
        vintages_lessthan = find(all.vintage_datetime <= estimate_date);
        correct_vintage_idx = vintages_lessthan(end);
        
        %The @FFUNDS Series may also lose their last observation
        
            
        %Data
        rawtxt.weekly = all.rawtxt.weekly(1:length(dates.weekly)+3, :);
        rawtxt.monthly = all.rawtxt.monthly(1:length(dates.monthly)+3, :);
        rawtxt.quarterly = all.rawtxt.quarterly(1:length(dates.quarterly)+3, :);
        
        rawdata.weekly = all.rawdata.weekly(1:length(dates.weekly), :);
        rawdata.monthly = all.rawdata.monthly(1:length(dates.monthly), :);
        rawdata.quarterly = all.rawdata.quarterly(1:length(dates.quarterly), :);
        
        rawdata.weekly(~logical(keepdateidx.weekly)) = NaN;
        rawdata.monthly(~logical(keepdateidx.monthly)) = NaN;
        rawdata.quarterly(~logical(keepdateidx.quarterly)) = NaN;
        
        
        for k = 1:numel(fn)
            temp_data =  all.vintagedata.(fn{k});
            vintagedata.(fn{k}) = temp_data(1:length(dates.quarterly), correct_vintage_idx);
        end
        
        
        %The @FFUNDS Series may also lose their last observation
        series.vintagedata = {'NFC', 'MCAP', 'GSE', 'TABS', 'SBD', 'FC', 'FCORP', 'INS', 'PENS', 'REIT', 'STLOC'};
        keepdateidx.FFUNDS = find_released('Quarterly', estimate_date, {'2 month, 2nd Tuesday'}, dates.quarterly, mondays, tuesdays, thursdays, fridays, busdays);
        
        for k = 1:numel(fn)
            if sum(strcmp({'NFC', 'GSE', 'TABS', 'SBD', 'FC', 'FCORP', 'INS', 'PENS', 'REIT', 'STLOC'}, series.vintagedata(k)))
                vintagedata.(fn{k})(~logical(keepdateidx.FFUNDS)) = NaN;
            end
        end
        
        %Add vintage data to other quarterly data
        vintagedata.all = NaN(size(vintagedata.nfc, 1), numel(fn));
        for k = 1:numel(fn)
            vintagedata.all(:, k) = vintagedata.(fn{k});
        end
        rawdata.quarterly = [rawdata.quarterly, vintagedata.all];
        
        %Find  rows to remove for each data frequency
        removerow.weekly = sum(~isnan(rawdata.weekly), 2) == 0;
        removerow.monthly = sum(~isnan(rawdata.monthly), 2) == 0;
        removerow.quarterly = sum(~isnan(rawdata.quarterly), 2) == 0;
        
        rawdata.weekly = rawdata.weekly(~removerow.weekly, :);
        rawdata.monthly = rawdata.monthly(~removerow.monthly, :);
        rawdata.quarterly = rawdata.quarterly(~removerow.quarterly, :);
        
        dates.weekly = dates.weekly(~removerow.weekly);
        dates.monthly = dates.monthly(~removerow.monthly);
        dates.quarterly = dates.quarterly(~removerow.quarterly);
        
        rawtxt.weekly = all.rawtxt.weekly(1:length(dates.weekly)+3, :);
        rawtxt.monthly = all.rawtxt.monthly(1:length(dates.monthly)+3, :);
        rawtxt.quarterly = all.rawtxt.quarterly(1:length(dates.quarterly)+3, :);
        
        daten.weekly = datenum(dates.weekly);
        daten.monthly = datenum(dates.monthly);
        daten.quarterly = datenum(dates.quarterly);
        
        %Series Names
        series.weekly = rawtxt.weekly(1, 2:end);
        series.monthly = rawtxt.monthly(1, 2:end);
        series.quarterly = [rawtxt.quarterly(1, 2:end), series.vintagedata];
        
        %Get Transformation Codes
        codes.vintagedata = repelem({'DLN'}, 1, 11);
        codes.weekly = rawtxt.weekly(3, 2:end);
        codes.monthly = rawtxt.monthly(3, 2:end);
        codes.quarterly = [rawtxt.quarterly(3, 2:end), codes.vintagedata];
        
        %For Series with Moving Averages, specify size of moving average
        ma_codes.weekly = NaN(size(codes.weekly));
        ma_codes.monthly = NaN(size(codes.monthly));
        ma_codes.quarterly = NaN(size(codes.quarterly));
        
        
        %Monthly
        ma_codes.monthly(strcmp(series.monthly, 'MBONDGF')) = 12;
        ma_codes.monthly(strcmp(series.monthly, 'BONDGR')) = 12;
        ma_codes.monthly(strcmp(series.monthly, 'STKGR')) = 12;
        
        %Weekly
        ma_codes.weekly(strcmp(series.weekly, 'FINS')) = 104;
        
        
        %--------------------------------------------------------------------------
        %TRANSFORM AND REDUCE AND DEMEAN/NORMALIZE SERIES
        
        %Transform Series
        data.weekly = prepare_missing_nfci(rawdata.weekly, codes.weekly, ma_codes.weekly);
        data.monthly = prepare_missing_nfci_monthly(rawdata.monthly, codes.monthly, ma_codes.monthly, daten.monthly);
        data.quarterly = prepare_missing_nfci(rawdata.quarterly, codes.quarterly, ma_codes.quarterly);
        
        %Get rid of massive level change in FG in june 1985
        idx_june_1985 = find(dates.monthly == datetime(1985, 6, 1));
        idx_FG = find(strcmp(series.monthly, 'FG'));
        data.monthly(idx_june_1985, idx_FG) = NaN;
        
        
        %Reduce dates to start at original sample
        idx_keepdate.weekly = dates.weekly >= datetime(1971, 1, 8);
        idx_keepdate.monthly = dates.monthly >= datetime(1971, 1, 8);
        idx_keepdate.quarterly = dates.quarterly >= datetime(1971, 1, 8);
        
        dates2.weekly = dates.weekly(idx_keepdate.weekly);
        dates2.monthly = dates.monthly(idx_keepdate.monthly);
        dates2.quarterly = dates.quarterly(idx_keepdate.quarterly);
        
        data2.weekly = data.weekly(idx_keepdate.weekly,:);
        data2.monthly = data.monthly(idx_keepdate.monthly,:);
        data2.quarterly = data.quarterly(idx_keepdate.quarterly,:);
        
        dates.final = dates.weekly(idx_keepdate.weekly);
        daten.final = daten.weekly(idx_keepdate.weekly);
        
        
        %Demean/Normalize series
        data_clean.weekly = standard_NaN(data2.weekly);
        data_clean.monthly = standard_NaN(data2.monthly);
        data_clean.quarterly = standard_NaN(data2.quarterly);
        
        
        %--------------------------------------------------------------------------
        %PUT LOW FREQUENCY DATA INTO WEEKLY FORMAT
        
        %Put Monthly Series into weekly format
        data_clean.monthly_weekly = NaN(length(data_clean.weekly), size(data_clean.monthly, 2));
        
        for j = 1:length(data_clean.weekly)
            if j ~= length(data_clean.weekly)
                if month(dates2.weekly(j)) < month(dates2.weekly(j+1))
                    try
                        data_clean.monthly_weekly(j, :) = data_clean.monthly(dates2.monthly == datetime(year(dates2.weekly(j)), month(dates2.weekly(j)), 1), :);
                    catch exception
                    end
                end
            else
                try
                    data_clean.monthly_weekly(j, :) = data_clean.monthly(dates2.monthly == datetime(year(dates2.weekly(j)), month(dates2.weekly(j)), 1), :);
                catch exception
                end
            end
        end
        
        
        %Put Quarterly Series into Weekly format
        data_clean.quarterly_weekly = NaN(length(data_clean.weekly), size(data_clean.quarterly, 2));
        
        for j = 1:length(data_clean.weekly)
            if j ~= length(data_clean.weekly)
                if (month(dates2.weekly(j)) < month(dates2.weekly(j+1))) || year(dates2.weekly(j)) < year(dates2.weekly(j+1)) ...
                        && ismember(month(dates2.weekly(j)), [3 6 9 12])
                    try
                        data_clean.quarterly_weekly(j, :) = data_clean.quarterly(dates2.quarterly == datetime(year(dates2.weekly(j)), month(dates2.weekly(j)), 1), :);
                    catch exception
                    end
                end
            else
                try
                    data_clean.quarterly_weekly(j, :) = data_clean.quarterly(dates2.quarterly == datetime(year(dates2.weekly(j)), month(dates2.weekly(j)), 1), :);
                catch exception
                end
            end
        end
        
        %--------------------------------------------------------------------------
        %PUT ALL SERIES TOGETHER AND DROP THOSE WITH SELECT NUMBER OF NANs
        %(Currently 1 Year)
        %If this is not the 1st of a quarter we should use the same series
        %as the previous estimation though.
        
            
        if v == 1 || month(estimate_date) ~= month(estimate_dates(v-1)) ||  sum(v-1 == vintages) == 0
            
            new_estimates = 1; %In this case we'll use previous vintage as initialization
            disp('Using PCA initialization...')
            series_drop_idx.quarterly = sum(~isnan(data_clean.quarterly_weekly)) < 8;
            series_drop_idx.monthly = sum(~isnan(data_clean.monthly_weekly)) < 24;
            series_drop_idx.weekly = sum(~isnan(data_clean.weekly)) < 104;
                      
        else
            
            new_estimates = 0; %In this case we'll use previous vintage estimates and skip the estimation
            disp('Using estimates from previous vintage...')
            
        end
        
        data_clean2.quarterly_weekly = data_clean.quarterly_weekly(:,~series_drop_idx.quarterly);
        data_clean2.monthly_weekly = data_clean.monthly_weekly(:,~series_drop_idx.monthly);
        data_clean2.weekly = data_clean.weekly(:,~series_drop_idx.weekly);
        
        series_final.quarterly = series.quarterly(~series_drop_idx.quarterly);
        series_final.monthly = series.monthly(~series_drop_idx.monthly);
        series_final.weekly = series.weekly(~series_drop_idx.weekly);
        series_final.all = [series_final.quarterly, series_final.monthly, series_final.weekly];
        
        num_series.quarterly = length(series_final.quarterly);
        num_series.monthly = length(series_final.monthly);
        num_series.weekly = length(series_final.weekly);
        num_series.all = length(series_final.all);
        
        y_final =[data_clean2.quarterly_weekly, data_clean2.monthly_weekly, data_clean2.weekly];
        num_periods = length(dates.final);
               
        
        %% ========================================================================
        %ESTIMATE MULTI-FREQUENCY DYNAMIC FACTOR MODEL
        %==========================================================================                    
        %SETUP ACCUMULATORS
        
        
        %Determine which monthly/quarterly series need average/sum accumulations
        %All Quarterly are sums
        type.accum = {};
        accum_idx.quarterly = [];
        frequencies.accum = {};
        type.quarterly = repelem({''}, num_series.quarterly);
        for i = 1:num_series.quarterly
            if sum(strcmp({'HH','NFC','MCAP','GSE','TABS','SBD','FC','FCORP','INS','PENS','REIT','CPH','DCOMM','GVL','MDQ','NCL', ...
                    'STLOC', 'DHE', 'DCLOSE', 'DBC', 'CBPER'}, series_final.quarterly(i))) >= 1
                type.quarterly(i) = {'sum'};
                type.accum{length(type.accum)+1} = 'sum';
                frequencies.accum{length(frequencies.accum)+1} = 'Quarter';
                accum_idx.quarterly = [accum_idx.quarterly i];
            end
        end
        
        type.monthly = repelem({''}, num_series.monthly);
        accum_idx.monthly = [];
        for i = 1:num_series.monthly
            if sum(strcmp({'CTABS','CTF','CTMBS','CCINC'}, series_final.monthly(i))) >= 1
                type.monthly(i) = {'avg'};
                type.accum{length(type.accum)+1} = 'avg';
                frequencies.accum{length(frequencies.accum)+1} = 'Month';
                accum_idx.monthly = [accum_idx.monthly i+num_series.quarterly];
            elseif sum(strcmp({'BDG','CITA','CONTA','RTA','STA','FOTA','ITA','FG','MG','CCDQ','CRG','FAILS','BONDGR','ABSI','CARSPREAD', ...
                    'CCG','CMBSI','CPH','DBC','DCLOSE','DHE','DOTH','DURSPREAD','HOUSSPREAD','MBONDGF','MBSI','MMF','SMALL', ...
                    'STKGR','W500','LPH','SMALL'}, series_final.monthly(i))) >= 1
                type.monthly(i) = {'sum'};
                type.accum{length(type.accum)+1} = 'sum';
                frequencies.accum{length(frequencies.accum)+1} = 'Month';
                accum_idx.monthly = [accum_idx.monthly i+num_series.quarterly];
            end
        end
        accum_idx.all = [accum_idx.quarterly, accum_idx.monthly];
        type.low = [type.quarterly, type.monthly];
        type.all = [type.quarterly,type.monthly,repelem({''},num_series.weekly)];
                                            
        %--------------------------------------------------------------------------
        %Make accumulator object
        
        accum = Accumulator.GenerateFromDates_NFCI(daten.final, accum_idx.all, frequencies.accum, type.accum);
        accum_pca.index = accum.index;
        accum_pca.calendar = accum.calendar;
        accum_pca.horizon = accum.horizon;
        
        
        %--------------------------------------------------------------------------
        %Get PCA estimates
        
        if new_estimates == 1
            
            [f0,gamma0,sigma0,Yhat,Xhat] = StockWatsonMF_alt_AJAMOD(y_final, 'accum', accum_pca);
            sigma0 = diag(nanvar(y_final - f0*gamma0')); %Use unbalanced panel to get error variance instead
            
            
               
            %--------------------------------------------------------------------------
            %SETUP ESTIMATE OF STATE SPACE
            
            Z = [nan(num_series.all,1), zeros(num_series.all, num_lags-1)];
            H = diag(nan(1,num_series.all));
            
            T = [nan(1,num_lags); [eye(num_lags-1) zeros(num_lags-1,1)]];
            R = [eye(1); zeros(num_lags-1, 1)];
            Q = eye(1)/std(f0);
            
            ssE = StateSpaceEstimation(Z, H, T, Q, 'R', R);
                       
            
            %--------------------------------------------------------------------------
            %ACCUMULATE STATE SPACE
            
            ssEA = accum.augmentStateSpaceEstimation(ssE);
            
            %--------------------------------------------------------------------------
            %SETUP STATE SPACE FOR INITIALIZATION
            
            %Get Initial values
            Z0 = Z;
            Z0(1:num_series.all,1) = gamma0*std(f0);
            H0 = sigma0;
            
            %Increase H0 to at least be lower bound
            H0(H0 < 2.2204e-15 & H0 > 0) = 2.2205e-15;
            
            f0 = standard_NaN(f0); %This is unneccesary?
            Xf = ones(size(f0, 1) - num_lags, 1 * num_lags);
            for iLag = 1:num_lags
                Xf(:,1+1*(iLag-1):1*iLag) = f0(num_lags-iLag+1:end-iLag,:);
            end
            % Drop initial factor observations for lags
            Yf = f0(num_lags+1:end,:);
            % Initial guess of AR dynamics
            A0 = (Xf'*Xf) \ (Xf'*Yf);
            
            T0 = T;
            T0(1,1:num_lags) = A0';
            R0 = R;
            Q0 = Q;
            
            ss0 = StateSpace(Z0, H0, T0, Q0, 'R', R0);
            ss0A = accum.augmentStateSpace(ss0);
            
            % Check ss0A
            [test, ll0] = ss0A.filter(y_final');
            assert(isfinite(ll0));
            
            %--------------------------------------------------------------------------
            %ESTIMATE THE MODEL
            
            %Set ssEA parameters
            ssEA.solver = 'fmincon';
            ssEA.useParallel = true;
            ssEA.useMex = true;         
           
            %Estimate using intialization ss0
            tic
            ssML = ssEA.estimate(y_final, ss0A);
            time_to_run(v) = toc;
            disp('Vintage '+string(v)+' took '+string(time_to_run(v)/3600)+ ' hours to estimate.');
                                  
            
        else
            
            %Get accumulated state space
            ssEA = accum.augmentStateSpaceEstimation(ssE);
            
            %Use Previous Estimates
            ssML = all.ssML{v-1};
            ssML.n = size(y_final, 1);
            ssML.tau = ssEA.tau;
            
        end
        
        %Output correlation with true 2011 NFCI
        
        alphaHat = ssML.smooth(y_final);
        Z_estimate = ssML.Z;
        factor = standard_NaN(alphaHat(:, 1));
        fill_idx = 1;
        
        if max(abs(factor(1:20))) > 0 %Set to 0 to always cutoff first 2 years
            disp('Vintage '+string(v)+' cutting off first 2 years...')
            factor = standard_NaN(alphaHat(105:end, 1));
            fill_idx = 105;
        else
            fill_idx = 1;
        end
        
        all.factors(fill_idx:num_periods, v) = factor;
        
        
        nfci_corr = corr(all.factors(105:2106, v), nfci_data(1:2002), 'rows', 'pairwise');
        
        if nfci_corr < 0
            factor = factor*-1;
            all.factors(fill_idx:num_periods, v) = factor;
            nfci_corr = corr(all.factors(105:2106, v), nfci_data(1:2002), 'rows', 'pairwise');
            alphaHat = alphaHat*-1;
            Z_estimate = Z_estimate*-1;
        end
        
        disp('Vintage '+string(v)+' has correlation of '+string(nfci_corr));
        
        
        %--------------------------------------------------------------------------
               
        %STORE VALUES
        temp1 = sum(Z_estimate, 2);
        temp2 = nansum(abs(temp1));
        Z_scaled = temp1.*(100/temp2);
        
        all.Z(1:num_series.all, 1:size(Z_estimate, 2), v) = Z_estimate;
        all.Z_scaled(1:num_series.all, v) = Z_scaled;
        all.H(1:num_series.all, 1:num_series.all, v) = ssML.H;
        all.T(1:1:size(Z_estimate, 2), 1:1:size(Z_estimate, 2), 1:size(ssML.T, 3), v) = ssML.T;
        all.Q(:,:, v) = ssML.Q;
        all.R(1:size(Z_estimate, 2), :, 1:size(ssML.R, 3), v) = ssML.R;
        all.alphaHat(1:num_periods, 1:1:size(Z_estimate, 2), v) = alphaHat;
        all.ssML{v} = ssML;
        
        dates_loop(1:num_periods, v) = dates.final;
        num_series_loop(v) = num_series.all;
        series_loop(1:num_series.all, v) = series_final.all;
        
    catch exception
        disp('Vintage '+string(v)+ ' failed...')
    end
    
    
end

%Display total time it took
total_hours_to_run = (nansum(time_to_run))/3600;
disp('Total Estimation Time = '+string(total_hours_to_run)+' Hours');



%% ========================================================================
%FINALIZE

%Put together matrix with just the vintages we estimated
estimated_dates = dates_loop(:, vintages(end));
estimated_factors = all.factors(:, vintages);
estimated_vintagedates = estimate_dates(vintages);

indx = find(estimated_dates==datetime(1973, 1, 5));
estimated_dates = estimated_dates(indx:end);
estimated_factors = estimated_factors(indx:end, :);

%Save final results to excel
path = '..\NFCI_estimatedvintages.xlsx';
writecell({'Vintage'}, path ,'Range', 'B1')
writecell({'Date'}, path, 'Range', 'A2')
writecell(cellstr(estimated_dates), path, 'Range', 'A3')
writecell(cellstr(estimated_vintagedates), path, 'Range', 'B2')
writematrix(estimated_factors, path, 'Range', 'B3')

