% Purpose: run all construction .m files
%api_key = 'f999b68da68a43c60f0fb3312e2e3775'; % user will need to replace this api_key

fprintf('   |-- Getting Raw Data...\n')
run 'getData.m'

% Creates the financials_combined_spliced and financials_with_vintages files
fprintf('   |-- Cleaning Financial Data...\n')
run 'EditFinancials.m'

% Combines raw data with spliced data calculated in the previous step, outputs financials_not_vintages.xlsx
fprintf('   |-- Combining Financial Data...\n');
run 'combineFinancials.m'

% Final step: estimate NFCI
fprintf('   |-- Estimating NFCI Vintages...\n');
run Estimate_NFCI_Vintages.m