clearvars -except api_key maindir
close all

%% get 2011 true vintage of nfci and output to data folder
vintage_dates = webread(['https://api.stlouisfed.org/fred/series/vintagedates?series_id=' 'NFCI' '&file_type=json&api_key=' api_key]).vintage_dates;
vintage_date = vintage_dates(1); % we are interested in the very first vintage for the true data
url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" + "NFCI" ...
   + "&" + "vintage_dates" + "=" + string(vintage_date) ...
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
data = timetable(dates, pulled_series_data);
writetimetable(data, fullfile(maindir, 'construction', 'RawData', 'NFCI_2011vintage.csv'))

fprintf('   |   |-- Official NFCI Vintages Pulled.\n')

%% get gnp/gdp data from FRED, chunk does not run if the file already exists
if ~isfile(fullfile(maindir, 'construction', 'RawData', 'gnp-gdp-vintages.csv'))
    pause(60) % pause in between pulling fred vintages
    data = fred_vintages_api(api_key, 'GDP'); % this function will take about ten minutes as it has to pull every vintage from FRED
    writetimetable(data, fullfile(maindir, 'construction', 'RawData', 'gdp.csv'))
    fprintf('   |   |-- GDP Vintages Pulled.\n')
    pause(60) % pause in between pulling fred vintages
    data = fred_vintages_api(api_key, 'GNP'); % this function will take about ten minutes as it has to pull every vintage from FRED
    writetimetable(data, fullfile(maindir, 'construction', 'RawData', 'gnp.csv'))
    fprintf('   |   |-- GNP Vintages Pulled.\n')
    
    gnp = readtimetable('gnp.csv', 'ReadVariableNames',true, 'VariableNamingRule','preserve');
    gdp = readtimetable('gdp.csv', 'ReadVariableNames',true, 'VariableNamingRule','preserve');
    gnp(:, ge(datetime(gnp.Properties.VariableNames), datetime(gdp.Properties.VariableNames(1)))) = [];
    gnp_gdp = innerjoin(gnp, gdp);
    gnp_gdp(:, datetime(gnp_gdp.Properties.VariableNames) < datetime(1959, 5, 15)) = []; % delete vintages before 1959
    gnp_gdp(gnp_gdp.Properties.RowTimes < datetime(1959, 1, 1), :) = []; % delete dates before 1959
    gnp_gdp(gnp_gdp.Properties.RowTimes > datetime(2020, 1, 1), :) = []; % delete dates after 2020
    writetimetable(gnp_gdp, fullfile(maindir, 'construction', 'RawData', 'gnp-gdp-vintages.csv'))

end 

%% get fred delinquency rates
url = "https://api.stlouisfed.org/fred/series/observations?"... % pull fred data : DRSREACBS	DRCLACBS	DRCCLACBS
   + "series_id" + "=" +  "DRSREACBS"...
   + "&" + "vintage_dates" + "=" + "2021-05-21" ...
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
data1 = timetable(dates, pulled_series_data);

url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" +  "DRCLACBS"...
   + "&" + "vintage_dates" + "=" + "2021-05-21" ...
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
data2 = timetable(dates, pulled_series_data);

url = "https://api.stlouisfed.org/fred/series/observations?"...
   + "series_id" + "=" +  "DRCCLACBS"...
   + "&" + "vintage_dates" + "=" + "2021-05-21" ...
   + "&" + "file_type" + "=" + "json" ...
   + "&" + "api_key" + "=" + api_key;
pull = webread(url);
dates = datetime({pull.observations.date}'); % Convert from char to datetime
pulled_series_data = str2double({pull.observations.value}'); % Convert from char to numeric
data3 = timetable(dates, pulled_series_data);

fred = outerjoin(data1, data2);
fred = outerjoin(fred, data3);
fred.Properties.VariableNames =[{'DRSREACBS'} ,   {'DRCLACBS'} ,   {'DRCCLACBS'}];
writetimetable(fred, fullfile(maindir, 'construction', 'RawData', 'delinquencyRates.csv'))
fprintf('   |   |-- Delinquency Rates Pulled.\n')
