% combine raw financial data with spliced data from EditFinancials.m
clearvars -except api_key maindir
close all

weekly = readcell(fullfile(maindir, 'construction', 'RawData', 'financials_not_vintages_raw.xlsx'), 'Sheet', 'Weekly');
weeklySpliced = readcell(fullfile(maindir, 'construction', 'CleanedData', 'financials_combined_spliced.xlsx'), 'Sheet', 'Weekly');
weeklyAll = [weekly, weeklySpliced(:, 2:end)];
weeklyAll(cellfun(@(x) any(ismissing(x)), weeklyAll))={NaN};
weeklyMat = weeklyAll(4:end, 2:end);
writecell(weeklyMat, fullfile(maindir, 'construction', 'CleanedData', 'financials_not_vintages.xlsx'), 'Sheet', 'Weekly', 'Range', 'B4')

monthly = readcell(fullfile(maindir, 'construction', 'RawData', 'financials_not_vintages_raw.xlsx'), 'Sheet', 'Monthly');
monthlySpliced = readcell(fullfile(maindir, 'construction', 'CleanedData', 'financials_combined_spliced.xlsx'), 'Sheet', 'Monthly');
monthlyAll = [monthly(1:end-1, :), monthlySpliced(:, 2:end)];
monthlyAll(cellfun(@(x) any(ismissing(x)), monthlyAll))={NaN};
writecell(monthlyAll, fullfile(maindir, 'construction', 'CleanedData', 'financials_not_vintages.xlsx'), 'Sheet', 'Monthly')

quarterly = readcell(fullfile(maindir, 'construction', 'RawData', 'financials_not_vintages_raw.xlsx'), 'Sheet', 'Quarterly');
fred = readcell(fullfile(maindir, 'construction', 'RawData', 'delinquencyRates.csv'));
quarterlyAll = quarterly;
quarterlyAll(find(double(string(quarterly(:, 1))) == 19871):end, end-2:end) = fred(2:134, 2:end);
quarterlyAll(cellfun(@(x) any(ismissing(x)), quarterlyAll))={NaN};
writecell(quarterlyAll, fullfile(maindir, 'construction', 'CleanedData', 'financials_not_vintages.xlsx'), 'Sheet', 'Quarterly')
