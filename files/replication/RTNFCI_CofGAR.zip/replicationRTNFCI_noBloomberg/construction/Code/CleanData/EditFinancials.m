clearvars -except api_key maindir
close all

%% ========================================================================  
%CREATE VINTAGES FOR QUARTERLY FINANCIALS THAT UTILIZE GNP/GDP

%Read in financials
[raw_financial.quarterly, raw_financial_txt.quarterly] = xlsread('nfci-haver-data.xlsx', 'Quarterly');
financial_datetime.quarterly = raw_financial_txt.quarterly(3:end, 1);

%Read in GNP/GDP vintages
gndp_raw = readcell('gnp-gdp-vintages.csv');
gndp = cell2mat(gndp_raw(2:end, 2:end));
gndp_datetime = vertcat(gndp_raw{2:end, 1});
gndp_date_txt = cellstr(datestr(gndp_datetime));
gndp_vintagetime = horzcat(gndp_raw{1, 2:end});
gndp_vintagedate_txt = cellstr(datestr(gndp_vintagetime))';

%Create vintage for each series
nfc = raw_financial.quarterly(:, 1)./gndp; %Nonfinancial business debt outstanding / GDP
mcap = raw_financial.quarterly(:, 2)./gndp; %S&P 500, NASDAQ, and NYSE Market Capitalization/GDP
gse = raw_financial.quarterly(:, 3)./gndp; %Total Agency and GSE Assets/GDP
tabs = raw_financial.quarterly(:, 4)./gndp; %Total Assets of ABS issuers/GDP
sbd = raw_financial.quarterly(:, 5)./gndp; %Total Assets of Broker-dealers/GDP
fc = raw_financial.quarterly(:, 6)./gndp; %Total Assets of Finance Companies/GDP
fcorp = raw_financial.quarterly(:, 7)./gndp; %Total Assets of Funding Corporations/GDP
ins = raw_financial.quarterly(:, 8)./gndp; %Total Assets of Insurance Companies/GDP
pens = raw_financial.quarterly(:, 9)./gndp; %Total Assets of Pension Funds/GDP
reit = raw_financial.quarterly(:, 10)./gndp; %Total REIT Assets/GDP
stloc = raw_financial.quarterly(:, 11)./gndp; %FEDERAL, STATE, AND LOCAL DEBT OUSTANDING/GDP

nfc2 = num2cell(nfc);
nfc2(isnan(nfc)) = {'NaN'};
nfc = nfc2;

mcap2 = num2cell(mcap);
mcap2(isnan(mcap)) = {'NaN'};
mcap = mcap2;

gse2 = num2cell(gse);
gse2(isnan(gse)) = {'NaN'};
gse = gse2;

tabs2 = num2cell(tabs);
tabs2(isnan(tabs)) = {'NaN'};
tabs = tabs2;

sbd2 = num2cell(sbd);
sbd2(isnan(sbd)) = {'NaN'};
sbd = sbd2;

fc2 = num2cell(fc);
fc2(isnan(fc)) = {'NaN'};
fc = fc2;

fcorp2 = num2cell(fcorp);
fcorp2(isnan(fcorp)) = {'NaN'};
fcorp = fcorp2;

ins2 = num2cell(ins);
ins2(isnan(ins)) = {'NaN'};
ins = ins2;

pens2 = num2cell(pens);
pens2(isnan(pens)) = {'NaN'};
pens = pens2;

reit2 = num2cell(reit);
reit2(isnan(reit)) = {'NaN'};
reit = reit2;

stloc2 = num2cell(stloc);
stloc2(isnan(stloc)) = {'NaN'};
stloc = stloc2;

%Export each set of vintages to excel
outfile = fullfile(maindir, 'construction', 'CleanedData', 'financials_with_vintages.xlsx');
mat_A = horzcat(NaN, 'Vintage', cell(1, length(gndp_vintagetime) - 1));
mat_B = vertcat({'Date'}, gndp_date_txt);

%nonfinance_busdebt
mat_C1 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, nfc));
outmat1 = vertcat(mat_A, mat_C1);
writecell(outmat1, outfile, 'Sheet', 'NFC');


%sp500_nasdaq_nyse
mat_C2 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, mcap));
outmat2 = vertcat(mat_A, mat_C2);
writecell(outmat2, outfile, 'Sheet', 'MCAP');

%agency_and_gse
mat_C3 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, gse));
outmat3 = vertcat(mat_A, mat_C3);
writecell(outmat3, outfile, 'Sheet', 'GSE');

%assets_ABS
mat_C4 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, tabs));
outmat4 = vertcat(mat_A, mat_C4);
writecell(outmat4, outfile, 'Sheet', 'TABS');

%assets_broker
mat_C5 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, sbd));
outmat5 = vertcat(mat_A, mat_C5);
writecell(outmat5, outfile, 'Sheet', 'SBD');

%assets_finance
mat_C6 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, fc));
outmat6 = vertcat(mat_A, mat_C6);
writecell(outmat6, outfile, 'Sheet', 'FC');

%assets_funding
mat_C7 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, fcorp));
outmat7 = vertcat(mat_A, mat_C7);
writecell(outmat7, outfile, 'Sheet', 'FCORP');

%assets_insurance
mat_C8 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, ins));
outmat8 = vertcat(mat_A, mat_C8);
writecell(outmat8, outfile, 'Sheet', 'INS');

%assets_pension
mat_C9 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, pens));
outmat9 = vertcat(mat_A, mat_C9);
writecell(outmat9, outfile, 'Sheet', 'PENS');

%assets_reit
mat_C10 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, reit));
outmat10 = vertcat(mat_A, mat_C10);
writecell(outmat10, outfile, 'Sheet', 'REIT');

%federal,state,local debt
mat_C11 = horzcat(mat_B, vertcat(gndp_vintagedate_txt, stloc));
outmat11 = vertcat(mat_A, mat_C11);
writecell(outmat11, outfile, 'Sheet', 'STLOC');

%% ========================================================================  
%Splice weekly series together

[raw_financial.weekly, raw_financial_txt.weekly] = xlsread('nfci-haver-data.xlsx', 'Weekly');

add_nans = NaN(size(raw_financial_txt.weekly, 1) - size(raw_financial.weekly, 1) - 2, size(raw_financial.weekly, 2));
raw_financial.weekly = [add_nans; raw_financial.weekly];

%1)REPOGR: This one is weird. Just going to use whatever is available,
%prioritizing the single series. The scaling seems slightly different, but
%this only becomes a problem post-2011 anyway which doesn't concern us as
%much.
repogr_raw1 = raw_financial.weekly(:, 1:2);
repogr_raw2 = raw_financial.weekly(:, 3:4);

repogr1 = repogr_raw1(:, 1);
repogr_raw1_missing = isnan(repogr1);
repogr1(repogr_raw1_missing) = repogr_raw1(repogr_raw1_missing, 2);

repogr2 = repogr_raw2(:, 1);
repogr_raw2_missing = isnan(repogr2);
repogr2(repogr_raw2_missing) = repogr_raw2(repogr_raw2_missing, 2);

repogr = repogr1 + repogr2;

% 2) OEQ
oeq1 = raw_financial.weekly(:, 5);
oeq2 = raw_financial.weekly(:, 6:7);



oeq = oeq1 + splice_aja(oeq2(:, 1), oeq2(:, 2)); %spliced sp500_nasdaq series



%% ========================================================================  
%Splice monthly series together


[raw_financial.monthly, raw_financial_txt.monthly] = xlsread('nfci-haver-data.xlsx', 'Monthly');


bdg_raw = raw_financial.monthly(:, 1:2);
ita_raw = raw_financial.monthly(:, 3:4);

%1) BDG
bdg = splice_aja(bdg_raw(:, 1), bdg_raw(:, 2));

%2) ITA
ita = splice_aja(ita_raw(:, 1), ita_raw(:, 2));


%NOTE: THE CODE BELOW WILL ONLY WORK IF THE USER HAS ACCESS TO THE RAW
%BLOOMBERG DATA FILES.

% %% ========================================================================  
% %Combine series that require Haver and Bloomberg, and splice when
% %neccessary
% 
% %Load data
% [raw_financial.havercombine, raw_financial_txt.havercombine] = xlsread('nfci-haver-data.xlsx', 'Combine'); %Haver series
% [raw_financial.bbweekly, raw_financial_txt.bbweekly] = xlsread('nfci-bloomberg-data.xlsx', 'Sheet1'); %Bloomberg weekly series
% 
% %Strip first 6 rows of bb data to remove metadata, then add empty row at
% %end so it is same length of haverdata (and starts at same point).
% raw_financial.bbweekly = raw_financial.bbweekly(7:end, :);
% add_nan = NaN(1, size(raw_financial.bbweekly, 2));
% raw_financial.bbweekly = [raw_financial.bbweekly; add_nan];
% 
% % %Add Nans to bottom to correct size 
% % add_nans = NaN(size(raw_financial_txt.bbweekly, 1) - size(raw_financial.bbweekly, 1) - 7, size(raw_financial.bbweekly, 2));
% % raw_financial.bbweekly = [add_nans; raw_financial.bbweekly];
% % 
% % %Add extra NaN to bottom to make it long same length as haver data
% % add_nan = NaN(2, size(raw_financial.bbweekly, 2));
% % raw_financial.bbweekly = [add_nan; raw_financial.bbweekly];
% 
% %1) MBOND
% 
% mbond = raw_financial.havercombine(:, 1) - raw_financial.bbweekly(:, 1);
% 
% %2) JINC
% 
% jinc = raw_financial.bbweekly(:, 2) - raw_financial.bbweekly(:, 3);
% 
% %3) LIBID
% 
% libid = splice_aja(raw_financial.havercombine(:, 2), raw_financial.bbweekly(:, 4)) - raw_financial.havercombine(:, 3);
% 
% % 4) RTERM
% 
% rterm = raw_financial.bbweekly(:, 5) - raw_financial.bbweekly(:, 6);
% 
% %5) CMBS
% 
% cmbs = raw_financial.bbweekly(:, 7);
% 
% %6) HY
% 
% hy = raw_financial.havercombine(:, 4) - raw_financial.bbweekly(:, 8);
% 
% %7,8,9) REPOA, REPOMORT, REPO
% 
% repoa = raw_financial.havercombine(:, 5) - raw_financial.bbweekly(:, 9);
% repomort = raw_financial.havercombine(:, 5) - raw_financial.bbweekly(:, 10);
% repo = raw_financial.havercombine(:, 5) - raw_financial.bbweekly(:, 11);
% 
% % 10) BAA
% 
% baa = raw_financial.bbweekly(:, 8) - raw_financial.havercombine(:, 6);
% 
% %% ========================================================================
% %Export Financials
% 
% outfile = fullfile(maindir, 'construction', 'CleanedData', 'financials_combined_spliced.xlsx');
% 
% %Weekly
% weekly_header = {'OEQ','REPOGR', 'MBOND', 'JINC', 'LIBID', 'RTERM', 'CMBS', 'HY', 'REPOA', 'REPOMORT', 'REPO', 'BAA'; ...
%     'COPSPMP@WEEKLY + COPSP5P@WEEKLY + COPNAMP@WEEKLY + Splice(COPNASP@WEEKLY, COPCNAP@WEEKLY)', ...
%     'Splice(FDFR@WEEKLY, total(FDIRGVT@WEEKLY, FDIRTIT@WEEKLY, FDIRGST@WEEKLY, FDIRMBT@WEEKLY, FDIRCPT@WEEKLY, FDIREQT@WEEKLY, FDIROTT@WEEKLY, FDIRABT@WEEKLY)) + Splice(FDFV@WEEKLY, total(FDORGVT@WEEKLY, FDORTIT@WEEKLY, FDORGST@WEEKLY, FDORMBT@WEEKLY, FDORCPT@WEEKLY, FDOREQT@WEEKLY, FDOROTT@WEEKLY, FDORABT@WEEKLY))',...
%     'FCM20@WEEKLY - BBWK20GO_Index', ...
%     'ILMJNAVG_Index - ILM3NAVG_Index', 'Splice(FDB3@WEEKLY, WeeklyAverage(LIBMB03M_Index) - FTBS3@WEEKLY)', ...
%     'WeeklyAverage(USRGCGC_ICUS_CURNCY - USRG1Z_ICUS_CURNCY)', 'WeeklyAverage(CMBS_daily)', ...
%     'FMLPHM@WEEKLY - WeeklyAverage(MOODCBAA_Index)', 'R111RD@INTWKLY - USRGAG1T_ICUS_CURNCY', ...
%     'R111RD@INTLWKLY - WeeklyAverage(USRGCY1T_ICUS_CURNCY)', 'R111RD@INTWKLY - WeeklyAverage(USRG1T_ICUS_CURNCY)', ...
%     'WeeklyAverage(MOODCBAA_Index) - FCM10@WEEKLY'; ...
%     'DLNQ','DLNQ', 'LV', 'LV', 'LV', 'LV', 'LV', 'LV', 'LV', 'LV', 'LV', 'LV'};
% weekly_dates = raw_financial_txt.weekly(3:end, 1);
% weekly_series = [oeq, repogr, mbond, jinc, libid, rterm, cmbs, hy, repoa, repomort, repo, baa];
% 
% weekly_outcell = horzcat(vertcat({'Mnemonic'; 'Formula'; 'Transform'}, weekly_dates), vertcat(weekly_header, num2cell(weekly_series)));
% xlswrite(outfile, weekly_outcell, 'Weekly')
% 
% %Monthly
% monthly_header = {'BDG', 'ITA'; ...
%     'SPLICE(SPMD@USECON, SPFMD@USECON)', 'Splice((FAIFFA@USECON + FABWORA@USECON)/FAA@USECON, FAFRPA@USECON/FAA@USECON)'; ...
%     'DLN', 'DLN'};
% monthly_dates = raw_financial_txt.monthly(3:end-1, 1);
% monthly_series = [bdg, ita];
% 
% monthly_outcell = horzcat(vertcat({'Mnemonic'; 'Formula'; 'Transform'}, monthly_dates), vertcat(monthly_header, num2cell(monthly_series)));
% xlswrite(outfile, monthly_outcell, 'Monthly')

